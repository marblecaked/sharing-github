# CFA Level I Study Kit

A study guide (PDF) and a browser practice app built from one content source, so the two always match.

## Run the practice app

```bash
pip install -r requirements.txt
python app.py
```

Open http://127.0.0.1:8050. Progress (answers, drill results, mock history) is saved in your browser's local storage, so it persists between sessions on the same browser. "Reset all progress" on the Dashboard clears it.

| Page | What it does |
|---|---|
| Dashboard | Accuracy and coverage by topic, a "focus next" list ranked by exam weight and weakness, mock history |
| Study | The full readings, formula cards with variable breakdowns, and worked examples with hidden step-by-step solutions |
| Formula sheet | All formulas by topic, searchable; recall mode hides them so you can test yourself |
| Practice questions | Exam-style three-choice questions with explanations; filter by topic and section; "Unseen first" and "Missed only" modes |
| Calculation drills | 33 drill types that generate fresh numbers every time, check your answer to a tolerance, and show the full solution |
| Mock exam | Timed (90 seconds per question), weighted by the official topic weights, with navigator, flags, scoring by topic and a full review |

## Rebuild the PDF

Requires a TeX installation (`pdflatex` with standard packages: tcolorbox, enumitem, titlesec, mathpazo).

```bash
python build_pdf.py        # writes build/CFA_Level_I_Study_Guide.pdf
```

## Files

- `content/` the single source: one module per topic (readings, formulas, examples, practice problems)
- `drills.py` randomized calculation generators with worked solutions
- `app.py`, `assets/style.css` the Dash app
- `build_pdf.py` the LaTeX renderer
- `check_content.py` structural checks; `verify_answers.py` recomputes every numeric answer key independently

## Adding your own questions

Append a dict to the `problems` list in the relevant `content/<topic>.py` file:

```python
{"id": "q99", "section": "returns", "level": 2,
 "q": r"Question text with $math$",
 "choices": {"A": "...", "B": "...", "C": "..."}, "answer": "B",
 "explanation": r"Why B is right and the others are wrong."},
```

Then run `python check_content.py`. Both the app and the PDF pick it up automatically.

"""CFA Level I practice app.

Run:  pip install dash plotly
      python app.py          then open http://127.0.0.1:8050

Progress is saved in your browser (localStorage), so it persists between sessions
on the same browser. Content comes from the same source as the PDF study guide.
"""
import random
import re
import time
from urllib.parse import parse_qs

import plotly.graph_objects as go
from dash import (ALL, Dash, Input, Output, State, ctx, dcc, html, no_update)

import drills as D
from content import TOPICS, TOPIC_BY_ID

app = Dash(__name__, title="CFA Level I Practice", suppress_callback_exceptions=True,
           external_stylesheets=["https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap"])
server = app.server

# ------------------------------------------------------------------ data helpers
QUESTIONS = {}
for t in TOPICS:
    secs = {s["id"]: s["title"] for s in t["sections"]}
    for p in t["problems"]:
        QUESTIONS[f"{t['id']}:{p['id']}"] = dict(p, topic=t["id"], topic_name=t["name"],
                                                  section_title=secs[p["section"]])
TOPIC_OPTS = [{"label": t["name"], "value": t["id"]} for t in TOPICS]
LEVEL = {1: "Recall", 2: "Apply", 3: "Analyze"}
SECONDS_PER_Q = 90


def weight_mid(t):
    lo, hi = [float(x) for x in t["weight"].rstrip("%").split("-")]
    return (lo + hi) / 2


def M(text, cls="md"):
    return dcc.Markdown(text, mathjax=True, className=cls)


def empty_hist():
    return {"q": {}, "d": {}, "mock": []}


def hist_or_empty(h):
    h = h or empty_hist()
    for k, v in empty_hist().items():
        h.setdefault(k, v)
    return h


def topic_stats(h):
    rows = []
    for t in TOPICS:
        keys = [k for k in QUESTIONS if QUESTIONS[k]["topic"] == t["id"]]
        tried = [k for k in keys if h["q"].get(k)]
        correct = sum(1 for k in tried if h["q"][k][-1])
        drill_res = [r for name, rs in h["d"].items() if D.DRILLS.get(name, {}).get("topic") == t["id"] for r in rs]
        rows.append({"id": t["id"], "name": t["name"], "weight": t["weight"], "total": len(keys),
                     "tried": len(tried), "correct": correct,
                     "acc": (correct / len(tried) * 100) if tried else None,
                     "drills": len(drill_res), "drill_acc": (sum(drill_res) / len(drill_res) * 100) if drill_res else None})
    return rows


# ------------------------------------------------------------------ layout shell
NAV = [("/", "Dashboard", "◧"), ("/study", "Study", "❏"), ("/formulas", "Formula sheet", "∑"),
       ("/practice", "Practice questions", "✓"), ("/drills", "Calculation drills", "⌗"), ("/mock", "Mock exam", "◷")]

app.layout = html.Div(className="shell", children=[
    dcc.Location(id="url"),
    dcc.Store(id="hist", storage_type="local"),
    dcc.Store(id="prac-meta", storage_type="session"),
    dcc.Store(id="prac-score", storage_type="session"),
    dcc.Store(id="drill-cur"),
    dcc.Store(id="mock-meta", storage_type="session"),
    dcc.Store(id="mock-ans", storage_type="session"),
    dcc.Store(id="mock-idx", storage_type="session", data=0),
    html.Aside(className="sidebar", children=[
        html.Div(className="brand", children=[html.Div("CFA", className="brand-mark"),
                                              html.Div([html.Div("Level I", className="brand-title"),
                                                        html.Div("Practice studio", className="brand-sub")])]),
        html.Nav(id="nav", className="nav"),
        html.Div(className="sidebar-foot", children=[
            html.Div(f"{len(QUESTIONS)} questions · {len(D.DRILLS)} drill types"),
            html.Div("Progress is saved in this browser."),
        ]),
    ]),
    html.Main(id="page", className="main"),
])


@app.callback(Output("nav", "children"), Input("url", "pathname"))
def nav(path):
    path = path or "/"
    return [dcc.Link([html.Span(icon, className="nav-icon"), label], href=href,
                     className="nav-link active" if path == href else "nav-link")
            for href, label, icon in NAV]


@app.callback(Output("page", "children"), Input("url", "pathname"), State("url", "search"), State("hist", "data"))
def route(path, search, hist):
    q = parse_qs((search or "").lstrip("?"))
    pages = {"/study": page_study, "/formulas": page_formulas, "/practice": page_practice,
             "/drills": page_drills, "/mock": page_mock}
    if path in pages:
        return pages[path](q)
    return page_home(hist_or_empty(hist))


def header(title, sub):
    return html.Div(className="page-head", children=[html.H1(title), html.P(sub)])


# ------------------------------------------------------------------ dashboard
def page_home(h):
    return html.Div([
        header("Dashboard", "Where you stand by topic, weighted by how much each topic counts on the exam."),
        html.Div(id="home-body", children=home_body(h)),
    ])


def home_body(h):
    rows = topic_stats(h)
    tried = sum(r["tried"] for r in rows)
    correct = sum(r["correct"] for r in rows)
    dr = [x for rs in h["d"].values() for x in rs]
    mocks = h["mock"]
    tiles = html.Div(className="tiles", children=[
        tile("Questions attempted", f"{tried} / {len(QUESTIONS)}", f"{tried/len(QUESTIONS)*100:.0f}% of the bank"),
        tile("Accuracy (latest attempt)", f"{correct/tried*100:.0f}%" if tried else "–", f"{correct} correct"),
        tile("Drills solved", f"{sum(dr)} / {len(dr)}" if dr else "–", f"{sum(dr)/len(dr)*100:.0f}% within tolerance" if dr else "Randomized calculations"),
        tile("Best mock", f"{max(m['pct'] for m in mocks):.0f}%" if mocks else "–", f"{len(mocks)} mock(s) taken" if mocks else "90 seconds per question"),
    ])
    # focus list: weight * (gap to 80% accuracy or untried)
    scored = []
    for r in rows:
        gap = 1.0 if r["acc"] is None else max(0, 80 - r["acc"]) / 80
        cov_gap = 1 - r["tried"] / r["total"]
        scored.append((weight_mid(TOPIC_BY_ID[r["id"]]) * (0.6 * gap + 0.4 * cov_gap), r))
    scored.sort(key=lambda x: -x[0])
    focus = html.Div(className="card", children=[
        html.H3("Focus next"),
        html.P("Ranked by exam weight × (accuracy gap to 80% + untouched questions).", className="muted small"),
        html.Ol(className="focus", children=[
            html.Li([html.Span(r["name"], className="focus-name"),
                     html.Span(f"{r['weight']} · " + (f"{r['acc']:.0f}% on {r['tried']}/{r['total']}" if r["acc"] is not None else "not started"),
                               className="muted small"),
                     html.Div([dcc.Link("Study", href=f"/study?topic={r['id']}", className="chip"),
                               dcc.Link("Practice", href=f"/practice?topic={r['id']}", className="chip chip-solid")], className="focus-actions")])
            for _, r in scored[:4]]),
    ])
    table = html.Table(className="tbl", children=[
        html.Thead(html.Tr([html.Th(x) for x in ["Topic", "Weight", "Attempted", "Accuracy", "Drills"]])),
        html.Tbody([html.Tr([html.Td(dcc.Link(r["name"], href=f"/study?topic={r['id']}")), html.Td(r["weight"]),
                             html.Td(f"{r['tried']} / {r['total']}"),
                             html.Td(acc_badge(r["acc"])),
                             html.Td(f"{r['drill_acc']:.0f}% of {r['drills']}" if r["drills"] else "–")]) for r in rows]),
    ])
    mock_hist = html.Div()
    if mocks:
        mock_hist = html.Div(className="card", children=[html.H3("Mock exam history"), html.Table(className="tbl", children=[
            html.Thead(html.Tr([html.Th(x) for x in ["Date", "Questions", "Score", "Time used"]])),
            html.Tbody([html.Tr([html.Td(m["date"]), html.Td(m["n"]), html.Td(acc_badge(m["pct"])), html.Td(m.get("time", "–"))])
                        for m in reversed(mocks[-10:])])])])
    return [tiles,
            html.Div(className="grid-2", children=[
                html.Div(className="card", children=[html.H3("Accuracy by topic"),
                                                     html.P("Latest attempt on each question. Topics you have not started show no bar.", className="muted small"),
                                                     dcc.Graph(figure=acc_figure(rows), config={"displayModeBar": False})]),
                focus]),
            html.Div(className="card", children=[html.H3("Detail"), table]),
            mock_hist,
            html.Div(className="reset-row", children=[
                dcc.ConfirmDialogProvider(html.Button("Reset all progress", className="btn btn-ghost"), id="reset",
                                          message="Erase all saved answers, drill results and mock history in this browser?")])]


def tile(label, value, sub):
    return html.Div(className="tile", children=[html.Div(label, className="tile-label"),
                                                html.Div(value, className="tile-value"),
                                                html.Div(sub, className="tile-sub")])


def acc_badge(acc):
    if acc is None:
        return html.Span("–", className="muted")
    cls = "badge good" if acc >= 70 else "badge mid" if acc >= 55 else "badge low"
    return html.Span(f"{acc:.0f}%", className=cls)


def acc_figure(rows):
    rows = rows[::-1]
    y = [r["name"] for r in rows]
    x = [r["acc"] if r["acc"] is not None else 0 for r in rows]
    text = [f"{r['acc']:.0f}%" if r["acc"] is not None else "not started" for r in rows]
    custom = [[r["tried"], r["total"], r["weight"]] for r in rows]
    fig = go.Figure(go.Bar(x=x, y=y, orientation="h", marker=dict(color="#0F6E8C", cornerradius=4),
                           text=text, textposition="outside", cliponaxis=False, textfont=dict(color="#3D4756", size=12),
                           customdata=custom,
                           hovertemplate="<b>%{y}</b><br>Accuracy %{x:.0f}%<br>Attempted %{customdata[0]} of %{customdata[1]}<br>Exam weight %{customdata[2]}<extra></extra>"))
    fig.add_vline(x=70, line_width=1, line_dash="dot", line_color="#8A94A3",
                  annotation_text="70% target", annotation_position="top", annotation_font=dict(size=11, color="#5B6676"))
    fig.update_layout(height=360, margin=dict(l=10, r=60, t=24, b=10), plot_bgcolor="white", paper_bgcolor="white",
                      font=dict(family="Inter, system-ui, sans-serif", size=12, color="#3D4756"), bargap=0.35,
                      xaxis=dict(range=[0, 105], ticksuffix="%", gridcolor="#EEF1F5", zeroline=False),
                      yaxis=dict(automargin=True), hoverlabel=dict(bgcolor="white", font_size=12))
    return fig


@app.callback(Output("hist", "data", allow_duplicate=True), Output("home-body", "children"),
              Input("reset", "submit_n_clicks"), prevent_initial_call=True)
def reset(n):
    if not n:
        return no_update, no_update
    h = empty_hist()
    return h, home_body(h)


# ------------------------------------------------------------------ study
def page_study(q):
    tid = q.get("topic", [TOPICS[0]["id"]])[0]
    return html.Div([
        header("Study", "The reading, formulas with breakdowns and worked examples: the same material as the PDF."),
        html.Div(className="toolbar", children=[
            dcc.Dropdown(id="study-topic", options=TOPIC_OPTS, value=tid, clearable=False, className="dd dd-wide")]),
        html.Div(id="study-body"),
    ])


def formula_card(fo, hidden=False):
    formula = M(f"$$\n{fo['tex']}\n$$", "md formula")
    parts = [html.Div(fo["name"], className="f-name")]
    parts.append(html.Details([html.Summary("Reveal formula"), formula]) if hidden else formula)
    if fo["vars"]:
        parts.append(html.Table(className="vars", children=[
            html.Tr([html.Td(M(f"${s}$")), html.Td(M(m))]) for s, m in fo["vars"]]))
    if fo.get("note"):
        parts.append(M(fo["note"], "md f-note"))
    return html.Div(className="formula-card", children=parts)


def example_card(ex, label):
    return html.Div(className="example-card", children=[
        html.Div(f"Example {label}: {ex['title']}", className="ex-title"),
        M(ex["problem"]),
        html.Details(className="solution", children=[
            html.Summary("Show step-by-step solution"),
            html.Ol([html.Li(M(s)) for s in ex["steps"]], className="steps"),
            html.Div([html.Strong("Answer. "), M(ex["answer"], "md inline")], className="ex-answer")]),
    ])


@app.callback(Output("study-body", "children"), Input("study-topic", "value"))
def study_body(tid):
    t = TOPIC_BY_ID[tid]
    out = [html.Div(className="topic-hero", children=[
        html.Div([html.Div(f"Exam weight {t['weight']}", className="eyebrow"), html.H2(t["name"])]),
        dcc.Link(f"Practice {len(t['problems'])} questions →", href=f"/practice?topic={tid}", className="btn")]),
        M(t["overview"])]
    ti = TOPICS.index(t) + 1
    for si, s in enumerate(t["sections"], 1):
        inner = [M(s["body"])]
        if s["formulas"]:
            inner += [html.H4("Key formulas"), html.Div([formula_card(f) for f in s["formulas"]], className="formula-grid")]
        if s["examples"]:
            inner += [html.H4("Worked examples")] + [example_card(e, f"{ti}.{si}.{k}") for k, e in enumerate(s["examples"], 1)]
        n = sum(1 for p in t["problems"] if p["section"] == s["id"])
        inner.append(dcc.Link(f"Practice this section ({n} questions) →", href=f"/practice?topic={tid}&section={s['id']}", className="chip chip-solid"))
        out.append(html.Details(className="section", open=(si == 1), children=[
            html.Summary([html.Span(f"{ti}.{si}", className="sec-num"), s["title"]]), html.Div(inner, className="section-body")]))
    out.append(html.Div(className="trap-card", children=[html.H4("Exam traps"), html.Ul([html.Li(M(x)) for x in t["pitfalls"]])]))
    return out


# ------------------------------------------------------------------ formulas
def page_formulas(q):
    return html.Div([
        header("Formula sheet", "Every formula with its variables. Turn on recall mode to hide them and test yourself."),
        html.Div(className="toolbar", children=[
            dcc.Dropdown(id="f-topic", options=[{"label": "All topics", "value": "all"}] + TOPIC_OPTS, value="quant", clearable=False, className="dd"),
            dcc.Input(id="f-search", placeholder="Search formulas (e.g. duration, WACC)", debounce=True, className="input"),
            dcc.Checklist(id="f-hide", options=[{"label": " Recall mode (hide formulas)", "value": "hide"}], value=[], className="check")]),
        html.Div(id="f-body"),
    ])


@app.callback(Output("f-body", "children"), Input("f-topic", "value"), Input("f-search", "value"), Input("f-hide", "value"))
def f_body(tid, search, hide):
    s = (search or "").lower().strip()
    out = []
    for t in TOPICS:
        if tid not in ("all", t["id"]):
            continue
        cards = [formula_card(fo, "hide" in (hide or [])) for sec in t["sections"] for fo in sec["formulas"]
                 if not s or s in fo["name"].lower() or s in sec["title"].lower()]
        if cards:
            out += [html.H3(t["name"], className="f-topic"), html.Div(cards, className="formula-grid")]
    return out or html.P("No formulas match.", className="muted")


# ------------------------------------------------------------------ practice
def section_opts(tid):
    if tid in (None, "all"):
        return [{"label": "All sections", "value": "all"}]
    return [{"label": "All sections", "value": "all"}] + [{"label": s["title"], "value": s["id"]} for s in TOPIC_BY_ID[tid]["sections"]]


def page_practice(q):
    tid = q.get("topic", ["all"])[0]
    sec = q.get("section", ["all"])[0]
    return html.Div([
        header("Practice questions", "Exam-style, three choices, instant feedback with the reasoning behind every option."),
        html.Div(className="toolbar", children=[
            dcc.Dropdown(id="p-topic", options=[{"label": "All topics", "value": "all"}] + TOPIC_OPTS, value=tid, clearable=False, className="dd"),
            dcc.Dropdown(id="p-section", options=section_opts(tid), value=sec, clearable=False, className="dd"),
            dcc.Dropdown(id="p-mode", clearable=False, className="dd dd-narrow", value="unseen", options=[
                {"label": "Unseen first", "value": "unseen"}, {"label": "Missed only", "value": "missed"},
                {"label": "All, shuffled", "value": "all"}]),
            dcc.Dropdown(id="p-n", clearable=False, className="dd dd-narrow", value=10,
                         options=[{"label": f"{n} questions", "value": n} for n in (5, 10, 20, 50)]),
            html.Button("Start set", id="p-start", className="btn")]),
        html.Div(id="p-card"),
    ])


@app.callback(Output("p-section", "options"), Output("p-section", "value"), Input("p-topic", "value"), State("p-section", "value"),
              prevent_initial_call=True)
def p_sections(tid, cur):
    opts = section_opts(tid)
    return opts, cur if cur in [o["value"] for o in opts] else "all"


@app.callback(Output("prac-meta", "data"), Output("prac-score", "data"), Input("p-start", "n_clicks"),
              State("p-topic", "value"), State("p-section", "value"), State("p-mode", "value"), State("p-n", "value"),
              State("hist", "data"), prevent_initial_call=True)
def p_start(n, tid, sec, mode, size, hist):
    h = hist_or_empty(hist)
    keys = [k for k, p in QUESTIONS.items() if tid in ("all", p["topic"]) and sec in ("all", p["section"])]
    random.shuffle(keys)
    if mode == "missed":
        keys = [k for k in keys if h["q"].get(k) and not h["q"][k][-1]]
    elif mode == "unseen":
        keys.sort(key=lambda k: 1 if h["q"].get(k) else 0)
    keys = keys[:size]
    return {"queue": keys, "idx": 0, "started": time.time()}, {"right": 0, "done": 0}


@app.callback(Output("p-card", "children"), Input("prac-meta", "data"), State("prac-score", "data"))
def p_card(meta, score):
    if ctx.triggered_id is None and not meta:
        return intro_card("Pick a topic and start a set.",
                          "\"Unseen first\" works through the bank; \"Missed only\" revisits questions whose latest attempt was wrong.")
    if not meta or not meta["queue"]:
        return intro_card("No questions match that filter.", "Try \"All, shuffled\", or a different topic. \"Missed only\" needs some wrong answers first.")
    i, qs = meta["idx"], meta["queue"]
    if i >= len(qs):
        sc = score or {"right": 0, "done": 0}
        pct = sc["right"] / sc["done"] * 100 if sc["done"] else 0
        return html.Div(className="card done-card", children=[
            html.Div("Set complete", className="eyebrow"),
            html.H2(f"{sc['right']} / {sc['done']} correct ({pct:.0f}%)"),
            html.P("Start another set, or switch to \"Missed only\" to drill the ones you got wrong.", className="muted")])
    return question_view(qs[i], f"Question {i+1} of {len(qs)}", "p")


def question_view(key, progress, prefix, value=None, extra=None):
    p = QUESTIONS[key]
    return html.Div(className="card q-card", children=[
        html.Div(className="q-meta", children=[html.Span(progress, className="q-progress"),
                                               html.Span(p["topic_name"], className="tag"),
                                               html.Span(p["section_title"], className="tag tag-light"),
                                               html.Span(LEVEL[p.get("level", 2)], className="tag tag-light")] + (extra or [])),
        M(p["q"], "md q-text"),
        dcc.RadioItems(id=f"{prefix}-choice", value=value, className="choices", labelClassName="choice",
                       options=[{"label": html.Div([html.Span(k, className="choice-key"), M(v, "md choice-md")], className="choice-inner"),
                                 "value": k} for k, v in sorted(p["choices"].items())]),
        html.Div(id=f"{prefix}-feedback") if prefix == "p" else None,
        html.Div(className="q-actions", children=[
            html.Button("Submit", id="p-submit", className="btn"),
            html.Button("Next question →", id="p-next", className="btn btn-ghost", style={"display": "none"})]) if prefix == "p" else None,
    ])


def intro_card(title, sub):
    return html.Div(className="card intro", children=[html.H3(title), html.P(sub, className="muted")])


@app.callback(Output("p-feedback", "children"), Output("hist", "data", allow_duplicate=True), Output("prac-score", "data", allow_duplicate=True),
              Output("p-submit", "style"), Output("p-next", "style"), Output("p-choice", "options"),
              Input("p-submit", "n_clicks"), State("p-choice", "value"), State("p-choice", "options"),
              State("prac-meta", "data"), State("hist", "data"), State("prac-score", "data"), prevent_initial_call=True)
def p_submit(n, choice, opts, meta, hist, score):
    if not n:
        return (no_update,) * 6
    if not choice:
        return html.Div("Choose an answer first.", className="note warn"), no_update, no_update, no_update, no_update, no_update
    key = meta["queue"][meta["idx"]]
    p = QUESTIONS[key]
    ok = choice == p["answer"]
    h = hist_or_empty(hist)
    h["q"].setdefault(key, []).append(1 if ok else 0)
    sc = score or {"right": 0, "done": 0}
    sc = {"right": sc["right"] + ok, "done": sc["done"] + 1}
    marked = []
    for k, v in sorted(p["choices"].items()):
        state = " is-correct" if k == p["answer"] else (" is-wrong" if k == choice else "")
        mark = "✓" if k == p["answer"] else ("✗" if k == choice else "")
        marked.append({"label": html.Div([html.Span(k, className="choice-key"), M(v, "md choice-md"), html.Span(mark, className="choice-mark")],
                                         className="choice-inner" + state), "value": k, "disabled": True})
    fb = feedback(p, choice)
    return fb, h, sc, {"display": "none"}, {"display": "inline-flex"}, marked


def feedback(p, choice):
    ok = choice == p["answer"]
    return html.Div(className="feedback " + ("ok" if ok else "bad"), children=[
        html.Div(("Correct." if ok else f"Not quite. You chose {choice}; the answer is {p['answer']}."), className="fb-head"),
        M(p["explanation"])])


@app.callback(Output("prac-meta", "data", allow_duplicate=True), Input("p-next", "n_clicks"), State("prac-meta", "data"),
              prevent_initial_call=True)
def p_next(n, meta):
    if not n:
        return no_update
    meta["idx"] += 1
    return meta


# ------------------------------------------------------------------ drills
def drill_opts(tid):
    names = D.drills_for(tid)
    return [{"label": "Any drill" + ("" if tid == "all" else " in this topic"), "value": "any"}] + \
           [{"label": D.DRILLS[n]["title"], "value": n} for n in names]


def page_drills(q):
    tid = q.get("topic", ["all"])[0]
    return html.Div([
        header("Calculation drills", "Fresh numbers every time, checked to a tolerance, with a full worked solution."),
        html.Div(className="toolbar", children=[
            dcc.Dropdown(id="d-topic", options=[{"label": "All topics", "value": "all"}] +
                         [o for o in TOPIC_OPTS if D.drills_for(o["value"])], value=tid, clearable=False, className="dd"),
            dcc.Dropdown(id="d-type", options=drill_opts(tid), value="any", clearable=False, className="dd dd-wide"),
            html.Button("New problem", id="d-new", className="btn")]),
        html.Div(id="d-card", children=intro_card("Choose a topic or drill type, then press New problem.",
                                                   "Enter percentages as numbers (5.25 for 5.25%). Commas, % and USD are ignored.")),
    ])


@app.callback(Output("d-type", "options"), Output("d-type", "value"), Input("d-topic", "value"), prevent_initial_call=True)
def d_types(tid):
    return drill_opts(tid), "any"


@app.callback(Output("drill-cur", "data"), Output("d-card", "children"), Input("d-new", "n_clicks"),
              State("d-topic", "value"), State("d-type", "value"), prevent_initial_call=True)
def d_new(n, tid, typ):
    names = D.drills_for(tid) if typ == "any" else [typ]
    d = D.generate(random.choice(names), seed=random.randrange(10**9))
    unit = {"%": "%", "USD": "USD", "USD bn": "USD billions", "USD M": "USD millions", "years": "years"}.get(d["unit"], "")
    card = html.Div(className="card q-card", children=[
        html.Div(className="q-meta", children=[html.Span(TOPIC_BY_ID[d["topic"]]["name"], className="tag"),
                                               html.Span(d["title"], className="tag tag-light")]),
        M(d["question"], "md q-text"),
        html.Div(className="answer-row", children=[
            dcc.Input(id="d-input", type="text", placeholder="Your answer", className="input input-answer", debounce=False, n_submit=0),
            html.Span(unit, className="unit"),
            html.Button("Check", id="d-check", className="btn"),
            html.Button("Show solution", id="d-show", className="btn btn-ghost")]),
        html.Div(id="d-feedback"),
    ])
    return d, card


def parse_num(s):
    if s is None:
        return None
    s = re.sub(r"(?i)usd|[,$%\s]", "", str(s))
    try:
        return float(s)
    except ValueError:
        return None


@app.callback(Output("d-feedback", "children"), Output("hist", "data", allow_duplicate=True),
              Input("d-check", "n_clicks"), Input("d-input", "n_submit"), Input("d-show", "n_clicks"),
              State("d-input", "value"), State("drill-cur", "data"), State("hist", "data"), prevent_initial_call=True)
def d_check(n1, n2, n3, val, d, hist):
    if not d or not (n1 or n2 or n3):
        return no_update, no_update
    sol = html.Div(className="solution-open", children=[html.Div("Solution", className="fb-sub"),
                                                        html.Ol([html.Li(M(s)) for s in d["steps"]], className="steps"),
                                                        html.Div(f"Answer: {fmt_ans(d)}", className="ex-answer")])
    if ctx.triggered_id == "d-show":
        return sol, no_update
    x = parse_num(val)
    if x is None:
        return html.Div("Enter a number.", className="note warn"), no_update
    ok = abs(x - d["answer"]) <= d["tol"]
    h = hist_or_empty(hist)
    h["d"].setdefault(d["name"], []).append(1 if ok else 0)
    head = html.Div(("Correct." if ok else f"Not quite: the answer is {fmt_ans(d)}."), className="fb-head")
    return html.Div(className="feedback " + ("ok" if ok else "bad"), children=[head, sol]), h


def fmt_ans(d):
    a = d["answer"]
    if d["unit"] == "%":
        return f"{a:.3f}%"
    if abs(a) >= 1000:
        return f"{a:,.2f}"
    return f"{a:.4f}".rstrip("0").rstrip(".") if abs(a) < 10 else f"{a:,.2f}"


# ------------------------------------------------------------------ mock exam
def page_mock(q):
    return html.Div([
        header("Mock exam", "Mixed questions weighted by the exam's topic weights, timed at 90 seconds per question."),
        html.Div(id="mock-setup", className="toolbar", children=[
            dcc.Dropdown(id="m-n", clearable=False, className="dd", value=30,
                         options=[{"label": f"{n} questions · {n*SECONDS_PER_Q//60} min", "value": n} for n in (15, 30, 60, 90, 120)]),
            dcc.ConfirmDialogProvider(html.Button("Start new mock", className="btn"), id="m-start",
                                      message="Start a new timed mock? Any mock in progress will be replaced.")]),
        html.Div(className="mock-wrap", children=[
            html.Div(id="m-main"),
            html.Div(className="mock-side", children=[html.Div(id="m-timer", className="timer"), html.Div(id="m-grid")]),
        ]),
        dcc.Interval(id="m-tick", interval=1000),
    ])


def allocate(n):
    w = {t["id"]: weight_mid(t) for t in TOPICS}
    tot = sum(w.values())
    avail = {t["id"]: len(t["problems"]) for t in TOPICS}
    alloc = {k: min(avail[k], round(n * v / tot)) for k, v in w.items()}
    while sum(alloc.values()) != n:
        diff = n - sum(alloc.values())
        cands = [k for k in alloc if (alloc[k] < avail[k] if diff > 0 else alloc[k] > 0)]
        k = max(cands, key=lambda k: (w[k] / tot * n - alloc[k]) * (1 if diff > 0 else -1))
        alloc[k] += 1 if diff > 0 else -1
    return alloc


@app.callback(Output("mock-meta", "data"), Output("mock-ans", "data"), Output("mock-idx", "data"),
              Input("m-start", "submit_n_clicks"), State("m-n", "value"), prevent_initial_call=True)
def m_start(n, size):
    if not n:
        return no_update, no_update, no_update
    qs = []
    for tid, k in allocate(size).items():
        keys = [x for x in QUESTIONS if QUESTIONS[x]["topic"] == tid]
        qs += random.sample(keys, k)
    random.shuffle(qs)
    return {"qs": qs, "start": time.time(), "dur": size * SECONDS_PER_Q, "submitted": False, "saved": False}, {"a": {}, "f": []}, 0


@app.callback(Output("m-main", "children"), Input("mock-meta", "data"), Input("mock-idx", "data"), State("mock-ans", "data"))
def m_main(meta, idx, ans):
    if not meta:
        return intro_card("No mock in progress.", "Choose a length and start. You can move between questions, flag them, and submit early.")
    if meta["submitted"]:
        return mock_results(meta, ans)
    ans = ans or {"a": {}, "f": []}
    key = meta["qs"][idx]
    flagged = idx in ans["f"]
    qv = question_view(key, f"Question {idx+1} of {len(meta['qs'])}", "m", value=ans["a"].get(str(idx)))
    qv.children.append(html.Div(className="q-actions", children=[
        html.Button("← Previous", id="m-prev", className="btn btn-ghost", disabled=idx == 0),
        html.Button("Unflag" if flagged else "⚑ Flag for review", id="m-flag", className="btn btn-ghost" + (" flagged" if flagged else "")),
        html.Button("Next →", id="m-next", className="btn btn-ghost", disabled=idx == len(meta["qs"]) - 1),
        dcc.ConfirmDialogProvider(html.Button("Submit exam", className="btn"), id="m-submit",
                                  message="Submit the exam now? Unanswered questions count as wrong.")]))
    return qv


@app.callback(Output("mock-ans", "data", allow_duplicate=True), Input("m-choice", "value"), State("mock-idx", "data"),
              State("mock-ans", "data"), prevent_initial_call=True)
def m_answer(v, idx, ans):
    if v is None:
        return no_update
    ans = ans or {"a": {}, "f": []}
    ans["a"][str(idx)] = v
    return ans


@app.callback(Output("mock-idx", "data", allow_duplicate=True), Output("mock-ans", "data", allow_duplicate=True),
              Input("m-prev", "n_clicks"), Input("m-next", "n_clicks"), Input("m-flag", "n_clicks"),
              Input({"type": "m-nav", "i": ALL}, "n_clicks"),
              State("mock-idx", "data"), State("mock-ans", "data"), State("mock-meta", "data"), prevent_initial_call=True)
def m_nav(p, nx, fl, navs, idx, ans, meta):
    t = ctx.triggered_id
    if not ctx.triggered or not ctx.triggered[0]["value"]:
        return no_update, no_update
    if t == "m-prev":
        return max(0, idx - 1), no_update
    if t == "m-next":
        return min(len(meta["qs"]) - 1, idx + 1), no_update
    if t == "m-flag":
        f = set(ans["f"])
        f.symmetric_difference_update({idx})
        ans["f"] = sorted(f)
        return idx, ans
    if isinstance(t, dict):
        return t["i"], no_update
    return no_update, no_update


@app.callback(Output("m-grid", "children"), Input("mock-ans", "data"), Input("mock-idx", "data"), Input("mock-meta", "data"))
def m_grid(ans, idx, meta):
    if not meta or meta["submitted"]:
        return None
    ans = ans or {"a": {}, "f": []}
    btns = []
    for i in range(len(meta["qs"])):
        cls = "nav-q"
        if str(i) in ans["a"]:
            cls += " answered"
        if i in ans["f"]:
            cls += " flagged"
        if i == idx:
            cls += " current"
        btns.append(html.Button(str(i + 1), id={"type": "m-nav", "i": i}, className=cls))
    return [html.Div(f"{len(ans['a'])} of {len(meta['qs'])} answered · {len(ans['f'])} flagged", className="muted small"),
            html.Div(btns, className="nav-grid"),
            html.Div([html.Span(className="key answered"), "answered ", html.Span(className="key flagged"), "flagged"], className="legend small")]


@app.callback(Output("m-timer", "children"), Output("mock-meta", "data", allow_duplicate=True),
              Input("m-tick", "n_intervals"), State("mock-meta", "data"), prevent_initial_call=True)
def m_tick(_, meta):
    if not meta or meta["submitted"]:
        return None, no_update
    left = meta["start"] + meta["dur"] - time.time()
    if left <= 0:
        meta["submitted"] = True
        meta["end"] = time.time()
        return None, meta
    m, s = divmod(int(left), 60)
    cls = "timer-val" + (" low" if left < 300 else "")
    return [html.Div("Time remaining", className="tile-label"), html.Div(f"{m:02d}:{s:02d}", className=cls)], no_update


@app.callback(Output("mock-meta", "data", allow_duplicate=True), Input("m-submit", "submit_n_clicks"), State("mock-meta", "data"),
              prevent_initial_call=True)
def m_submit(n, meta):
    if not n or not meta:
        return no_update
    meta["submitted"] = True
    meta["end"] = time.time()
    return meta


def mock_results(meta, ans):
    ans = ans or {"a": {}, "f": []}
    qs = meta["qs"]
    res = [(i, k, ans["a"].get(str(i))) for i, k in enumerate(qs)]
    right = sum(1 for _, k, a in res if a == QUESTIONS[k]["answer"])
    pct = right / len(qs) * 100
    used = int(min(meta.get("end", time.time()) - meta["start"], meta["dur"]))
    by = {}
    for _, k, a in res:
        tid = QUESTIONS[k]["topic"]
        r = by.setdefault(tid, [0, 0])
        r[0] += a == QUESTIONS[k]["answer"]
        r[1] += 1
    review = []
    for i, k, a in sorted(res, key=lambda x: x[2] == QUESTIONS[x[1]]["answer"]):
        p = QUESTIONS[k]
        ok = a == p["answer"]
        review.append(html.Details(className="review " + ("ok" if ok else "bad"), children=[
            html.Summary([html.Span("✓" if ok else "✗", className="mark"), f"Q{i+1} · {p['topic_name']} · ",
                          html.Span(f"your answer {a or '–'}, correct {p['answer']}", className="muted")]),
            M(p["q"]),
            html.Ul([html.Li([html.Strong(f"{c}. "), M(v, "md inline")], className="opt" + (" right" if c == p["answer"] else " wrong" if c == a else ""))
                     for c, v in sorted(p["choices"].items())], className="opts"),
            M(p["explanation"], "md expl")]))
    return html.Div([
        html.Div(className="card done-card", children=[
            html.Div("Mock exam result", className="eyebrow"),
            html.H2(f"{right} / {len(qs)} correct · {pct:.0f}%"),
            html.P(f"Time used {used//60} min {used%60:02d} s of {meta['dur']//60} min. "
                   "CFA Institute does not publish the passing score; many candidates aim for 70%+ on mocks.", className="muted"),
            html.Table(className="tbl", children=[
                html.Thead(html.Tr([html.Th("Topic"), html.Th("Score"), html.Th("")])),
                html.Tbody([html.Tr([html.Td(TOPIC_BY_ID[t]["name"]), html.Td(f"{r[0]} / {r[1]}"), html.Td(acc_badge(r[0] / r[1] * 100))])
                            for t, r in by.items()])])]),
        html.H3("Review (wrong answers first)", className="f-topic"),
        html.Div(review),
    ])


@app.callback(Output("hist", "data", allow_duplicate=True), Output("mock-meta", "data", allow_duplicate=True),
              Input("mock-meta", "data"), State("mock-ans", "data"), State("hist", "data"), prevent_initial_call=True)
def m_save(meta, ans, hist):
    if not meta or not meta["submitted"] or meta.get("saved"):
        return no_update, no_update
    ans = ans or {"a": {}, "f": []}
    h = hist_or_empty(hist)
    right = 0
    for i, k in enumerate(meta["qs"]):
        a = ans["a"].get(str(i))
        ok = a == QUESTIONS[k]["answer"]
        right += ok
        if a is not None:
            h["q"].setdefault(k, []).append(1 if ok else 0)
    used = int(min(meta.get("end", time.time()) - meta["start"], meta["dur"]))
    h["mock"].append({"date": time.strftime("%Y-%m-%d %H:%M"), "n": len(meta["qs"]), "pct": right / len(meta["qs"]) * 100,
                      "time": f"{used//60}:{used%60:02d}"})
    meta["saved"] = True
    return h, meta


if __name__ == "__main__":
    app.run(debug=False, port=8050)

"""Independently recompute every numeric multiple-choice answer and check it matches the keyed choice."""
import math, re
from scipy.optimize import brentq
from content import TOPIC_BY_ID as T

def bp(c,y,n,m=1,F=100):
    return sum(c*F/m/(1+y/m)**t for t in range(1,n*m+1))+F/(1+y/m)**(n*m)
pva=lambda p,r,n:p*(1-(1+r)**-n)/r
calc = {
 ("quant","q1"): ((1.15*.9*1.2)**(1/3)-1)*100,
 ("quant","q3"): math.log(1.025)*100,
 ("quant","q4"): 3/(1/20+1/25+1/16),
 ("quant","q5"): (1.02**4-1)*100,
 ("quant","q6"): 5/.08,
 ("quant","q7"): pva(10000,.06,5)/1.06**3,
 ("quant","q8"): (.09-2/50)*100,
 ("quant","q12"): .6*.3/.4*100,
 ("quant","q13"): abs(.5*20-.5*20),
 ("quant","q17"): 1.5-2.064*5/5,
 ("quant","q19"): .3*math.sqrt(28)/math.sqrt(1-.09),
 ("quant","q21"): (200-60)/(60/30),
 ("econ","x4"): .25+.09+.04,
 ("econ","x9"): 1/(1-.9*.8),
 ("econ","x18"): (1.3/1.365-1)*100,
 ("econ","x19"): 1.35*1.08,
 ("econ","x20"): 18*1.045/1.02,
 ("corp","c5"): ((1+1/99)**(365/20)-1)*100,
 ("corp","c10"): pva(200,.08,3)-500,
 ("corp","c14"): (.4*6*.75+.6*10),
 ("corp","c16"): 500+.25*200,
 ("corp","c19"): 2*1.5*10,
 ("fsa","f5"): 3e6/1.7e6,
 ("fsa","f6"): 800+120+20+50-70-30,
 ("fsa","f9"): 2000-150+40,
 ("fsa","f11"): 5000-150,
 ("fsa","f15"): .5*(50000-25000),
 ("fsa","f16"): 800-700,
 ("fsa","f17"): 300/60,
 ("fsa","f21"): 400+50-20,
 ("fsa","f23"): .75*.8*.12*1.5*2*100,
 ("fsa","f26"): 200/250,
 ("equity","q1"): 40*.6/.7,
 ("equity","q5"): 1/.25,
 ("equity","q16"): .6*15,
 ("equity","q17"): 1.5*1.04/.045,
 ("equity","q18"): 2/1.11+(2.2+2.2*1.04/.07)/1.11**2,
 ("equity","q20"): 800+300+50-100,
 ("equity","q22"): 6/.075,
 ("fi","b5"): bp(.04,.06,3),
 ("fi","b7"): (1.03**2-1)*100,
 ("fi","b10"): 100*(1-180/360*.05),
 ("fi","b11"): (1.03**2/1.02-1)*100,
 ("fi","b15"): (6*.02+.5*50*.02**2)*100,
 ("fi","b16"): (100.85-99.17)/(2*.001*100),
 ("fi","b19"): 7.2*1.05e6,
 ("fi","b21"): .03*.55*100,
 ("fi","b24"): -5*.004*100,
 ("fi","b29"): 1.5/1.2,
 ("deriv","d3"): 3000-2200,
 ("deriv","d5"): 40*1.03**.75,
 ("deriv","d8"): 63-60/1.04**.25,
 ("deriv","d11"): 50-43-4,
 ("deriv","d14"): 4.5+50/1.05**.5-52,
 ("deriv","d16"): .4*5/1.02,
 ("deriv","d18"): 60-55/1.05,
 ("alts","a1"): (240-3.6-.2*(240-200-3.6)-200)/200*100,
 ("alts","a2"): .2*(240-3.6-220),
 ("alts","a6"): 160/80,
 ("alts","a11"): .9/.075,
 ("pm","p4"): .09-.5*3*.15**2,
 ("pm","p6"): .4*4+.6*10,
 ("pm","p8"): .64*25/16,
 ("pm","p9"): 2.5+1.3*6.5,
 ("pm","p12"): 10*16/20-7,
 ("pm","p13"): 14-(4+1.2*7),
}
bad=0
for (tid,pid),v in calc.items():
    p=next(x for x in T[tid]["problems"] if x["id"]==pid)
    txt=p["choices"][p["answer"]]
    nums=[float(n.replace(",","")) for n in re.findall(r"-?\d[\d,]*\.?\d*",txt)]
    if "-USD" in txt: nums=[-n for n in nums]
    ok=any(abs(n-v)<=max(abs(v)*0.006,0.011) or abs(n+v)<=max(abs(v)*0.006,0.011) for n in nums)
    # also make sure no OTHER choice is equally close
    others=[c for k,c in p["choices"].items() if k!=p["answer"]]
    clash=[c for c in others for n in [float(x.replace(",","")) for x in re.findall(r"-?\d[\d,]*\.?\d*",c)] if abs(n-v)<=max(abs(v)*0.002,0.005)]
    if not ok or clash:
        bad+=1; print("MISMATCH",tid,pid,round(v,4),"| keyed:",txt,"| clash:",clash)
print(len(calc),"numeric answers checked,",bad,"problems")

import re, sys
from content import TOPICS
errs=[]; nq=0; nf=0; ne=0
def strs(o, path=""):
    if isinstance(o,str): yield path,o
    elif isinstance(o,dict):
        for k,v in o.items(): yield from strs(v,f"{path}.{k}")
    elif isinstance(o,list):
        for i,v in enumerate(o): yield from strs(v,f"{path}[{i}]")
for t in TOPICS:
    secs={s['id'] for s in t['sections']}
    ids=set()
    for p in t['problems']:
        nq+=1
        if p['id'] in ids: errs.append(f"dup id {t['id']}:{p['id']}")
        ids.add(p['id'])
        if p['section'] not in secs: errs.append(f"bad section {t['id']}:{p['id']}")
        if p['answer'] not in p['choices']: errs.append(f"bad answer {p['id']}")
        if sorted(p['choices'])!=['A','B','C']: errs.append(f"choices {p['id']}")
    for s in t['sections']:
        nf+=len(s['formulas']); ne+=len(s['examples'])
    for path,s in strs(t,t['id']):
        bad=[c for c in s if ord(c)>127]
        if bad: errs.append(f"nonascii {path}: {set(bad)}")
        n=len(re.findall(r'(?<!\\)\$',s.replace('$$','')))
        if n%2 and not path.endswith('.tex') and '.vars' not in path: errs.append(f"odd $ {path}")
print("topics",len(TOPICS),"problems",nq,"formulas",nf,"examples",ne)
print("\n".join(errs) or "OK")

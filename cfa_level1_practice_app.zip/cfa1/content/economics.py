TOPIC = {
"id": "econ",
"name": "Economics",
"weight": "6-9%",
"overview": r"""Level I economics has eight modules: firms and market structures, understanding business cycles, fiscal policy, monetary policy, introduction to geopolitics, international trade, capital flows and the FX market, and exchange rate calculations. Most questions are conceptual (identify the market structure, the phase of the cycle, the effect of a policy). The calculation questions that reliably appear are **elasticities, breakeven/shutdown points, the fiscal multiplier, cross rates, and forward rates** from interest rate parity.""",
"sections": [
{
"id": "firms",
"title": "Firms and Market Structures",
"body": r"""**Elasticity of demand** measures how sensitive quantity demanded is to price. Demand is *elastic* when $|E_P| > 1$ (quantity changes proportionally more than price) and *inelastic* when $|E_P| < 1$. Elasticity matters for revenue: when demand is elastic, cutting price **raises** total revenue; when inelastic, raising price raises revenue. Revenue is maximized where $|E_P| = 1$. Income elasticity separates normal goods (positive) from inferior goods (negative); cross-price elasticity separates substitutes (positive) from complements (negative).

**Profit maximization.** Every firm maximizes profit where **marginal revenue = marginal cost (MR = MC)**. Economic profit subtracts the opportunity cost of all resources, including the owners' capital, so *zero economic profit* means the firm earns a normal return.

**Breakeven and shutdown.**

- Price $\ge$ ATC: economic profit $\geq$ 0; continue.
- AVC $\le$ price < ATC: losing money, but covering variable costs and some fixed costs: **operate in the short run**, exit in the long run.
- Price < AVC: **shut down** immediately; operating adds to the loss.

**Economies of scale** (falling long-run average cost as output rises) come from specialization and bulk purchasing; diseconomies come from bureaucracy. The *minimum efficient scale* is the lowest output at which long-run average cost is minimized.

**The four market structures.**

| Feature | Perfect competition | Monopolistic competition | Oligopoly | Monopoly |
|---|---|---|---|---|
| Number of sellers | Many | Many | Few | One |
| Product | Identical | Differentiated | Similar or differentiated | Unique |
| Barriers to entry | Very low | Low | High | Very high |
| Pricing power | None (price taker) | Some | Some to significant (interdependent) | Considerable |
| Long-run economic profit | Zero | Zero | Possible | Possible |
| Demand curve | Horizontal (P = MR) | Downward sloping, elastic | Kinked / interdependent | Downward sloping (market demand) |

**Oligopoly models.** *Kinked demand*: rivals match price cuts but not increases, so prices are sticky. *Cournot*: firms choose quantities; the outcome lies between monopoly and perfect competition. *Stackelberg*: a leader moves first and gains. *Dominant firm*: one large low-cost firm sets the price; small firms take it. *Nash equilibrium*: no firm can improve by unilaterally changing strategy; collusion is unstable because each firm has an incentive to cheat.

**Measuring concentration.** The N-firm concentration ratio sums the market shares of the N largest firms but ignores mergers among the largest firms and potential entry. The **Herfindahl-Hirschman Index (HHI)** sums *squared* market shares and is more sensitive to mergers among large firms.""",
"formulas": [
{"name": "Own-price elasticity of demand", "tex": r"E_P = \frac{\%\Delta Q_d}{\%\Delta P} = \frac{\Delta Q_d}{\Delta P}\cdot\frac{P}{Q_d}",
 "vars": [["Q_d", "quantity demanded"], ["P", "price"]], "note": "Income elasticity: $\\%\\Delta Q/\\%\\Delta I$. Cross-price: $\\%\\Delta Q_x/\\%\\Delta P_y$."},
{"name": "Profit maximizing condition", "tex": r"MR = MC", "vars": [["MR", "marginal revenue"], ["MC", "marginal cost"]], "note": "Perfect competition: $P = MR = MC$."},
{"name": "Herfindahl-Hirschman Index", "tex": r"HHI = \sum_{i=1}^{N} s_i^2", "vars": [["s_i", "market share of firm i (as a decimal, or in % for the 0-10,000 scale)"]], "note": "Equal-sized firms: $HHI = 1/N$."},
],
"examples": [
{"title": "Elasticity and revenue",
 "problem": "A coffee shop raises its price from USD 10 to USD 11, and daily cups sold fall from 100 to 85. Is demand elastic? What happened to revenue?",
 "steps": [r"$\%\Delta P = +10\%$; $\%\Delta Q = -15\%$.", r"$E_P = -15/10 = -1.5$: elastic.", r"Revenue: $10 \times 100 = 1{,}000$ before; $11 \times 85 = 935$ after."],
 "answer": "Elastic (-1.5); revenue fell by USD 65, as expected when raising price on elastic demand."},
{"title": "Concentration",
 "problem": "Four firms hold 40%, 30%, 20% and 10% of a market. Compute the 4-firm concentration ratio and the HHI.",
 "steps": [r"CR4 $= 40+30+20+10 = 100\%$.", r"HHI $= 0.40^2 + 0.30^2 + 0.20^2 + 0.10^2 = 0.16 + 0.09 + 0.04 + 0.01 = 0.30$ (3,000 on the 10,000 scale)."],
 "answer": "CR4 = 100%; HHI = 0.30, equivalent to about 3.3 equal-sized firms (1/0.30)."},
],
},
{
"id": "cycles",
"title": "Business Cycles",
"body": r"""**Phases.** A business cycle runs through **recovery** (output below potential but rising), **expansion** (growth above trend, output gap closing then positive), **slowdown** (growth slowing, output above potential, inflation pressure) and **contraction** (output falling; a recession is typically two consecutive quarters of negative GDP growth). The output gap is actual minus potential GDP.

**Typical behavior through the cycle.**

| | Recovery | Expansion | Slowdown | Contraction |
|---|---|---|---|---|
| Inventories | Rebuilt | Rising with demand | Unintended build-up | Liquidated |
| Hiring | Overtime first, then hiring | Strong hiring | Hiring slows | Layoffs, hours cut |
| Capex | Starts to rise | Strong | Peaks | Cut sharply |
| Inflation | Low | Rising | Highest | Falling (lags) |

The **inventory-to-sales ratio** rises at the end of an expansion (sales fall faster than production adjusts) and falls in early recovery. Firms first lengthen hours, then hire, because hiring is costly to reverse.

**Credit cycles** tend to amplify business cycles: lenders loosen standards in booms and tighten in busts. Credit cycles last longer than business cycles and deep credit contractions are associated with deeper recessions.

**Theories.** Neoclassical (markets self-correct; cycles from technology shocks), Keynesian (insufficient aggregate demand; use fiscal policy), Monetarist (money supply drives cycles; follow steady money growth rules), Austrian (excessive credit from artificially low rates causes malinvestment), New Classical / real business cycle (cycles are efficient responses to real shocks).

**Unemployment.** Frictional (between jobs), structural (skills mismatch) and cyclical (demand-driven). The *natural rate* is frictional + structural. *Discouraged workers* have stopped looking and are excluded from the labor force, so the unemployment rate can fall in a recession for the wrong reason. Unemployment is a **lagging** indicator.

**Inflation.** Cost-push (input costs rise) vs. demand-pull (demand outstrips capacity). Core inflation excludes food and energy. Deflation is dangerous because it raises the real burden of debt and encourages households to delay spending. **Price indexes** such as the CPI (fixed basket, Laspeyres) overstate inflation through *substitution bias*, *quality bias* and *new-product bias*; a chained index reduces substitution bias.

**Economic indicators.** *Leading* (turn before the economy: average weekly hours in manufacturing, initial jobless claims, new orders, building permits, the stock market, the yield curve spread, consumer expectations); *coincident* (employees on payrolls, personal income, industrial production, manufacturing sales); *lagging* (average duration of unemployment, inventory-to-sales ratio, change in unit labor costs, average prime rate, commercial loans outstanding, consumer credit to income, change in services CPI).""",
"formulas": [
{"name": "Output gap", "tex": r"\text{Output gap} = \text{Actual GDP} - \text{Potential GDP}", "vars": [], "note": "Positive gap: inflationary pressure."},
{"name": "Unemployment and participation rates", "tex": r"\text{Unemployment rate} = \frac{\text{Unemployed}}{\text{Labor force}} \qquad \text{Participation} = \frac{\text{Labor force}}{\text{Working-age population}}", "vars": [], "note": ""},
],
"examples": [
{"title": "Reading the cycle",
 "problem": "GDP is growing faster than trend, firms report rising unit labor costs, inventories are rising faster than sales and the central bank has begun raising rates. Which phase is most likely?",
 "steps": ["Above-trend growth, cost pressure and policy tightening are late-cycle signals.", "Inventories rising faster than sales indicates demand is beginning to cool."],
 "answer": "Late expansion moving into slowdown."},
],
},
{
"id": "policy",
"title": "Fiscal and Monetary Policy",
"body": r"""**Fiscal policy** is the government's use of spending and taxes. *Discretionary* policy requires action; *automatic stabilizers* (progressive taxes, unemployment benefits) work counter-cyclically on their own. Fiscal policy suffers from **recognition, action and impact lags**, and can be offset by *crowding out* (government borrowing raises rates and displaces private investment) or *Ricardian equivalence* (households save tax cuts in anticipation of future taxes).

The **fiscal multiplier** shows how much GDP changes per unit change in government spending. The **balanced budget multiplier** is positive (equal increases in spending and taxes still raise GDP) because part of a tax increase is paid out of saving. Direct taxes are levied on income and wealth; indirect taxes on goods and services (e.g. sales tax, VAT). A budget deficit is not automatically expansionary: what matters is the *change* in the structural (cyclically adjusted) balance.

**Monetary policy** is run by central banks, whose usual mandate is price stability (often an inflation target near 2%), sometimes with full employment. Tools: the **policy rate** (the main tool), **reserve requirements** and **open market operations** (buying securities adds reserves and is expansionary). With rates near zero, central banks use **quantitative easing** (large-scale asset purchases).

**Transmission mechanism.** A cut in the policy rate lowers market rates, raises asset prices, weakens the currency and boosts expectations and confidence, raising domestic demand and net exports, and eventually inflation.

**Money creation.** Banks lend out excess reserves; each loan becomes a deposit elsewhere. The money multiplier is $1/\text{reserve requirement}$. The **quantity theory of money** says $MV = PY$: with stable velocity and real output, money growth drives inflation. The **Fisher effect**: nominal rate $\approx$ real rate + expected inflation (+ a risk premium for uncertainty).

**The neutral rate** is the policy rate that neither stimulates nor restrains the economy: trend real growth plus the inflation target. Policy is expansionary when the policy rate is below neutral, contractionary when above.

**Central bank qualities**: independence (operational, and possibly target independence), credibility and transparency. **Limits**: if rates are at the zero bound, a *liquidity trap* can make further cuts ineffective; long rates may not follow short rates; banks may not lend.

**Policy mix.** Easy fiscal + tight monetary: higher rates, larger government share of output. Tight fiscal + easy monetary: lower rates, larger private-sector share. Both easy: highly expansionary. Both tight: contractionary.""",
"formulas": [
{"name": "Fiscal (spending) multiplier", "tex": r"\text{Multiplier} = \frac{1}{1 - MPC(1-t)}",
 "vars": [["MPC", "marginal propensity to consume"], ["t", "tax rate"]], "note": ""},
{"name": "Money multiplier", "tex": r"\text{Money multiplier} = \frac{1}{\text{reserve requirement}}", "vars": [], "note": ""},
{"name": "Quantity theory of money", "tex": r"M \times V = P \times Y", "vars": [["M", "money supply"], ["V", "velocity"], ["P", "price level"], ["Y", "real output"]], "note": ""},
{"name": "Neutral policy rate", "tex": r"R_{neutral} = \text{trend real growth} + \text{inflation target}", "vars": [], "note": ""},
],
"examples": [
{"title": "Fiscal multiplier",
 "problem": "The MPC is 0.80 and the tax rate is 25%. What is the impact on GDP of a USD 100 billion increase in government spending?",
 "steps": [r"$MPC(1-t) = 0.80 \times 0.75 = 0.60$.", r"Multiplier $= 1/(1-0.60) = 2.5$.", r"$\Delta GDP = 2.5 \times 100 = 250$."],
 "answer": "GDP rises by USD 250 billion (before any crowding-out or Ricardian effects)."},
{"title": "Policy stance",
 "problem": "Trend real growth is 2%, the inflation target is 2% and the policy rate is 3%. What is the stance?",
 "steps": [r"Neutral rate $= 2\% + 2\% = 4\%$.", r"Policy rate of 3% is below neutral."],
 "answer": "Expansionary."},
],
},
{
"id": "geo_trade",
"title": "Geopolitics and International Trade",
"body": r"""**Geopolitics** studies how geography and politics shape relations among countries. Countries are analyzed along two axes: **cooperative vs. non-cooperative** and **globalization vs. nationalism**, giving four archetypes: *autarky* (non-cooperative, nationalist), *hegemony* (non-cooperative, globalist), *bilateralism* (cooperative, nationalist) and *multilateralism* (cooperative, globalist). State actors use **tools**: national security (armed conflict, espionage), economic (sanctions, tariffs, trade agreements) and financial (currency, capital controls, restricting access to markets). Geopolitical risks are classed as *event risk* (elections, known dates), *exogenous risk* (sudden, unanticipated) and *thematic risk* (persistent, e.g. cyber threats). Analysts assess likelihood, velocity (how fast it hits markets) and size of impact.

**Why trade.** **Absolute advantage**: producing a good with fewer resources. **Comparative advantage**: producing a good at a lower *opportunity cost*. Trade gains come from comparative, not absolute, advantage. Ricardian model: comparative advantage comes from labor productivity (technology). Heckscher-Ohlin: comes from relative factor endowments (labor- vs. capital-abundant countries).

**Trade restrictions** and their welfare effects in a small importing country:

- **Tariff**: domestic price rises; domestic producers gain; consumers lose more; government collects revenue; the net effect is a *deadweight loss*.
- **Import quota**: same price effect, but quota rents go to whoever holds the licenses (often foreign exporters), so the national welfare loss can be larger than under an equivalent tariff.
- **Voluntary export restraint (VER)**: imposed by the exporting country; rents go to foreign producers.
- **Export subsidy**: raises domestic price in the exporting country; harms its consumers and taxpayers.

**Trading blocs** (from least to most integrated): free trade area (no internal barriers), customs union (+ common external tariff), common market (+ free movement of labor and capital), economic union (+ common institutions and policies), monetary union (+ common currency).

**Balance of payments.** The **current account** (trade in goods and services, income, transfers) plus the **capital account** (capital transfers, non-produced assets) plus the **financial account** (investment flows) sum to zero. A current account deficit means the country is a net borrower: domestic investment exceeds domestic saving. From national accounts: $(X - M) = (S - I) + (T - G)$, so a trade deficit reflects low private saving, high investment or a fiscal deficit.""",
"formulas": [
{"name": "Current account identity", "tex": r"X - M = (S - I) + (T - G)",
 "vars": [["X - M", "net exports (trade balance)"], ["S - I", "private saving minus investment"], ["T - G", "government budget balance"]], "note": ""},
],
"examples": [
{"title": "Comparative advantage",
 "problem": "Country A can make 10 shirts or 5 phones per worker-day; Country B can make 6 shirts or 1 phone. Who has the comparative advantage in phones?",
 "steps": ["A's opportunity cost of 1 phone = 2 shirts; B's = 6 shirts.", "A has the lower opportunity cost of phones; B has the lower opportunity cost of shirts (1/6 phone vs. 1/2 phone)."],
 "answer": "A should specialize in phones and B in shirts, even though A has an absolute advantage in both."},
],
},
{
"id": "fx",
"title": "Capital Flows, the FX Market and Exchange Rate Calculations",
"body": r"""**Quote convention.** The curriculum writes exchange rates as **A/B = price of one unit of B in units of A**. In USD/EUR = 1.1000, the euro is the **base** currency and the dollar is the **price** currency: one euro costs 1.10 dollars. When this quote **rises**, the base currency (EUR) has **appreciated**.

**Percentage changes are asymmetric.** If USD/EUR moves from 1.10 to 1.15, the euro has appreciated by $1.15/1.10 - 1 = 4.55\%$, but the dollar has depreciated by only $1.10/1.15 - 1 = -4.35\%$ against the euro. Always compute the change of the *base* currency from the quote as given; for the price currency, invert first.

**Cross rates.** Chain quotes so that the unwanted currency cancels: $\text{JPY/EUR} = \text{JPY/USD} \times \text{USD/EUR}$. If both quotes have the unwanted currency in the same position, invert one.

**Forward rates and covered interest rate parity.** A forward rate is set so that a hedged investment in either currency earns the same return (no arbitrage). The currency with the **higher interest rate trades at a forward discount**. Forward points are $F - S$ scaled by 10,000 for most pairs (100 for JPY).

**Real exchange rates** adjust nominal rates for relative price levels: $q_{d/f} = S_{d/f} \times P_f/P_d$. A rising real exchange rate means foreign goods are getting relatively more expensive for domestic buyers.

**Exchange rate regimes** (from most to least rigid): no separate legal tender (dollarization, monetary union), currency board (domestic currency fully backed by a reserve currency), conventional fixed peg, target zone (wider band), crawling peg, managed float, independent float. Fixed regimes give up independent monetary policy (the *impossible trinity*: a country cannot simultaneously have a fixed exchange rate, free capital flows and independent monetary policy).

**Effect of depreciation on the trade balance.** The **Marshall-Lerner condition**: a depreciation improves the trade balance if the export and import demand elasticities (weighted by trade shares) sum to more than one. The **J-curve**: in the short run the trade balance often worsens after a depreciation because import contracts are fixed; it improves as volumes adjust. The **absorption approach**: the trade balance improves only if national income rises relative to domestic spending.

**Capital flows.** Large inflows of short-term capital can create asset bubbles and currency overvaluation; sudden reversals cause crises. Countries respond with capital controls, foreign exchange intervention and macroprudential policy.""",
"formulas": [
{"name": "Cross rate", "tex": r"\frac{A}{C} = \frac{A}{B} \times \frac{B}{C}", "vars": [["A/B", "units of A per one unit of B"]], "note": "The intermediate currency must cancel."},
{"name": "Forward rate (covered interest parity)", "tex": r"F_{f/d} = S_{f/d} \times \frac{1 + i_f\left(\frac{\text{days}}{360}\right)}{1 + i_d\left(\frac{\text{days}}{360}\right)}",
 "vars": [["S_{f/d}", "spot: units of price currency f per unit of base currency d"], ["i_f", "interest rate of the price currency"], ["i_d", "interest rate of the base currency"]],
 "note": "Memory aid: price currency rate on top, base currency rate on the bottom, matching the quote."},
{"name": "Forward premium/discount", "tex": r"F - S = S \times \frac{(i_f - i_d)\frac{\text{days}}{360}}{1 + i_d\frac{\text{days}}{360}}", "vars": [], "note": "If $F > S$, the base currency trades at a forward premium."},
{"name": "Real exchange rate", "tex": r"q_{d/f} = S_{d/f} \times \frac{P_f}{P_d}", "vars": [["P_f, P_d", "foreign and domestic price levels"]], "note": ""},
],
"examples": [
{"title": "Cross rate",
 "problem": "USD/EUR = 1.10 and JPY/USD = 150.00. What is JPY/EUR?",
 "steps": [r"$\text{JPY/EUR} = \text{JPY/USD} \times \text{USD/EUR} = 150.00 \times 1.10$.", "USD cancels."],
 "answer": "165.00 yen per euro."},
{"title": "Forward rate and forward points",
 "problem": "Spot USD/EUR = 1.1000. One-year rates: USD 4%, EUR 2%. Compute the one-year forward and forward points. (For 1-year, days/360 = 1.)",
 "steps": [r"USD is the price currency, EUR the base: $F = 1.1000 \times 1.04/1.02 = 1.1216$.",
           r"Forward points $= (1.1216 - 1.1000) \times 10{,}000 = +216$ (precisely 215.7).",
           r"The euro (lower interest rate) trades at a forward premium, as parity predicts."],
 "answer": "F = 1.1216 USD/EUR; about +216 points."},
{"title": "90-day forward",
 "problem": "Same spot and rates, for a 90-day forward.",
 "steps": [r"$F = 1.1000 \times \dfrac{1 + 0.04(90/360)}{1 + 0.02(90/360)} = 1.1000 \times \dfrac{1.010}{1.005}$."],
 "answer": "1.1055 USD/EUR."},
],
},
],
"pitfalls": [
"Shutdown in the short run only if price < average VARIABLE cost; exit in the long run if price < average TOTAL cost.",
"Monopolistic competition and perfect competition earn zero long-run economic profit.",
"HHI uses squared shares; it reacts to mergers among large firms, the concentration ratio does not.",
"Unemployment is a lagging indicator; the yield curve spread and building permits are leading.",
"A/B: B is the base. A higher quote means the base currency appreciated.",
"Higher interest rate currency trades at a forward DISCOUNT.",
"Fixed exchange rate + free capital flows means no independent monetary policy (impossible trinity).",
"Quota rents may go abroad, making a quota worse for national welfare than an equivalent tariff.",
],
"problems": [
{"id": "x1", "section": "firms", "level": 1,
 "q": "If the price elasticity of demand for a product is -0.4, a price increase will most likely:",
 "choices": {"A": "increase total revenue.", "B": "decrease total revenue.", "C": "leave total revenue unchanged."}, "answer": "A",
 "explanation": "Demand is inelastic (|E| < 1): quantity falls proportionally less than price rises, so revenue increases."},
{"id": "x2", "section": "firms", "level": 2,
 "q": "A firm's price is above average variable cost but below average total cost. In the short run, the firm should:",
 "choices": {"A": "shut down.", "B": "continue operating.", "C": "raise its price to average total cost."}, "answer": "B",
 "explanation": "Operating covers variable costs and part of fixed costs, which are incurred anyway. Exit is a long-run decision."},
{"id": "x3", "section": "firms", "level": 1,
 "q": "Which market structure features many firms, differentiated products, low barriers to entry and zero long-run economic profit?",
 "choices": {"A": "Perfect competition", "B": "Monopolistic competition", "C": "Oligopoly"}, "answer": "B",
 "explanation": "Product differentiation with free entry is monopolistic competition; entry drives economic profit to zero."},
{"id": "x4", "section": "firms", "level": 2,
 "q": "Three firms have market shares of 50%, 30% and 20%. The HHI is closest to:",
 "choices": {"A": "0.33", "B": "0.38", "C": "1.00"}, "answer": "B",
 "explanation": r"$0.25 + 0.09 + 0.04 = 0.38$. C is the 3-firm concentration ratio."},
{"id": "x5", "section": "firms", "level": 2,
 "q": "In the kinked demand curve model of oligopoly, prices tend to be stable because competitors:",
 "choices": {"A": "match price increases but not price cuts.", "B": "match price cuts but not price increases.", "C": "collude to fix prices."}, "answer": "B",
 "explanation": "Raising price loses share (rivals do not follow); cutting price gains little (rivals match). Both discourage price changes."},
{"id": "x6", "section": "cycles", "level": 1,
 "q": "Which of the following is a lagging economic indicator?",
 "choices": {"A": "Building permits", "B": "Average duration of unemployment", "C": "Industrial production"}, "answer": "B",
 "explanation": "Duration of unemployment lags the cycle. Building permits lead; industrial production is coincident."},
{"id": "x7", "section": "cycles", "level": 2,
 "q": "Early in a recovery, firms are most likely to respond to rising demand by:",
 "choices": {"A": "hiring many permanent workers.", "B": "increasing hours of existing workers.", "C": "building new plants."}, "answer": "B",
 "explanation": "Hiring and capex are costly to reverse; firms first add overtime until the recovery looks durable."},
{"id": "x8", "section": "cycles", "level": 2,
 "q": "A consumer price index based on a fixed basket most likely overstates inflation because:",
 "choices": {"A": "consumers substitute toward relatively cheaper goods.", "B": "it excludes food and energy.", "C": "it uses current-period quantities."}, "answer": "A",
 "explanation": "A Laspeyres index ignores substitution away from goods whose prices rose (substitution bias), plus quality and new-product biases."},
{"id": "x9", "section": "policy", "level": 2,
 "q": "With an MPC of 0.9 and a tax rate of 20%, the fiscal multiplier is closest to:",
 "choices": {"A": "3.57", "B": "5.00", "C": "10.00"}, "answer": "A",
 "explanation": r"$1/[1 - 0.9(0.8)] = 1/0.28 = 3.57$. C ignores taxes."},
{"id": "x10", "section": "policy", "level": 1,
 "q": "A central bank purchasing government bonds in the open market will most likely:",
 "choices": {"A": "decrease bank reserves.", "B": "increase bank reserves and the money supply.", "C": "raise short-term interest rates."}, "answer": "B",
 "explanation": "Paying for the bonds credits bank reserves, which supports lending and money creation: expansionary."},
{"id": "x11", "section": "policy", "level": 2,
 "q": "Trend real GDP growth is 2.5% and the inflation target is 2%. A policy rate of 6% is most likely:",
 "choices": {"A": "expansionary.", "B": "neutral.", "C": "contractionary."}, "answer": "C",
 "explanation": "Neutral = 2.5% + 2% = 4.5%. A 6% policy rate is above neutral: contractionary."},
{"id": "x12", "section": "policy", "level": 2,
 "q": "Ricardian equivalence suggests that a debt-financed tax cut will:",
 "choices": {"A": "strongly increase consumption.", "B": "have little effect on consumption because households save it.", "C": "reduce interest rates."}, "answer": "B",
 "explanation": "Households anticipate future taxes to repay the debt and save the tax cut."},
{"id": "x13", "section": "policy", "level": 2,
 "q": "Expansionary fiscal policy combined with restrictive monetary policy most likely leads to:",
 "choices": {"A": "lower interest rates and a smaller public sector.", "B": "higher interest rates and a larger public sector share of GDP.", "C": "lower interest rates and higher private investment."}, "answer": "B",
 "explanation": "Government borrows more while the central bank tightens: rates rise and private investment is crowded out."},
{"id": "x14", "section": "geo_trade", "level": 2,
 "q": "Compared with an equivalent tariff, an import quota is more likely to reduce national welfare of the importing country because:",
 "choices": {"A": "domestic prices rise by more.", "B": "quota rents may be captured by foreign exporters rather than the government.", "C": "domestic producers gain less."}, "answer": "B",
 "explanation": "Under a tariff the government collects revenue. Under a quota, the equivalent rents go to license holders, often foreign."},
{"id": "x15", "section": "geo_trade", "level": 1,
 "q": "A customs union differs from a free trade area in that members:",
 "choices": {"A": "share a common currency.", "B": "adopt a common trade policy toward non-members.", "C": "allow free movement of labor and capital."}, "answer": "B",
 "explanation": "A customs union adds a common external tariff to the free trade area."},
{"id": "x16", "section": "geo_trade", "level": 2,
 "q": "A country runs a large government budget deficit and private saving equals private investment. Its current account is most likely:",
 "choices": {"A": "in surplus.", "B": "in deficit.", "C": "balanced."}, "answer": "B",
 "explanation": r"$X - M = (S - I) + (T - G) = 0 + (\text{negative}) < 0$."},
{"id": "x17", "section": "geo_trade", "level": 2,
 "q": "A country that is cooperative but nationalist, preferring country-to-country agreements, is best described by the geopolitical archetype of:",
 "choices": {"A": "multilateralism.", "B": "bilateralism.", "C": "hegemony."}, "answer": "B",
 "explanation": "Cooperative + nationalist = bilateralism. Cooperative + globalist = multilateralism."},
{"id": "x18", "section": "fx", "level": 2,
 "q": "The CAD/USD rate moves from 1.3000 to 1.3650. The Canadian dollar has:",
 "choices": {"A": "appreciated 5.00% against the USD.", "B": "depreciated 4.76% against the USD.", "C": "depreciated 5.00% against the USD."}, "answer": "B",
 "explanation": r"USD is the base and appreciated 5%. For CAD, invert: $1.3000/1.3650 - 1 = -4.76\%$."},
{"id": "x19", "section": "fx", "level": 2,
 "q": "CAD/USD = 1.35 and USD/EUR = 1.08. The CAD/EUR cross rate is closest to:",
 "choices": {"A": "0.80", "B": "1.25", "C": "1.46"}, "answer": "C",
 "explanation": r"$\text{CAD/EUR} = \text{CAD/USD} \times \text{USD/EUR} = 1.35 \times 1.08 = 1.458$."},
{"id": "x20", "section": "fx", "level": 3,
 "q": "Spot MXN/USD is 18.00. The 180-day MXN rate is 9% and the USD rate is 4% (actual/360). The 180-day forward rate is closest to:",
 "choices": {"A": "17.56", "B": "18.44", "C": "18.87"}, "answer": "B",
 "explanation": r"$F = 18.00 \times (1 + 0.09 \times 0.5)/(1 + 0.04 \times 0.5) = 18.00 \times 1.045/1.020 = 18.44$. The high-rate MXN trades at a forward discount (more pesos per dollar)."},
{"id": "x21", "section": "fx", "level": 2,
 "q": "A country fixes its exchange rate and allows free capital movement. According to the impossible trinity, it must give up:",
 "choices": {"A": "an independent monetary policy.", "B": "fiscal policy.", "C": "current account convertibility."}, "answer": "A",
 "explanation": "With a fixed rate and open capital account, domestic interest rates must follow the anchor currency."},
{"id": "x22", "section": "fx", "level": 2,
 "q": "Following a currency depreciation, a country's trade balance initially worsens and then improves. This pattern is known as:",
 "choices": {"A": "the Marshall-Lerner condition.", "B": "the J-curve effect.", "C": "the absorption approach."}, "answer": "B",
 "explanation": "Existing contracts fix volumes short term, so import costs rise first; volumes adjust later: the J-curve."},
],
}

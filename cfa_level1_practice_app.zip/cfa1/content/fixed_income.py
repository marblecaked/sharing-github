TOPIC = {
"id": "fi",
"name": "Fixed Income",
"weight": "11-14%",
"overview": r"""Fixed income is the most calculation-heavy topic on Level I and one of the largest by weight. It runs from bond features and markets, through pricing and yield measures, the term structure (spot, par and forward rates), interest rate risk (duration and convexity), credit risk and credit analysis, to securitization (ABS and MBS). Core skills: **price a bond from a yield or from spot rates, compute forward rates, compute and use duration and convexity, and reason about credit spreads and prepayment risk.** Your ETF and index background will make the market structure material feel familiar; spend the time on the math.""",
"sections": [
{
"id": "features",
"title": "Features, Cash Flow Structures and Markets",
"body": r"""**Basic features.** Issuer, maturity (tenor), par value, coupon rate and frequency, currency. The **bond indenture** (trust deed) sets out the issuer's obligations, with **affirmative covenants** (what the issuer must do: pay interest, maintain insurance) and **negative covenants** (what it must not do: restrictions on additional debt, asset sales, negative pledges). **Secured** bonds are backed by collateral; **unsecured** debentures by the general credit of the issuer.

**Legal and tax structures.** Bonds are domestic, foreign (issued in another country's currency and market by a foreign issuer), or **Eurobonds** (issued outside the jurisdiction of the currency; usually bearer, lightly regulated). **Special purpose entities** isolate assets for securitization (bankruptcy remote). Original issue discount bonds may have tax effects.

**Cash flow structures.**

- **Bullet**: all principal at maturity. **Amortizing**: principal repaid over the life (fully or partially, with a balloon). **Sinking fund**: principal retired gradually; reduces credit risk but creates reinvestment risk for investors.
- **Floating-rate notes (FRNs)**: coupon = market reference rate (MRR, e.g. SOFR) + quoted margin, reset periodically. Prices stay near par because coupons adjust. Caps protect the issuer; floors protect the investor.
- **Step-up coupons**, **credit-linked coupons** (rise if rating falls), **payment-in-kind** (pays in more bonds), **index-linked bonds** (e.g. inflation-linked: principal or coupon adjusted with CPI), **zero-coupon** bonds (all return from discount), **deferred coupon** bonds.

**Contingency provisions (embedded options).**

- **Callable bond**: issuer may redeem early (typically when rates fall). Investor bears reinvestment risk, so callable bonds have higher yields. $V_{callable} = V_{straight} - V_{call}$. Call protection periods, make-whole calls, American/European/Bermudan exercise.
- **Putable bond**: investor may sell back to the issuer (useful when rates rise). $V_{putable} = V_{straight} + V_{put}$; lower yield.
- **Convertible bond**: investor may convert into shares. Conversion value = conversion ratio $\times$ share price. Lower coupon in exchange for equity upside.

**Issuance and trading.** Primary issuance: underwritten offerings, best-efforts, auctions (government bonds, often single-price), shelf registrations, private placements. Secondary trading is mostly OTC through dealers; liquidity is measured by the bid-ask spread.

**Corporate debt markets.** Short-term funding via **commercial paper** (CP), which is usually backed by liquidity lines, and bank loans. Corporate bonds may be investment grade or high yield. **Government debt**: sovereign bonds (developed vs. emerging; in local or foreign currency), non-sovereign (states, municipals: general obligation vs. revenue bonds), quasi-government and supranational issuers. Sovereign bonds in local currency rarely default because the government can print money (at the cost of inflation).

**Repurchase agreements (repos)**: a sale of a security with a commitment to repurchase it at a higher price; effectively a collateralized loan. The **repo rate** is lower when the collateral is higher quality, the term is shorter, collateral is delivered to the lender, and the collateral is in high demand ("special"). The **haircut** (repo margin) is the excess of collateral value over the loan; it is larger for riskier, longer or less liquid collateral.""",
"formulas": [
{"name": "Floating-rate coupon", "tex": r"\text{Coupon}_t = (\text{MRR}_{t-1} + \text{Quoted margin}) \times \frac{\text{Par}}{m}", "vars": [["MRR", "market reference rate set at the start of the period"], ["m", "payments per year"]], "note": ""},
{"name": "Bonds with embedded options", "tex": r"V_{callable} = V_{straight} - V_{call} \qquad V_{putable} = V_{straight} + V_{put}", "vars": [], "note": ""},
{"name": "Repo interest", "tex": r"\text{Repo interest} = \text{Loan amount} \times \text{Repo rate} \times \frac{\text{days}}{360}", "vars": [], "note": "Loan amount = collateral value / (1 + haircut) or collateral value $\\times$ (1 - haircut), depending on the convention."},
],
"examples": [
{"title": "Callable bond value",
 "problem": "An otherwise identical straight bond is worth 104.20 and the embedded call option is worth 2.10. What is the callable bond worth? What if instead it had a put worth 1.30?",
 "steps": [r"Callable: $104.20 - 2.10 = 102.10$ (the investor has sold a call).", r"Putable: $104.20 + 1.30 = 105.50$ (the investor owns a put)."],
 "answer": "102.10 callable; 105.50 putable."},
],
},
{
"id": "pricing",
"title": "Bond Valuation, Yields and Spreads",
"body": r"""**Pricing with a market discount rate.** The price of a bond is the PV of its coupons and principal at the market discount rate (yield to maturity). Key relationships:

- Price and yield move **inversely**.
- Coupon > yield: premium. Coupon < yield: discount. Coupon = yield: par.
- For a given yield change, **longer-maturity** bonds and **lower-coupon** bonds change more in price.
- Price changes are not symmetric: a yield decrease raises the price by more than an equal increase lowers it (convexity).
- **Constant-yield price trajectory**: discount bonds rise, premium bonds fall, toward par as maturity approaches ("pull to par").

**Yield to maturity** is the IRR of the bond's cash flows. It is the realized return only if the bond is held to maturity, the issuer makes all payments on time, and **coupons are reinvested at the YTM**.

**Between coupon dates.** The **full price** (dirty price, invoice price) = flat price + accrued interest. Quoted prices are **flat (clean)**. Accrued interest = coupon $\times$ (days since last coupon / days in period). Day count conventions: actual/actual for government bonds, 30/360 for corporates.

**Matrix pricing** estimates the yield of an illiquid bond by interpolating from yields on comparable liquid bonds with similar credit quality, coupon and maturity.

**Yield conventions.** Annual-pay vs. semiannual bond-equivalent yields: convert via $(1 + y_{semi}/2)^2 = 1 + y_{annual}$. **Current yield** = annual coupon / flat price (ignores capital gains and reinvestment). For callable bonds, **yield to call** for each call date; **yield to worst** = the lowest of YTM and the yields to each call date. An **option-adjusted spread (OAS)** removes the value of the embedded option from the spread: $OAS = Z\text{-spread} - \text{option cost}$; for callable bonds OAS < Z-spread.

**Spreads.**

- **G-spread**: yield minus the yield of an interpolated government bond of the same maturity.
- **I-spread**: yield minus the swap rate of the same maturity.
- **Z-spread** (zero-volatility): the constant spread added to each point on the government **spot** curve that makes PV equal to price.
- Benchmark spread components: credit risk, liquidity risk and tax effects.

**Money market instruments** (one year or less) are quoted on either a **discount rate** basis (T-bills, CP, bankers' acceptances) or an **add-on** basis (bank CDs, repos, MRR loans). Discount rate quotes understate the true return because they are based on face value, not price, and usually on a 360-day year. To compare, convert both to the same basis.

**Floating-rate notes.** The **quoted margin** is fixed in the contract; the **discount margin** (required margin) is what the market demands now. If the required margin exceeds the quoted margin, the FRN trades at a discount.""",
"formulas": [
{"name": "Bond price", "tex": r"PV = \sum_{t=1}^{N}\frac{PMT}{(1+r)^t} + \frac{FV}{(1+r)^N}", "vars": [["PMT", "coupon per period"], ["r", "market discount rate (YTM) per period"], ["N", "number of periods"], ["FV", "par value"]], "note": "Semiannual: use coupon/2, YTM/2 and 2 x years."},
{"name": "Full price and accrued interest", "tex": r"PV^{Full} = PV \times (1+r)^{t/T} \qquad AI = \frac{t}{T}\times PMT \qquad PV^{Flat} = PV^{Full} - AI",
 "vars": [["PV", "price at the last coupon date"], ["t", "days since last coupon"], ["T", "days in the coupon period"]], "note": ""},
{"name": "Periodicity conversion", "tex": r"\left(1 + \frac{APR_m}{m}\right)^m = \left(1 + \frac{APR_n}{n}\right)^n", "vars": [["APR_m", "annual rate with m compounding periods per year"]], "note": ""},
{"name": "Money market: discount rate basis", "tex": r"PV = FV\left(1 - \frac{\text{Days}}{\text{Year}}\times DR\right)", "vars": [["DR", "discount rate"]], "note": ""},
{"name": "Money market: add-on rate basis", "tex": r"PV = \frac{FV}{1 + \frac{\text{Days}}{\text{Year}}\times AOR} \qquad AOR = \frac{\text{Year}}{\text{Days}}\times\frac{FV - PV}{PV}", "vars": [["AOR", "add-on rate"]], "note": ""},
{"name": "Floating-rate note pricing", "tex": r"PV = \sum_{t=1}^{N}\frac{\frac{(MRR + QM)\times FV}{m}}{\left(1 + \frac{MRR + DM}{m}\right)^t} + \frac{FV}{\left(1 + \frac{MRR + DM}{m}\right)^N}", "vars": [["QM", "quoted margin"], ["DM", "discount (required) margin"]], "note": ""},
],
"examples": [
{"title": "Pricing a premium bond",
 "problem": "A 5-year bond pays a 6% annual coupon. The market discount rate is 5%. Price per 100 of par?",
 "steps": [r"N = 5, I/Y = 5, PMT = 6, FV = 100, CPT PV.", r"$PV = 6 \times 4.3295 + 100/1.05^5 = 25.977 + 78.353 = 104.33$."],
 "answer": "104.33 (premium, because coupon > yield)."},
{"title": "Semiannual discount bond",
 "problem": "A 10-year bond pays a 5% coupon semiannually; the YTM is 6% (semiannual bond basis). Price per 100?",
 "steps": [r"N = 20, I/Y = 3, PMT = 2.5, FV = 100, CPT PV.", r"$PV = 92.56$."],
 "answer": "92.56."},
{"title": "Money market comparison",
 "problem": "A 90-day T-bill is quoted at a 4.00% discount rate (360-day year). What is its price per 100, and its add-on yield on a 365-day basis?",
 "steps": [r"$PV = 100(1 - 90/360 \times 0.04) = 99.00$.", r"$AOR_{365} = (365/90) \times (100 - 99)/99 = 4.10\%$."],
 "answer": "Price 99.00; equivalent add-on yield 4.10%, higher than the quoted 4.00%."},
],
},
{
"id": "termstructure",
"title": "The Term Structure: Spot, Par and Forward Rates",
"body": r"""**Spot rates** are yields on zero-coupon bonds for each maturity. Pricing a coupon bond with the spot curve (discount each cash flow at its own spot rate) gives the **no-arbitrage** price. The YTM of the bond is a kind of weighted average of the spot rates used.

**Par rates** are the coupon rates that would make a bond price exactly at par, given the spot curve. Par curves are derived from on-the-run government bonds. **Bootstrapping** derives spot rates sequentially from par rates.

**Forward rates** are rates agreed today for borrowing or lending in the future. Notation: $f_{A,B-A}$ or "AyBy" is the rate for a $B$-year loan starting in $A$ years (e.g. **1y1y** is a one-year rate starting in one year). Forward rates are implied by spot rates under no arbitrage: investing for two years at the 2-year spot rate must equal investing one year at the 1-year spot rate and rolling into the 1y1y forward.

**Relationships.** When the spot curve is upward sloping, the forward curve lies above it and the par curve lies below it. When the spot curve is flat, all three are equal.

**Theories of the term structure.**

- **Pure (unbiased) expectations theory**: forward rates are unbiased predictors of future spot rates; an upward-sloping curve means rates are expected to rise.
- **Local expectations theory**: over short horizons, all bonds earn the risk-free rate.
- **Liquidity preference theory**: investors demand a term premium for longer maturities, so the curve slopes upward even if rates are expected to stay flat.
- **Segmented markets theory**: separate supply and demand in each maturity segment; no substitution.
- **Preferred habitat theory**: investors prefer certain maturities but will move if compensated.

**Yield curve shapes and movements.** Normal (upward), flat, inverted (often precedes recessions), humped. Changes are decomposed into **level** (parallel shift), **slope** (steepening/flattening) and **curvature**. A **bull flattening** has long rates falling more than short; a **bear steepening** has long rates rising more than short.""",
"formulas": [
{"name": "Price using spot rates", "tex": r"PV = \frac{PMT}{(1+Z_1)^1} + \frac{PMT}{(1+Z_2)^2} + \dots + \frac{PMT + FV}{(1+Z_N)^N}", "vars": [["Z_t", "spot rate for maturity t"]], "note": ""},
{"name": "Implied forward rate", "tex": r"(1+Z_A)^A \times (1 + f_{A,B-A})^{B-A} = (1+Z_B)^B", "vars": [["Z_A, Z_B", "spot rates for A and B years"], ["f_{A,B-A}", "forward rate for B - A years starting in A years"]], "note": ""},
{"name": "Par rate from spot rates", "tex": r"1 = \frac{PMT}{(1+Z_1)} + \frac{PMT}{(1+Z_2)^2} + \dots + \frac{PMT + 1}{(1+Z_N)^N}", "vars": [["PMT", "par coupon rate (per 1 of par)"]], "note": ""},
],
"examples": [
{"title": "Pricing with spot rates",
 "problem": "Spot rates are 3% (1y), 4% (2y), 5% (3y). Price a 3-year 5% annual-coupon bond per 100 and find its YTM.",
 "steps": [r"$5/1.03 + 5/1.04^2 + 105/1.05^3 = 4.854 + 4.623 + 90.703 = 100.18$.",
           r"Solve N = 3, PV = -100.18, PMT = 5, FV = 100 for I/Y: 4.93%."],
 "answer": "Price 100.18; YTM 4.93%, a blend of the spot rates weighted toward the 3-year rate."},
{"title": "Implied forward rates",
 "problem": "Using the same spot rates, compute the 1y1y and the 1y2y forward rates.",
 "steps": [r"1y1y: $1.04^2/1.03 - 1 = 5.01\%$.", r"1y2y: $(1.05^3/1.03)^{1/2} - 1 = 6.01\%$."],
 "answer": "1y1y = 5.01%; 1y2y = 6.01%. With an upward-sloping spot curve, forwards are above spot rates."},
],
},
{
"id": "duration",
"title": "Interest Rate Risk: Duration and Convexity",
"body": r"""**Two opposing risks.** If rates rise, bond prices fall (**market price risk**), but coupons are reinvested at higher rates (**reinvestment risk** works in your favor). Over a short horizon price risk dominates; over a long horizon reinvestment dominates. They roughly offset when the **investment horizon equals the Macaulay duration**: this is the basis of immunization. A **duration gap** = Macaulay duration - investment horizon. A positive gap means price risk dominates (the investor is hurt by rising rates).

**Macaulay duration** is the weighted average time to receipt of the bond's cash flows, weights being the share of price each cash flow represents.

**Modified duration** estimates the percentage price change for a 1% (100 bp) change in yield. **Approximate modified duration** is computed by repricing the bond for a small yield shift up and down, and works for bonds with embedded options too (as *effective duration*, when the yield shift is a shift in the benchmark curve).

**Effective duration** must be used for bonds with embedded options, because their cash flows change when rates change. Callable bonds have **negative convexity** at low yields: the price is capped near the call price, so price gains are limited when yields fall. Putable bonds have more positive convexity than straight bonds.

**Properties of duration** (for option-free bonds):

- Longer maturity: higher duration (generally).
- Higher coupon: lower duration.
- Higher yield: lower duration.
- Zero-coupon bond: Macaulay duration = maturity.
- Floating-rate note: duration roughly equals time to the next reset.
- Callable bonds: lower effective duration than straight bonds; putables: lower too.

**Key rate duration** measures sensitivity to a change at one point of the curve (for non-parallel shifts).

**Portfolio duration** is approximately the market-value-weighted average of the bond durations.

**Money duration and PVBP.** Money duration converts duration into currency: $\text{ModDur} \times \text{full price}$. The **price value of a basis point (PVBP)** is the money change for a 1 bp yield change.

**Convexity.** Duration is a linear approximation; the true price-yield curve is convex. Adding the convexity adjustment improves the estimate for large yield changes. Option-free bonds always have positive convexity, which helps investors: prices rise more than duration predicts when yields fall, and fall less when yields rise. Convexity is higher for longer maturities, lower coupons, lower yields and more dispersed cash flows.

**Credit and liquidity.** Duration can be split into sensitivity to the benchmark yield and to the spread; for option-free bonds they are the same. Changes in credit quality or liquidity show up as spread changes.""",
"formulas": [
{"name": "Macaulay duration", "tex": r"MacDur = \sum_{t=1}^{N} t \times \frac{CF_t/(1+r)^t}{PV}", "vars": [["CF_t", "cash flow at period t"], ["PV", "bond price"]], "note": "Measured in periods; divide by periods per year for years."},
{"name": "Modified duration", "tex": r"ModDur = \frac{MacDur}{1 + r}", "vars": [["r", "yield per period"]], "note": ""},
{"name": "Approximate modified duration", "tex": r"ApproxModDur = \frac{PV_- - PV_+}{2 \times \Delta Yield \times PV_0}", "vars": [["PV_-", "price when yield falls by $\\Delta Yield$"], ["PV_+", "price when yield rises by $\\Delta Yield$"]], "note": "Effective duration has the same form with $\\Delta Curve$."},
{"name": "Approximate convexity", "tex": r"ApproxCon = \frac{PV_- + PV_+ - 2PV_0}{(\Delta Yield)^2 \times PV_0}", "vars": [], "note": ""},
{"name": "Estimated percentage price change", "tex": r"\%\Delta PV \approx -ModDur \times \Delta Yield + \tfrac{1}{2}\times Convexity \times (\Delta Yield)^2", "vars": [["\\Delta Yield", "change in yield as a decimal (100 bp = 0.01)"]], "note": ""},
{"name": "Money duration and PVBP", "tex": r"MoneyDur = ModDur \times PV^{Full} \qquad PVBP = \frac{PV_- - PV_+}{2}", "vars": [["PV_-, PV_+", "prices for a 1 bp decrease and increase"]], "note": ""},
],
"examples": [
{"title": "Macaulay and modified duration",
 "problem": "Compute the Macaulay and modified duration of a 3-year, 5% annual-coupon bond priced at par (YTM 5%).",
 "steps": [r"PVs of cash flows: $5/1.05 = 4.7619$; $5/1.05^2 = 4.5351$; $105/1.05^3 = 90.7029$; total 100.",
           r"$MacDur = (1 \times 4.7619 + 2 \times 4.5351 + 3 \times 90.7029)/100 = 2.8594$ years.",
           r"$ModDur = 2.8594/1.05 = 2.7232$."],
 "answer": "MacDur 2.86 years; ModDur 2.72: a 1% rise in yield cuts the price by about 2.72%."},
{"title": "Duration plus convexity",
 "problem": "A 10-year 6% annual bond at a 5% YTM is priced at 107.72. Repricing at 4.9% and 5.1% gives an approximate modified duration of 7.52 and convexity of 72.17. Estimate the price change for a 100 bp rise in yield.",
 "steps": [r"Duration effect: $-7.52 \times 0.01 = -7.52\%$.",
           r"Convexity effect: $0.5 \times 72.17 \times 0.01^2 = +0.36\%$.",
           r"Estimate: $-7.16\%$. Actual: price at 6% is 100.00, a change of $-7.17\%$."],
 "answer": "About -7.16%; adding convexity brings the estimate within 0.01% of the true change."},
],
},
{
"id": "credit",
"title": "Credit Risk and Credit Analysis",
"body": r"""**Components of credit risk.** **Default risk** (probability of default, PD) and **loss severity** (loss given default, LGD = 1 - recovery rate). **Expected loss = PD $\times$ LGD.** Credit spreads also compensate for **spread risk**: *credit migration (downgrade) risk* and *market liquidity risk*.

**Seniority and recovery.** In order of priority: first lien / senior secured, second lien, senior unsecured, senior subordinated, subordinated, junior subordinated. Recovery rates fall down the ranking. **Pari passu** claims share equally. In practice, the **absolute priority rule** is sometimes violated in reorganizations.

**Credit ratings.** Investment grade is BBB-/Baa3 and above; below that is high yield ("junk"). Issuer ratings apply to senior unsecured debt; issue ratings may be **notched** up or down for seniority and collateral (more notching for lower-rated issuers). Ratings lag market prices, may be wrong, and can change suddenly (event risk: LBOs, litigation, natural disasters).

**The four Cs of credit analysis (traditionally).**

- **Capacity**: ability to repay from cash flow (industry, competitive position, operating history, management).
- **Collateral**: quality and value of pledged assets.
- **Covenants**: protection for lenders.
- **Character**: management's integrity and track record (including its treatment of bondholders).

**Key credit ratios.** Profitability and cash flow (EBITDA, FFO, FCF), **leverage** (debt/capital, debt/EBITDA, FFO/debt), and **coverage** (EBITDA/interest, EBIT/interest). Higher leverage and lower coverage mean weaker credit.

**Sovereign credit analysis** considers institutional and economic factors (government effectiveness, rule of law, GDP per capita, growth prospects), fiscal flexibility (debt/GDP, interest burden), monetary flexibility, and external status (reserve currency, external debt). Local-currency ratings are usually higher than foreign-currency ratings.

**Spreads over the cycle.** Credit spreads widen in recessions and narrow in expansions, and high-yield spreads move more than investment-grade spreads. A bond's price change from a spread change is approximately $-\text{ModDur} \times \Delta\text{spread}$ plus convexity.

**High-yield analysis** stresses liquidity and debt structure, corporate structure (holding company debt is *structurally subordinated* to operating company debt), and the covenants (change of control, restricted payments).""",
"formulas": [
{"name": "Expected loss", "tex": r"EL = PD \times LGD \qquad LGD = (1 - RR) \times EAD", "vars": [["PD", "probability of default"], ["RR", "recovery rate"], ["EAD", "exposure at default"]], "note": "As a yield spread: approximate spread $\\approx PD \\times (1 - RR)$."},
{"name": "Price impact of a spread change", "tex": r"\%\Delta PV \approx -ModDur \times \Delta\text{Spread} + \tfrac{1}{2}\times Con \times (\Delta\text{Spread})^2", "vars": [], "note": ""},
{"name": "Leverage and coverage", "tex": r"\frac{\text{Debt}}{EBITDA} \qquad \frac{FFO}{\text{Debt}} \qquad \frac{EBITDA}{\text{Interest}}", "vars": [["FFO", "funds from operations"]], "note": ""},
],
"examples": [
{"title": "Expected loss and spread",
 "problem": "A USD 1,000,000 bond has a 2% annual probability of default and a 40% recovery rate. Compute the expected loss and the approximate credit spread that compensates for it.",
 "steps": [r"LGD $= (1 - 0.40) \times 1{,}000{,}000 = 600{,}000$.", r"$EL = 0.02 \times 600{,}000 = 12{,}000$ per year.", r"Spread $\approx 0.02 \times 0.60 = 1.20\%$."],
 "answer": "Expected loss USD 12,000 (1.20%), so a spread of at least about 120 bp."},
],
},
{
"id": "securitization",
"title": "Securitization, ABS and MBS",
"body": r"""**Securitization** pools assets (loans, receivables) and sells claims on their cash flows. A **special purpose entity (SPE)** buys the assets from the originator (the *seller* or *depositor*) and issues securities; because the SPE is bankruptcy remote, its credit rating can exceed the originator's. Benefits: it frees bank capital, improves liquidity, gives investors direct access to diversified pools, and can lower funding costs. The **servicer** collects payments.

**Credit enhancement.**

- **Internal**: **subordination** (senior/subordinated tranches; the junior tranches absorb losses first: a *waterfall*), **overcollateralization** (collateral exceeds the securities issued), **excess spread** (interest received exceeds interest paid; builds a reserve).
- **External**: third-party guarantees, letters of credit, bond insurance (exposes investors to the guarantor's credit).

**Prepayment risk** is the defining risk of mortgage securities. Borrowers prepay when rates fall (to refinance), returning principal when reinvestment rates are low: **contraction risk**. When rates rise, prepayments slow and the security lasts longer just when investors would like their money back: **extension risk**. This gives mortgage securities negative convexity.

**Residential MBS.** Agency RMBS are guaranteed by government agencies or GSEs (Ginnie Mae, Fannie Mae, Freddie Mac); non-agency RMBS rely on credit enhancement. Mortgage features: amortizing payments, fixed or adjustable rates, prepayment penalties, recourse vs. non-recourse loans (in a non-recourse loan the lender can only seize the property). **Loan-to-value (LTV)** and **debt-to-income** ratios measure credit risk.

**Measuring prepayments.** The **single monthly mortality rate (SMM)** is the share of remaining principal prepaid in a month; the **conditional prepayment rate (CPR)** annualizes it: $CPR = 1 - (1 - SMM)^{12}$. The PSA benchmark ramps CPR from 0.2% in month 1 to 6% at month 30. **Weighted average life (WAL)** is the average time to receipt of principal.

**Collateralized mortgage obligations (CMOs)** redistribute prepayment risk among tranches:

- **Sequential-pay**: tranches receive principal in order; short tranches have more contraction protection, long tranches more extension protection.
- **PAC/support**: the **planned amortization class** tranche gets a schedule that holds within a range of prepayment speeds; the **support (companion)** tranche absorbs the variation, so it has the most prepayment risk.
- **Floaters and inverse floaters** split a fixed-rate tranche.

**Commercial MBS** are backed by income-producing property loans, usually **non-recourse**, so credit analysis focuses on the property: **debt service coverage ratio** (NOI / debt service) and LTV. CMBS have **call protection** at the loan level (prepayment lockouts, defeasance, yield maintenance, prepayment penalty points) and at the structure level. Loans often have **balloon payments**, creating balloon (refinancing) risk.

**Non-mortgage ABS**: auto loans (amortizing), credit card receivables (non-amortizing, with a **lockout/revolving period** during which principal repayments buy new receivables, followed by amortization; early amortization triggers). **Collateralized debt obligations (CDOs)** and **CLOs** pool corporate loans or bonds and are actively managed; the equity tranche earns the residual.

**Covered bonds** are senior debt of a bank backed by a segregated pool (the cover pool) that stays on the bank's balance sheet. Investors have **dual recourse**: to the issuer and to the cover pool. The issuer must replace non-performing assets, so covered bonds typically have lower credit risk and lower yields than comparable ABS.""",
"formulas": [
{"name": "Prepayment rates", "tex": r"SMM = \frac{\text{Prepayment in month}}{\text{Beginning balance} - \text{Scheduled principal}} \qquad CPR = 1 - (1 - SMM)^{12}", "vars": [], "note": ""},
{"name": "Loan-to-value and DSCR", "tex": r"LTV = \frac{\text{Loan amount}}{\text{Property value}} \qquad DSCR = \frac{NOI}{\text{Debt service}}", "vars": [["NOI", "net operating income"]], "note": "Lower LTV and higher DSCR mean lower credit risk."},
],
"examples": [
{"title": "Which tranche?",
 "problem": "An investor wants the most protection against both contraction and extension risk in a CMO with a PAC tranche and a support tranche. Which should she buy?",
 "steps": ["The PAC tranche has a principal schedule that holds within its prepayment collar.", "The support tranche absorbs both faster and slower prepayments."],
 "answer": "The PAC tranche; the support tranche bears most of the prepayment risk (and offers a higher yield for it)."},
],
},
],
"pitfalls": [
"Coupon > YTM: premium. Lower coupon or longer maturity: larger price change for a yield change.",
"Quoted prices are flat (clean); you pay the full (dirty) price = flat + accrued interest.",
"Upward-sloping spot curve: forward curve above spot, par curve below spot.",
"Use EFFECTIVE duration for bonds with embedded options. Callables show negative convexity at low yields.",
"Zero-coupon: Macaulay duration = maturity. FRN duration is about the time to the next reset.",
"Horizon = Macaulay duration means price risk and reinvestment risk offset.",
"OAS = Z-spread - option cost. For callables, OAS < Z-spread.",
"Rates fall: prepayments speed up (contraction risk). Rates rise: extension risk.",
"Support tranches carry the prepayment risk that PAC tranches shed.",
"Covered bonds give dual recourse and stay on the issuer's balance sheet.",
"Expected loss = PD x LGD; LGD = (1 - recovery rate) x exposure.",
],
"problems": [
{"id": "b1", "section": "features", "level": 1,
 "q": "A covenant that prohibits the issuer from pledging assets already securing the bond to other lenders is a(n):",
 "choices": {"A": "affirmative covenant.", "B": "negative covenant.", "C": "sinking fund provision."}, "answer": "B",
 "explanation": "A negative pledge clause is a negative covenant: it restricts what the issuer may do."},
{"id": "b2", "section": "features", "level": 2,
 "q": "Compared with an otherwise identical option-free bond, a putable bond will have:",
 "choices": {"A": "a higher price and lower yield.", "B": "a lower price and higher yield.", "C": "the same price."}, "answer": "A",
 "explanation": "The investor owns the put: $V_{putable} = V_{straight} + V_{put}$."},
{"id": "b3", "section": "features", "level": 2,
 "q": "An FRN pays SOFR + 1.50%. If its required (discount) margin rises to 2.00%, the FRN will most likely trade:",
 "choices": {"A": "at par.", "B": "at a premium.", "C": "at a discount."}, "answer": "C",
 "explanation": "Required margin > quoted margin: coupons are too low for the current credit risk, so price falls below par."},
{"id": "b4", "section": "features", "level": 2,
 "q": "All else equal, the repo rate is most likely to be lower when:",
 "choices": {"A": "the collateral is in high demand (special).", "B": "the repo term is longer.", "C": "the collateral is held by the borrower rather than delivered."}, "answer": "A",
 "explanation": "Lenders accept a lower rate to obtain special collateral. Longer terms and non-delivery raise the rate."},
{"id": "b5", "section": "pricing", "level": 1,
 "q": "A 3-year bond with a 4% annual coupon is priced at a yield of 6%. Its price per 100 of par is closest to:",
 "choices": {"A": "94.65", "B": "100.00", "C": "105.35"}, "answer": "A",
 "explanation": r"$4/1.06 + 4/1.06^2 + 104/1.06^3 = 3.774 + 3.560 + 87.320 = 94.65$."},
{"id": "b6", "section": "pricing", "level": 2,
 "q": "Holding the yield constant, as a discount bond approaches maturity its price will:",
 "choices": {"A": "decrease toward par.", "B": "increase toward par.", "C": "remain unchanged."}, "answer": "B",
 "explanation": "Pull to par: discount bonds accrete up to par; premium bonds amortize down."},
{"id": "b7", "section": "pricing", "level": 2,
 "q": "A YTM of 6% quoted on a semiannual bond basis is equivalent to an annual-pay yield of:",
 "choices": {"A": "5.91%", "B": "6.00%", "C": "6.09%"}, "answer": "C",
 "explanation": r"$(1.03)^2 - 1 = 6.09\%$."},
{"id": "b8", "section": "pricing", "level": 2,
 "q": "The constant spread over the government spot curve that equates the PV of a bond's cash flows to its price is the:",
 "choices": {"A": "G-spread.", "B": "Z-spread.", "C": "I-spread."}, "answer": "B",
 "explanation": "Z-spread uses the whole spot curve; the G-spread uses a single government yield and the I-spread uses swap rates."},
{"id": "b9", "section": "pricing", "level": 2,
 "q": "For a callable bond, the option-adjusted spread is:",
 "choices": {"A": "greater than the Z-spread.", "B": "less than the Z-spread.", "C": "equal to the Z-spread."}, "answer": "B",
 "explanation": "OAS = Z-spread - option cost. The call option has positive cost to the investor."},
{"id": "b10", "section": "pricing", "level": 2,
 "q": "A 180-day commercial paper note is quoted at a 5% discount rate (360-day year). Its price per 100 is:",
 "choices": {"A": "97.50", "B": "97.56", "C": "95.00"}, "answer": "A",
 "explanation": r"$100(1 - 180/360 \times 0.05) = 97.50$. B treats the quote as an add-on rate: $100/1.025 = 97.56$."},
{"id": "b11", "section": "termstructure", "level": 2,
 "q": "The 1-year spot rate is 2% and the 2-year spot rate is 3%. The 1y1y forward rate is closest to:",
 "choices": {"A": "2.50%", "B": "4.01%", "C": "3.00%"}, "answer": "B",
 "explanation": r"$1.03^2/1.02 - 1 = 1.0609/1.02 - 1 = 4.01\%$."},
{"id": "b12", "section": "termstructure", "level": 2,
 "q": "If the spot curve is upward sloping, the par curve will be:",
 "choices": {"A": "above the spot curve.", "B": "below the spot curve.", "C": "identical to the spot curve."}, "answer": "B",
 "explanation": "Par rates are averages that include the lower early spot rates, so they lie below the spot curve; forwards lie above."},
{"id": "b13", "section": "termstructure", "level": 2,
 "q": "Which theory holds that the yield curve slopes upward because investors demand a premium for holding longer maturities, even if rates are not expected to rise?",
 "choices": {"A": "Pure expectations", "B": "Liquidity preference", "C": "Segmented markets"}, "answer": "B",
 "explanation": "Liquidity preference adds a term premium to expected rates."},
{"id": "b14", "section": "termstructure", "level": 2,
 "q": "Short-term yields rise by 50 bp while long-term yields rise by 10 bp. This is best described as a:",
 "choices": {"A": "bear flattening.", "B": "bear steepening.", "C": "bull flattening."}, "answer": "A",
 "explanation": "Rates rising (bear) with the spread between long and short narrowing (flattening)."},
{"id": "b15", "section": "duration", "level": 2,
 "q": "A bond has modified duration 6.0 and convexity 50. For a 200 bp decrease in yield, the estimated percentage price change is closest to:",
 "choices": {"A": "+11.0%", "B": "+12.0%", "C": "+13.0%"}, "answer": "C",
 "explanation": r"$-6.0 \times (-0.02) + 0.5 \times 50 \times 0.02^2 = 12.0\% + 1.0\% = 13.0\%$."},
{"id": "b16", "section": "duration", "level": 2,
 "q": "A bond priced at 100 rises to 100.85 if yields fall 10 bp and falls to 99.17 if yields rise 10 bp. Its approximate modified duration is:",
 "choices": {"A": "4.2", "B": "8.4", "C": "16.8"}, "answer": "B",
 "explanation": r"$(100.85 - 99.17)/(2 \times 0.001 \times 100) = 1.68/0.2 = 8.4$."},
{"id": "b17", "section": "duration", "level": 2,
 "q": "Which bond has the highest duration?",
 "choices": {"A": "10-year, 8% coupon", "B": "10-year, zero coupon", "C": "5-year, zero coupon"}, "answer": "B",
 "explanation": "A 10-year zero has Macaulay duration of 10 years; coupons shorten duration."},
{"id": "b18", "section": "duration", "level": 2,
 "q": "An investor with a 5-year horizon holds a bond with a Macaulay duration of 8 years. Her main exposure is to:",
 "choices": {"A": "rising rates, through market price risk.", "B": "falling rates, through reinvestment risk.", "C": "neither, the risks offset."}, "answer": "A",
 "explanation": "Duration gap = 8 - 5 = +3 > 0: price risk dominates, so rising rates hurt."},
{"id": "b19", "section": "duration", "level": 2,
 "q": "A bond's modified duration is 7.2 and its full price is USD 1,050,000. The money duration and the approximate PVBP are closest to:",
 "choices": {"A": "7,560,000 and 756", "B": "75,600 and 7.56", "C": "7,560,000 and 75.6"}, "answer": "A",
 "explanation": r"Money duration $= 7.2 \times 1{,}050{,}000 = 7{,}560{,}000$. PVBP $\approx 7{,}560{,}000 \times 0.0001 = 756$."},
{"id": "b20", "section": "duration", "level": 2,
 "q": "For a callable bond when yields are low and near the call price, convexity is most likely:",
 "choices": {"A": "positive and larger than a straight bond's.", "B": "negative.", "C": "zero."}, "answer": "B",
 "explanation": "Price appreciation is capped by the call: negative convexity."},
{"id": "b21", "section": "credit", "level": 2,
 "q": "A bond has a 3% probability of default and a 45% recovery rate. Its expected loss as a percentage of exposure is:",
 "choices": {"A": "1.35%", "B": "1.65%", "C": "3.00%"}, "answer": "B",
 "explanation": r"$0.03 \times (1 - 0.45) = 1.65\%$. A uses the recovery rate instead of LGD."},
{"id": "b22", "section": "credit", "level": 2,
 "q": "Notching of an issue's rating relative to the issuer rating is most likely to be greater for:",
 "choices": {"A": "investment-grade issuers.", "B": "high-yield issuers.", "C": "sovereign issuers."}, "answer": "B",
 "explanation": "With higher default risk, recovery (driven by seniority) matters more, so notching is wider."},
{"id": "b23", "section": "credit", "level": 2,
 "q": "Debt of a holding company whose cash flows come from dividends of operating subsidiaries with their own debt is:",
 "choices": {"A": "structurally subordinated.", "B": "senior secured.", "C": "pari passu with the subsidiary debt."}, "answer": "A",
 "explanation": "Subsidiary creditors are paid before cash flows up to the parent."},
{"id": "b24", "section": "credit", "level": 2,
 "q": "A bond with modified duration 5.0 experiences a 40 bp widening of its credit spread. Ignoring convexity, its price change is about:",
 "choices": {"A": "-0.2%", "B": "-2.0%", "C": "-4.0%"}, "answer": "B",
 "explanation": r"$-5.0 \times 0.0040 = -2.0\%$."},
{"id": "b25", "section": "securitization", "level": 1,
 "q": "Which is an internal credit enhancement?",
 "choices": {"A": "A letter of credit.", "B": "Overcollateralization.", "C": "A third-party guarantee."}, "answer": "B",
 "explanation": "Overcollateralization, subordination and excess spread are internal."},
{"id": "b26", "section": "securitization", "level": 2,
 "q": "When interest rates fall sharply, holders of mortgage pass-through securities most likely face:",
 "choices": {"A": "extension risk.", "B": "contraction risk.", "C": "lower prepayments."}, "answer": "B",
 "explanation": "Refinancing accelerates prepayments, shortening the security when reinvestment rates are low."},
{"id": "b27", "section": "securitization", "level": 2,
 "q": "In a CMO with PAC and support tranches, the tranche that bears the most prepayment risk is the:",
 "choices": {"A": "PAC tranche.", "B": "support tranche.", "C": "senior sequential tranche."}, "answer": "B",
 "explanation": "The support tranche absorbs deviations from the PAC schedule."},
{"id": "b28", "section": "securitization", "level": 2,
 "q": "Compared with an ABS backed by similar assets, a covered bond most likely has:",
 "choices": {"A": "higher credit risk because assets remain on the issuer's balance sheet.", "B": "lower credit risk because investors have recourse to both the issuer and the cover pool.", "C": "no recourse to the issuer."}, "answer": "B",
 "explanation": "Dual recourse plus the obligation to replace non-performing assets lowers credit risk."},
{"id": "b29", "section": "securitization", "level": 2,
 "q": "A commercial property generates NOI of USD 1.5 million; annual debt service is USD 1.2 million. The DSCR is:",
 "choices": {"A": "0.80x", "B": "1.25x", "C": "1.50x"}, "answer": "B",
 "explanation": r"$1.5/1.2 = 1.25\times$."},
],
}

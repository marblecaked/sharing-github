TOPIC = {
"id": "ethics",
"name": "Ethical and Professional Standards",
"weight": "15-20%",
"overview": r"""Ethics is the single heaviest topic on Level I, and it carries extra weight beyond its share: CFA Institute has historically used ethics performance as a tie-breaker for candidates near the minimum passing score. Questions are almost all short scenarios that ask *whether* a standard was violated, *which* standard, or *what the member should do*.

The tested material is the Code of Ethics, the seven Standards of Professional Conduct (Standards of Practice Handbook, 12th edition, effective 1 January 2024), an ethical decision-making framework, and an introduction to the Global Investment Performance Standards (GIPS). There are no formulas. What earns points is knowing the *exact* requirement of each standard and the handful of rules of thumb the Handbook uses to resolve close calls.

**The 2024 revision** added Standard I(E) Competence, renamed VI(A) to "Avoid or Disclose Conflicts" (with disclosures that must be prominent and in plain language), and expanded V(B) to require disclosing the nature of services and their costs to clients.""",
"sections": [
{
"id": "framework",
"title": "Ethics, Trust and the Code of Ethics",
"body": r"""**Why ethics matters in investment management.** Clients cannot easily observe the quality of advice or execution; they rely on trust. Ethical lapses destroy that trust, raise the cost of capital, and invite heavier regulation. Rules and laws set a floor, but *ethical conduct often requires more than the law*: something can be legal and still unethical.

**Challenges to ethical behavior.** People overestimate their own ethics (overconfidence), give heavy weight to short-term rewards, and are strongly shaped by **situational influences** (peer pressure, loyalty to the firm, bonuses). Good firms design processes that counter these influences.

**The ethical decision-making framework.**

1. **Identify**: the relevant facts, the stakeholders and duties owed, ethical principles involved, and any conflicts of interest.
2. **Consider**: situational influences, additional guidance (compliance, colleagues, mentors), alternative actions.
3. **Decide and act.**
4. **Reflect**: was the outcome as expected? What would you do differently?

**The Code of Ethics.** Members of CFA Institute and candidates must:

- Act with integrity, competence, diligence and respect, and in an ethical manner with the public, clients, prospective clients, employers, employees, colleagues in the investment profession and other participants in the global capital markets.
- Place the integrity of the investment profession and the interests of clients above their own personal interests.
- Use reasonable care and exercise independent professional judgment when conducting investment analysis, making investment recommendations, taking investment actions and engaging in other professional activities.
- Practice and encourage others to practice in a professional and ethical manner that will reflect credit on themselves and the profession.
- Promote the integrity and viability of the global capital markets for the ultimate benefit of society.
- Maintain and improve their professional competence and strive to maintain and improve the competence of other investment professionals.

**Professional Conduct Program (PCP).** Investigations start from self-disclosure on the annual Professional Conduct Statement, written complaints, media reports, or exam proctor reports. Sanctions range from a private censure to public censure, suspension or revocation of membership and the right to use the designation. A member may cooperate with a PCP inquiry without breaching client confidentiality.

**Priority of duties.** When duties conflict, the order is: (1) obey the law and the Code and Standards, (2) clients, (3) employer, (4) yourself.""",
"formulas": [],
"examples": [
{"title": "Applying the framework",
 "problem": "Your firm's sales head asks you to raise your target price on a stock because the firm is bidding to underwrite the issuer's next bond deal. Walk through the framework.",
 "steps": ["Identify: facts (pressure tied to banking business), stakeholders (clients who rely on research, the issuer, your firm), principles (independence and objectivity), the conflict (investment banking vs. research).",
           "Consider: situational influence (career pressure), guidance (compliance, research management), alternatives (keep the rating; explain your analysis; escalate to compliance).",
           "Act: maintain your analysis; if pressured, escalate; do not publish a view you do not hold.",
           "Reflect: would a firewall between banking and research have prevented the request?"],
 "answer": "Keep the independent rating. Changing it would violate Standard I(B) Independence and Objectivity."},
],
},
{
"id": "std1",
"title": "Standard I: Professionalism",
"body": r"""**I(A) Knowledge of the Law.** Understand and comply with all applicable laws, rules and regulations, including the Code and Standards. **When law and the Code conflict, follow the stricter.** Do not knowingly participate in or assist violations by others; if you become aware of one, **dissociate** (which may mean refusing an assignment or even leaving the firm). Reporting to authorities is not required by the Standards, though it may be advisable or legally required; first escalate to supervisors or compliance.

**I(B) Independence and Objectivity.** Do not offer, solicit or accept any gift, benefit or compensation that could reasonably be expected to compromise your own or another's independence. Key rules:

- **Gifts from clients** (e.g. a reward for good past performance) may be accepted but must be **disclosed to the employer**. A *bonus tied to future performance* is additional compensation and requires written consent (Standard IV(B)).
- **Gifts from third parties** seeking to influence you (brokers, issuers) should be of minimal value; firms set a limit.
- **Issuer-paid research**: the fee must be a flat fee, not linked to the conclusions, and the arrangement must be disclosed.
- **Travel**: pay for your own commercial transport and hotel when visiting a company where practical; avoid lavish hospitality.
- Buy-side pressure on sell-side analysts and corporate pressure on credit ratings are both covered.

**I(C) Misrepresentation.** Do not knowingly misrepresent investment analysis, recommendations, actions or professional activities. This covers **plagiarism** (using others' work, models or wording without attribution), guaranteeing returns on inherently risky investments, misstating qualifications or firm services, and omissions that mislead. Stating that an investment has a guaranteed return is acceptable only when it truly is guaranteed (e.g. a government-insured deposit) or structured to guarantee principal, with the structure disclosed.

**I(D) Misconduct.** No professional conduct involving dishonesty, fraud or deceit, and no act that reflects adversely on your professional reputation, integrity or competence. Personal behavior such as civil disobedience is generally not covered; repeated intoxication at work or lying on an expense report is.

**I(E) Competence** (new in 2024). Act with and maintain the competence needed to fulfill your professional responsibilities. If a task is outside your expertise, acquire the knowledge, get help, or decline it. This makes explicit the Code's existing competence requirement.""",
"formulas": [],
"examples": [
{"title": "Stricter rule",
 "problem": "A member works in Country A, where insider trading laws only cover corporate insiders. She learns material nonpublic information about a takeover from a friend at an investment bank. May she trade?",
 "steps": ["Local law permits the trade because she is not an insider.", "The Code (II(A)) prohibits acting on any material nonpublic information.", "Rule: apply the stricter of local law and the Code."],
 "answer": "No. The stricter rule (the Code) applies."},
],
},
{
"id": "std2_3",
"title": "Standards II and III: Capital Markets and Duties to Clients",
"body": r"""**II(A) Material Nonpublic Information.** Do not act, or cause others to act, on information that is both **material** (would likely affect the price, or a reasonable investor would want it) and **nonpublic** (not yet disseminated to the market). The **mosaic theory** allows conclusions drawn from public information combined with *non-material* nonpublic information, even if the conclusion is something insiders know. Firms should use **firewalls**, restricted and watch lists, and review of employee trading. If you receive MNPI, encourage the issuer to make public disclosure; do not trade on it.

**II(B) Market Manipulation.** No practices that distort prices or artificially inflate trading volume with intent to mislead. Two forms: **information-based** (spreading false rumors, pump-and-dump) and **transaction-based** (wash trades, cornering a market). Legitimate tax-loss trades or genuine liquidity-providing trades are not manipulation; *intent to mislead* is the test.

**III(A) Loyalty, Prudence and Care.** Act for the benefit of clients and place their interests before the employer's and your own. Identify who the client is (for a pension plan, it is the plan's beneficiaries, not the sponsor's management). **Soft dollars** (research paid for with client commissions) belong to the client and may only buy research that benefits the client. Vote proxies in clients' interests (a cost-benefit analysis may justify not voting). Seek best execution.

**III(B) Fair Dealing.** Deal fairly and objectively with all clients when disseminating recommendations and taking investment action. *Fairly* does not mean *identically*: premium service levels are allowed if disclosed and available to all who pay for them. But **recommendation changes must reach all clients at the same time** (no favored early access), and **trade allocations** must be fair: block trades allocated pro rata, oversubscribed IPOs distributed pro rata, never withheld for personal or family accounts.

**III(C) Suitability.** For advisory relationships: inquire into the client's objectives, constraints and experience, prepare a written **investment policy statement (IPS)** and update it at least annually or after major changes; judge each investment in the context of the *whole portfolio*. If a client insists on an unsuitable trade, consider having the client acknowledge it is client-directed and outside the IPS, or update the IPS. When managing a fund to a mandate, suitability means **sticking to the stated mandate and strategy**.

**III(D) Performance Presentation.** Make reasonable efforts to ensure performance information is fair, accurate and complete. Do not present simulated results as actual, cherry-pick periods or accounts, or present a predecessor firm's results as your own without disclosure. GIPS compliance is encouraged but not required.

**III(E) Preservation of Confidentiality.** Keep information about current, former and prospective clients confidential unless (1) it concerns illegal activities by the client, (2) disclosure is required by law, or (3) the client permits it. Sharing with the CFA Institute PCP is permitted.""",
"formulas": [],
"examples": [
{"title": "Mosaic theory vs. MNPI",
 "problem": "An analyst counts trucks at a company's distribution centers, reviews public shipping data, and talks to suppliers about general demand. She concludes that quarterly revenue will badly miss estimates and issues a sell. Has she violated II(A)?",
 "steps": ["Each piece is public or non-material on its own.", "Combining them into a material conclusion is exactly what the mosaic theory permits.", "She should keep records of the research supporting the conclusion (V(C))."],
 "answer": "No violation. Her conclusion comes from a mosaic of public and non-material information."},
{"title": "IPO allocation",
 "problem": "A portfolio manager receives a small allocation of a hot IPO, suitable for 20 client accounts. He gives shares to his 10 largest clients and to his brother's account, which the firm manages for a fee.",
 "steps": ["Oversubscribed issues must be allocated pro rata to all accounts for which they are suitable.", "Favoring large clients violates III(B).", "The brother's fee-paying account is a client account and may participate on the same basis as others, but should not be favored (VI(B))."],
 "answer": "Violation of III(B) Fair Dealing. Allocate pro rata across all 20 suitable accounts."},
],
},
{
"id": "std4_7",
"title": "Standards IV to VII: Employers, Analysis, Conflicts, the CFA Program",
"body": r"""**IV(A) Loyalty (to employer).** Act for the employer's benefit; do not deprive it of your skills or cause it harm. You may plan to leave and arrange a new job, but **while still employed you may not solicit clients, take client lists or confidential records**, or use firm property. After leaving, you may contact former clients using public information or memory (unless a non-compete applies). Starting an independent practice that competes requires the employer's consent. Whistleblowing to protect clients or market integrity is not a violation.

**IV(B) Additional Compensation Arrangements.** Do not accept gifts, benefits or compensation that compete with or might create a conflict with the employer's interests **unless you obtain written consent from all parties involved**. A client's offer of a bonus for exceeding a benchmark needs the employer's written consent.

**IV(C) Responsibilities of Supervisors.** Make **reasonable efforts to ensure** anyone you supervise complies with laws and the Standards. That means adequate compliance procedures and effective enforcement. If the firm's procedures are inadequate, **decline in writing** to accept supervisory responsibility until adequate procedures exist. When you learn of a violation, a prompt investigation and limits on the employee's activity (not just a warning) are expected.

**V(A) Diligence and Reasonable Basis.** Exercise diligence, independence and thoroughness; have a reasonable and adequate basis, supported by appropriate research. Third-party research may be used if you have checked its reasonableness. With **group research**, you may put your name on a consensus report you disagree with, provided you believe the process was sound; if not, dissociate.

**V(B) Communication with Clients and Prospective Clients.** Disclose the basic format and general principles of the investment process, **the nature of the services and their associated costs**, and promptly disclose material changes. Use reasonable judgment about what to include, disclose **significant limitations and risks**, and **distinguish between fact and opinion**.

**V(C) Record Retention.** Keep records supporting analysis, recommendations and actions. Records belong to the firm. Absent regulatory guidance, CFA Institute recommends **at least seven years**.

**VI(A) Avoid or Disclose Conflicts.** Avoid conflicts where possible; otherwise make **full and fair disclosure** of anything that could impair independence and objectivity or interfere with duties to clients, prospects and employer. Disclosures must be **prominent, delivered in plain language** and effectively communicate the conflict. Examples: owning shares you recommend, board seats, compensation tied to banking deals.

**VI(B) Priority of Transactions.** Client and employer transactions come before personal transactions in which you have beneficial ownership. Family accounts that are client accounts should be treated like any other client (neither advantaged nor disadvantaged). Firms use blackout periods, pre-clearance and reporting of personal holdings.

**VI(C) Referral Fees.** Disclose to the employer, clients and prospects any compensation, consideration or benefit received or paid for recommending products or services, *before* entering into the engagement.

**VII(A) Conduct as Participants in CFA Institute Programs.** No cheating, no disclosing confidential exam content (specific questions or topics tested, beyond what CFA Institute discloses), no misuse of the designation. You may express opinions about the program, its policies and its difficulty in general terms.

**VII(B) Reference to CFA Institute, the CFA Designation and the CFA Program.** Do not misrepresent or exaggerate the meaning of membership, the charter or candidacy. Correct usage: "CFA" is an adjective (*a CFA charterholder*, never *a CFA*). There is **no partial designation**: "CFA Level II" is not permitted, though "passed Level II of the CFA Program" is. Candidates may say they are a "candidate in the CFA Program" only while registered for the next exam (or awaiting results). Stating that you passed all three levels on the first attempt is a fact and allowed; claiming this implies superior investment ability is not. Do not use larger or special fonts for the letters CFA.""",
"formulas": [],
"examples": [
{"title": "Preparing to leave a firm",
 "problem": "Over a weekend, a portfolio manager about to resign emails himself the firm's client contact spreadsheet so he can announce his new firm to them after he leaves.",
 "steps": ["Preparing to leave and arranging a new job is allowed.", "Taking firm records, including client lists, is not; they are the employer's property.", "After leaving he may contact clients he remembers or finds through public sources, subject to any non-compete."],
 "answer": "Violation of IV(A) Loyalty, because he took confidential firm records."},
{"title": "Supervisor's duty",
 "problem": "A newly promoted head of trading finds the firm has no written policy on personal trading. What should she do?",
 "steps": ["Under IV(C) she must make reasonable efforts to prevent and detect violations.", "Without adequate procedures she cannot meet that duty.", "She should decline supervisory responsibility in writing until adequate procedures are adopted, and urge their adoption."],
 "answer": "Decline in writing to accept supervisory responsibility until the firm adopts adequate compliance procedures."},
],
},
{
"id": "gips",
"title": "Global Investment Performance Standards (GIPS)",
"body": r"""**Purpose.** GIPS are voluntary, ethical standards for calculating and presenting investment performance, created so that prospective clients can compare firms on a fair, like-for-like basis. They aim for **full disclosure and fair representation**, preventing practices such as presenting only the best accounts (cherry-picking) or choosing flattering time periods.

**Who complies.** Only **investment management firms** (and asset owners) can claim compliance; individuals, consultants and software cannot. Compliance is **firm-wide**; there is no partial compliance. A firm may not say its performance is "calculated in accordance with GIPS" except as part of a full compliance claim.

**Composites.** A composite aggregates portfolios managed to a similar mandate, objective or strategy. **All actual, fee-paying, discretionary portfolios must be included in at least one composite.** This is the main tool that prevents cherry-picking. Composites must be defined in advance and portfolios cannot be moved between composites to flatter results.

**Return calculations.** Firms must use time-weighted returns for most portfolios (money-weighted is allowed in specific situations such as private equity where the firm controls flows), and value portfolios at least monthly and at large external cash flows.

**Presentation.** Firms must present at least five years of compliant performance (or since inception if shorter) and build to ten years.

**Verification** is performed by an independent third party on a **firm-wide** basis and tests (1) whether composite construction requirements have been applied firm-wide and (2) whether policies and procedures for calculating and presenting performance are designed in compliance and have been implemented. Verification is **recommended, not required**.

**Benefits.** Firms gain credibility and access to institutional mandates, and the process of complying often improves internal controls. Clients gain comparability and confidence.""",
"formulas": [],
"examples": [
{"title": "Composite construction",
 "problem": "A firm manages 40 portfolios to a large-cap value strategy but places only the 25 best-performing in its 'Large Cap Value' composite. Is this GIPS compliant?",
 "steps": ["All actual, fee-paying, discretionary portfolios must be in at least one composite.", "Excluding weaker portfolios is cherry-picking."],
 "answer": "No. All 40 portfolios managed to that strategy must be included."},
],
},
],
"pitfalls": [
"Law vs. Code: follow the stricter. Dissociate from violations; reporting to authorities is not required by the Standards.",
"Gifts FROM clients: disclose to employer. Bonus tied to FUTURE performance: written consent from employer (IV(B)).",
"Mosaic theory allows public + non-material nonpublic information, even if the conclusion turns out to be material.",
"Fair dealing does not mean identical treatment, but recommendation changes must reach clients simultaneously; IPOs pro rata.",
"Supervisors with inadequate procedures: decline supervisory responsibility in writing.",
"While still employed: no soliciting clients, no taking client lists or records. Memory and public info are fine after leaving.",
"Records: firm property; keep at least 7 years absent other rules.",
"'CFA' is an adjective; there is no partial designation; first-attempt passing is a fact you may state.",
"GIPS: firm-wide only, all fee-paying discretionary portfolios in at least one composite; verification is optional.",
],
"problems": [
{"id": "e1", "section": "std1", "level": 1,
 "q": "A member works in a country whose securities law is less strict than the CFA Institute Code and Standards. She should:",
 "choices": {"A": "follow local law, because it governs her conduct.", "B": "follow the Code and Standards, because they are stricter.", "C": "follow whichever her employer designates."}, "answer": "B",
 "explanation": "Standard I(A): when applicable law and the Code and Standards differ, follow the stricter."},
{"id": "e2", "section": "std1", "level": 2,
 "q": "A client gives a portfolio manager two concert tickets as thanks for strong returns last year. The manager should:",
 "choices": {"A": "decline the gift.", "B": "accept the gift and disclose it to his employer.", "C": "accept the gift only with written consent from his employer."}, "answer": "B",
 "explanation": "Gifts from clients for past performance may be accepted under I(B) but should be disclosed to the employer. Written consent applies to compensation tied to future performance (IV(B))."},
{"id": "e3", "section": "std1", "level": 2,
 "q": "A company hires an analyst to write a research report on its own stock for a fee. The arrangement is most consistent with Standard I(B) if the fee is:",
 "choices": {"A": "a flat fee, paid regardless of the report's conclusions, and disclosed.", "B": "a percentage of any increase in the company's share price.", "C": "contingent on a buy recommendation being issued."}, "answer": "A",
 "explanation": "Issuer-paid research must use a flat fee not linked to the conclusions, with the arrangement disclosed."},
{"id": "e4", "section": "std1", "level": 2,
 "q": "An analyst copies a few paragraphs of an industry overview from a broker's report into his own report without citing it. This most likely violates:",
 "choices": {"A": "I(C) Misrepresentation.", "B": "V(A) Diligence and Reasonable Basis.", "C": "II(A) Material Nonpublic Information."}, "answer": "A",
 "explanation": "Using another's work without attribution is plagiarism, covered by I(C) Misrepresentation."},
{"id": "e5", "section": "std1", "level": 2,
 "q": "A member is arrested at a peaceful political protest and charged with a minor offense. Under Standard I(D), this is:",
 "choices": {"A": "a violation, because any arrest reflects poorly on the profession.", "B": "a violation only if she is convicted.", "C": "generally not a violation, because it does not involve dishonesty or affect professional integrity."}, "answer": "C",
 "explanation": "I(D) targets dishonesty, fraud, deceit and conduct reflecting on professional integrity. Civil disobedience generally does not."},
{"id": "e6", "section": "std1", "level": 2,
 "q": "A fixed income manager is asked to take over a complex derivatives overlay strategy she has never used. Under the 2024 Standards, she should most appropriately:",
 "choices": {"A": "accept, since all charterholders are presumed competent.", "B": "acquire the necessary knowledge or support before acting, or decline the assignment.", "C": "accept but disclose to clients that she lacks experience."}, "answer": "B",
 "explanation": "Standard I(E) Competence requires acting with and maintaining the competence needed for the responsibility. Disclosure alone does not satisfy it."},
{"id": "e7", "section": "std2_3", "level": 2,
 "q": "During a lunch, a CFO tells an analyst, before any announcement, that the company will miss earnings badly. The analyst should:",
 "choices": {"A": "downgrade the stock immediately to protect clients.", "B": "not trade or recommend on the information and encourage the company to disclose it publicly.", "C": "share the information only with institutional clients."}, "answer": "B",
 "explanation": "This is material nonpublic information. II(A) prohibits acting or causing others to act on it. The appropriate step is to encourage public disclosure."},
{"id": "e8", "section": "std2_3", "level": 1,
 "q": "A trader repeatedly buys and sells the same thinly traded stock between two accounts he controls to make it appear actively traded. This is:",
 "choices": {"A": "information-based manipulation.", "B": "transaction-based manipulation.", "C": "permitted if no client is harmed."}, "answer": "B",
 "explanation": "Wash trades that create a false impression of volume are transaction-based manipulation under II(B)."},
{"id": "e9", "section": "std2_3", "level": 2,
 "q": "A pension plan's investment manager owes her duty of loyalty primarily to:",
 "choices": {"A": "the plan sponsor's management.", "B": "the plan's participants and beneficiaries.", "C": "her firm's shareholders."}, "answer": "B",
 "explanation": "III(A): for a pension plan, the client is the participants and beneficiaries."},
{"id": "e10", "section": "std2_3", "level": 2,
 "q": "A firm offers a premium service in which subscribers receive a phone call before a research note is emailed to all clients. Under III(B), this is:",
 "choices": {"A": "acceptable, because premium service levels are permitted if disclosed.", "B": "a violation, because a change in recommendation must be disseminated so that all clients receive it at the same time.", "C": "acceptable if the premium clients pay higher commissions."}, "answer": "B",
 "explanation": "Different service levels are allowed, but they cannot give some clients the recommendation change before others."},
{"id": "e11", "section": "std2_3", "level": 2,
 "q": "A manager of a fund marketed as a 'U.S. investment-grade bond fund' adds high-yield emerging market bonds because they look attractive. This most likely violates:",
 "choices": {"A": "III(C) Suitability.", "B": "III(D) Performance Presentation.", "C": "no standard, if returns improve."}, "answer": "A",
 "explanation": "When managing to a mandate, suitability means adhering to the stated strategy and constraints."},
{"id": "e12", "section": "std2_3", "level": 2,
 "q": "An adviser learns that a client is laundering money through the account. Regarding confidentiality, the adviser:",
 "choices": {"A": "must keep the information confidential.", "B": "may disclose it, because the duty of confidentiality does not cover illegal activity.", "C": "may disclose it only with the client's permission."}, "answer": "B",
 "explanation": "III(E) allows disclosure when the information concerns illegal activity by the client (and may be legally required)."},
{"id": "e13", "section": "std2_3", "level": 2,
 "q": "A manager's marketing piece shows the performance of her three best accounts as 'representative' of the strategy. This violates:",
 "choices": {"A": "III(D) Performance Presentation.", "B": "IV(A) Loyalty.", "C": "VII(B) Reference to CFA Institute."}, "answer": "A",
 "explanation": "Cherry-picking accounts misrepresents performance, violating III(D)."},
{"id": "e14", "section": "std4_7", "level": 2,
 "q": "A client offers his portfolio manager a bonus if the portfolio beats its benchmark by 3% this year. The manager should:",
 "choices": {"A": "decline, because client bonuses are prohibited.", "B": "accept only after obtaining written consent from her employer.", "C": "accept and disclose it after the year ends."}, "answer": "B",
 "explanation": "Compensation tied to future performance can create a conflict with the employer; IV(B) requires written consent from all parties involved."},
{"id": "e15", "section": "std4_7", "level": 2,
 "q": "An analyst disagrees with her research team's 'buy' consensus but believes the team's process was thorough and well founded. She may:",
 "choices": {"A": "put her name on the report.", "B": "not put her name on the report under any circumstances.", "C": "publish a separate dissenting report to her own clients."}, "answer": "A",
 "explanation": "Under V(A), a member may be associated with a group report she disagrees with if she believes it has a reasonable and adequate basis."},
{"id": "e16", "section": "std4_7", "level": 2,
 "q": "Which statement in a client presentation is most likely a violation of V(B)?",
 "choices": {"A": "'We expect earnings to grow 10% next year, based on our model.'", "B": "'Earnings will grow 10% next year.'", "C": "'Last year earnings grew 8%.'"}, "answer": "B",
 "explanation": "V(B) requires distinguishing fact from opinion. Stating a forecast as a certainty presents opinion as fact."},
{"id": "e17", "section": "std4_7", "level": 1,
 "q": "In the absence of regulatory guidance, CFA Institute recommends keeping records that support investment recommendations for at least:",
 "choices": {"A": "3 years.", "B": "5 years.", "C": "7 years."}, "answer": "C",
 "explanation": "V(C): at least seven years absent other requirements."},
{"id": "e18", "section": "std4_7", "level": 2,
 "q": "An analyst writes a buy recommendation on a stock he owns. Under VI(A), he must:",
 "choices": {"A": "sell the stock before publishing.", "B": "make full and fair disclosure of his holding, prominently and in plain language.", "C": "do nothing, if the position is small relative to his net worth."}, "answer": "B",
 "explanation": "VI(A) Avoid or Disclose Conflicts: ownership is a conflict that must be avoided or disclosed prominently and clearly."},
{"id": "e19", "section": "std4_7", "level": 2,
 "q": "A portfolio manager places his personal order for a stock before executing a large block purchase of the same stock for clients. This violates:",
 "choices": {"A": "VI(B) Priority of Transactions.", "B": "III(C) Suitability.", "C": "VI(C) Referral Fees."}, "answer": "A",
 "explanation": "Front-running clients violates VI(B): client and employer trades come first."},
{"id": "e20", "section": "std4_7", "level": 1,
 "q": "Which statement is consistent with Standard VII(B)?",
 "choices": {"A": "'John Smith, CFA Level III'", "B": "'As a CFA, I deliver superior returns.'", "C": "'I passed all three levels of the CFA exam on my first attempt.'"}, "answer": "C",
 "explanation": "Passing on the first attempt is a factual statement. There is no partial designation (A), and 'CFA' cannot be a noun or imply superior performance (B)."},
{"id": "e21", "section": "std4_7", "level": 2,
 "q": "After sitting the Level I exam, a candidate posts online that 'there were a lot of questions on duration this year.' This is:",
 "choices": {"A": "permissible, since no specific question was disclosed.", "B": "a violation of VII(A), because it discloses which topics were tested.", "C": "a violation only if the post is public."}, "answer": "B",
 "explanation": "Disclosing which topics or formulas were or were not tested breaches exam confidentiality under VII(A)."},
{"id": "e22", "section": "std4_7", "level": 2,
 "q": "A financial planner receives a fee from an attorney for every client he refers. Under VI(C), he must disclose this to:",
 "choices": {"A": "his employer only.", "B": "clients and prospective clients only.", "C": "his employer, clients and prospective clients."}, "answer": "C",
 "explanation": "Referral fees must be disclosed to the employer, clients and prospects, before entering the engagement."},
{"id": "e23", "section": "gips", "level": 1,
 "q": "Which of the following can claim compliance with GIPS?",
 "choices": {"A": "An individual portfolio manager.", "B": "An investment management firm.", "C": "A performance-measurement software vendor."}, "answer": "B",
 "explanation": "Only firms (and asset owners) can claim compliance, and compliance is firm-wide."},
{"id": "e24", "section": "gips", "level": 2,
 "q": "Under GIPS, which portfolios must be included in at least one composite?",
 "choices": {"A": "All actual, fee-paying, discretionary portfolios.", "B": "All portfolios, including non-fee-paying ones.", "C": "Only portfolios that have existed for at least one year."}, "answer": "A",
 "explanation": "All actual, fee-paying, discretionary portfolios must be included in at least one composite."},
{"id": "e25", "section": "gips", "level": 2,
 "q": "GIPS verification is best described as:",
 "choices": {"A": "required and performed on each composite.", "B": "recommended and performed on a firm-wide basis by an independent third party.", "C": "required and performed by the firm's internal audit."}, "answer": "B",
 "explanation": "Verification is optional (recommended), firm-wide, and performed by an independent third party."},
{"id": "e26", "section": "framework", "level": 1,
 "q": "When a member's duties conflict, the correct order of priority is:",
 "choices": {"A": "employer, clients, self.", "B": "clients, employer, self.", "C": "clients, self, employer."}, "answer": "B",
 "explanation": "After obeying the law and the Code and Standards, clients come first, then the employer, then personal interests."},
],
}

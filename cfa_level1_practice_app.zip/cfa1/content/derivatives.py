TOPIC = {
"id": "deriv",
"name": "Derivatives",
"weight": "5-8%",
"overview": r"""Level I derivatives covers the instruments and their markets, the uses, benefits and risks of derivatives, and the core pricing idea: **arbitrage-free pricing by replication**. If two portfolios have identical future payoffs, they must cost the same today. From that one idea come the cost-of-carry forward price, the value of a forward during its life, swap pricing as a series of forwards, **put-call parity**, and the **one-period binomial model**. Your daily work with ETF creation/redemption and AP arbitrage is the same logic: identical exposures cannot persistently trade at different prices.""",
"sections": [
{
"id": "instruments",
"title": "Instruments, Markets, Uses and Risks",
"body": r"""A **derivative** is a contract whose value depends on an **underlying** (equity, bond, rate, currency, commodity, credit, or another derivative). Two families:

- **Firm (forward) commitments**: both parties are obligated. **Forwards** (customized OTC contracts), **futures** (standardized, exchange-traded, marked to market daily through a clearinghouse), and **swaps** (exchanges of a series of cash flows; equivalent to a portfolio of forwards). Payoffs are **linear** (symmetric) in the underlying.
- **Contingent claims**: one party has a right, not an obligation. **Options** (calls and puts), **credit derivatives** (e.g. credit default swaps, where the protection buyer pays a premium and receives compensation on a credit event), and **asset-backed securities** with embedded options. Payoffs are **non-linear** (asymmetric).

**Exchange-traded vs. OTC.** Exchange-traded derivatives are standardized, liquid, transparent, and the clearinghouse guarantees performance (counterparty risk is minimal). OTC derivatives are customized and flexible but carry **counterparty credit risk** and less transparency. Post-2008 regulation pushes standardized OTC derivatives to **central clearing** (CCPs) with margin.

**Futures mechanics.** Both sides post **initial margin**; the account is **marked to market daily**; if the balance falls below the **maintenance margin**, a **variation margin** call restores it to the *initial* margin level. Some futures have **price limits**. Settlement is by delivery or cash.

**Forward vs. futures prices.** If interest rates are uncorrelated with the futures price, the two are equal. If futures prices are positively correlated with rates, futures are preferred (gains are reinvested at higher rates) and their price is higher.

**Uses.** Hedging (risk transfer), lower transaction costs, greater liquidity, ease of shorting, **price discovery**, operational efficiency. Companies use derivatives to manage exposure, and may qualify for **hedge accounting** (fair value hedges, cash flow hedges, net investment hedges) to reduce earnings volatility.

**Risks.** Implicit leverage, **basis risk** (the hedge and the exposure do not move together), liquidity risk, counterparty credit risk, and systemic risk from interconnected positions and excessive speculation.""",
"formulas": [],
"examples": [
{"title": "Futures margin call",
 "problem": "A trader is long one futures contract with initial margin USD 5,000 and maintenance margin USD 4,000. A daily loss of USD 1,300 brings the account to USD 3,700. What must be deposited?",
 "steps": ["The balance (3,700) is below maintenance (4,000), triggering a call.", "Variation margin restores the account to the INITIAL margin: 5,000 - 3,700 = 1,300."],
 "answer": "USD 1,300 (not 300, which would only reach the maintenance level)."},
],
},
{
"id": "forwards",
"title": "Arbitrage, Replication and Pricing Forwards, Futures and Swaps",
"body": r"""**Arbitrage-free pricing.** Under the **law of one price**, assets with identical cash flows must have the same price. If not, an arbitrageur buys the cheap one and sells the expensive one for a riskless profit. Derivative prices are therefore set by **replication**, not by investors' expectations or risk preferences: a forward price is *not* a forecast of the future spot price.

**Cost of carry.** Holding the underlying until the forward date involves:

- the **opportunity cost** of the money tied up (the risk-free rate),
- **costs** of carry such as storage and insurance (raise the forward price),
- **benefits** such as dividends, coupons or a **convenience yield** (lower the forward price).

**Replication.** A long forward is replicated by borrowing to buy the underlying and holding it. If the forward is too expensive, sell the forward and buy the underlying with borrowed money (*cash-and-carry*); if too cheap, buy the forward and short the underlying, investing the proceeds (*reverse cash-and-carry*).

**Value vs. price.** At initiation the forward **price** $F_0(T)$ is set so the contract has **zero value**. During its life, the **value** to the long position changes: it is the spot price minus the present value of the forward price, adjusted for any carry. At expiration, the value is simply $S_T - F_0(T)$.

**Currency forwards** follow covered interest rate parity (see Economics): the higher-rate currency trades at a forward discount.

**Forward rate agreements (FRAs)** lock in a future interest rate; the implied forward rate from the spot curve is the no-arbitrage FRA rate.

**Interest rate swaps.** In a plain vanilla swap, one side pays fixed and receives floating. A swap is equivalent to a **series of forward contracts** (or FRAs) at the same fixed rate. At initiation the **swap rate** is set so that the PV of fixed payments equals the PV of the floating payments: it is the **par rate** implied by the spot curve. Paying fixed is like issuing a fixed bond and buying a floating bond; it gains value when rates rise.""",
"formulas": [
{"name": "Forward price (discrete compounding)", "tex": r"F_0(T) = \left[S_0 - PV_0(I) + PV_0(C)\right](1+r)^T", "vars": [["S_0", "spot price"], ["PV_0(I)", "PV of income/benefits (dividends, coupons, convenience yield)"], ["PV_0(C)", "PV of costs of carry (storage, insurance)"], ["r", "annual risk-free rate"], ["T", "time to expiration in years"]], "note": "No carry: $F_0(T) = S_0(1+r)^T$."},
{"name": "Forward price (continuous compounding)", "tex": r"F_0(T) = S_0\,e^{(r + c - i)T}", "vars": [["c", "continuous carry cost rate"], ["i", "continuous income yield"]], "note": ""},
{"name": "Value of a long forward during its life", "tex": r"V_t(T) = \left[S_t - PV_t(I) + PV_t(C)\right] - \frac{F_0(T)}{(1+r)^{T-t}}", "vars": [["S_t", "spot price at time t"]], "note": r"At expiration: $V_T = S_T - F_0(T)$. The short's value is the negative."},
{"name": "Swap rate from discount factors", "tex": r"s_N = \frac{1 - DF_N}{\sum_{t=1}^{N} DF_t} \qquad DF_t = \frac{1}{(1+Z_t)^t}", "vars": [["s_N", "N-period par swap rate"], ["DF_t", "discount factor for t"]], "note": ""},
],
"examples": [
{"title": "Forward price with a dividend",
 "problem": "A stock trades at USD 100. It will pay a USD 2 dividend in 6 months. The risk-free rate is 5% (annual compounding). Price a 1-year forward.",
 "steps": [r"$PV(I) = 2/1.05^{0.5} = 1.9518$.", r"$F_0 = (100 - 1.9518) \times 1.05 = 102.95$.", "Without the dividend the forward would be 105.00."],
 "answer": "USD 102.95."},
{"title": "Valuing an existing forward",
 "problem": "Six months ago a trader went long a 1-year forward at USD 105 on a non-dividend stock. The stock is now USD 108 and r = 5%. Value the position.",
 "steps": [r"PV of the forward price over the remaining 0.5 years: $105/1.05^{0.5} = 102.47$.", r"$V_t = 108 - 102.47 = 5.53$."],
 "answer": "USD 5.53 to the long (and -5.53 to the short)."},
{"title": "Swap rate",
 "problem": "Spot rates: 3% (1y), 4% (2y), 5% (3y). Find the 3-year annual-pay swap rate.",
 "steps": [r"$DF_1 = 0.97087$, $DF_2 = 0.92456$, $DF_3 = 0.86384$; sum $= 2.75927$.", r"$s_3 = (1 - 0.86384)/2.75927 = 4.93\%$."],
 "answer": "4.93%, the 3-year par rate."},
],
},
{
"id": "options",
"title": "Options: Payoffs, Value Drivers, Put-Call Parity and the Binomial Model",
"body": r"""**Payoffs at expiration.** A **call** gives the right to buy at the exercise (strike) price $X$; a **put** gives the right to sell. The buyer pays a premium; the seller (writer) receives it and takes on the obligation.

| Position | Payoff at expiration | Profit | Breakeven | Max gain / max loss |
|---|---|---|---|---|
| Long call | $\max(0, S_T - X)$ | payoff $- c_0$ | $X + c_0$ | Unlimited / $c_0$ |
| Short call | $-\max(0, S_T - X)$ | $c_0 -$ payoff | $X + c_0$ | $c_0$ / unlimited |
| Long put | $\max(0, X - S_T)$ | payoff $- p_0$ | $X - p_0$ | $X - p_0$ / $p_0$ |
| Short put | $-\max(0, X - S_T)$ | $p_0 -$ payoff | $X - p_0$ | $p_0$ / $X - p_0$ |

**Moneyness.** A call is in the money when $S > X$; a put when $S < X$. **Intrinsic (exercise) value** is the payoff if exercised now; **time value** = option price - intrinsic value, and it decays to zero at expiration. European options can only be exercised at expiration; American options at any time (so they are worth at least as much).

**Factors that affect option value.**

| Increase in | Call | Put |
|---|---|---|
| Underlying price | Up | Down |
| Exercise price | Down | Up |
| Time to expiration | Up | Up (usually) |
| Volatility | Up | Up |
| Risk-free rate | Up | Down |
| Income on underlying (dividends) | Down | Up |
| Carry costs | Up | Down |

**Lower bounds** (European, non-dividend): $c_0 \geq \max[0, S_0 - X/(1+r)^T]$ and $p_0 \geq \max[0, X/(1+r)^T - S_0]$.

**Put-call parity.** A **fiduciary call** (call + risk-free bond paying $X$) and a **protective put** (stock + put) have identical payoffs at expiration: $\max(S_T, X)$. So they must cost the same. Rearranging gives *synthetic* instruments: a synthetic put = call + bond - stock, etc. **Put-call forward parity** replaces the stock with a forward: $F_0/(1+r)^T + p_0 = c_0 + X/(1+r)^T$.

**One-period binomial model.** The underlying moves up to $S_0u$ or down to $S_0d$. A portfolio of the underlying and the option can be made riskless (hedged), so it must earn the risk-free rate. This gives **risk-neutral probabilities** $\pi$ that depend only on $u$, $d$ and $r$, not on investors' views. The option value is the expected payoff under $\pi$, discounted at the risk-free rate. The **hedge ratio** $h$ is the number of shares per option that makes the position riskless.

**Option value from replication** is risk-neutral: the actual probability of an up move does not enter the price.""",
"formulas": [
{"name": "Option payoffs", "tex": r"c_T = \max(0, S_T - X) \qquad p_T = \max(0, X - S_T)", "vars": [["S_T", "underlying price at expiration"], ["X", "exercise price"]], "note": ""},
{"name": "Put-call parity", "tex": r"S_0 + p_0 = c_0 + \frac{X}{(1+r)^T}", "vars": [["S_0", "spot price"], ["p_0, c_0", "European put and call prices"], ["X/(1+r)^T", "PV of the exercise price (risk-free bond)"]], "note": "Left: protective put. Right: fiduciary call."},
{"name": "Put-call forward parity", "tex": r"\frac{F_0(T)}{(1+r)^T} + p_0 = c_0 + \frac{X}{(1+r)^T}", "vars": [], "note": ""},
{"name": "Binomial model", "tex": r"\pi = \frac{1 + r - d}{u - d} \qquad c_0 = \frac{\pi c_u + (1-\pi)c_d}{1+r} \qquad h = \frac{c_u - c_d}{S_0u - S_0d}",
 "vars": [["u, d", "up and down factors (gross returns)"], ["\\pi", "risk-neutral probability of an up move"], ["c_u, c_d", "option payoffs in the up and down states"], ["h", "hedge ratio (shares per option)"]], "note": "Same formula for puts with $p_u, p_d$."},
],
"examples": [
{"title": "Put-call parity",
 "problem": "S0 = 50, X = 50, one year to expiration, r = 4%. A European call costs 5.00. What should the European put cost?",
 "steps": [r"$p_0 = c_0 + X/(1+r)^T - S_0 = 5.00 + 50/1.04 - 50$.", r"$50/1.04 = 48.077$; $p_0 = 5.00 + 48.077 - 50 = 3.08$."],
 "answer": "USD 3.08. If the put traded at 3.50, buy the fiduciary call (cheap side) and sell the protective put (rich side)."},
{"title": "One-period binomial model",
 "problem": "S0 = 100, u = 1.2, d = 0.8, r = 5% for the period. Value a call and a put with X = 100, and the call's hedge ratio.",
 "steps": [r"$\pi = (1.05 - 0.8)/(1.2 - 0.8) = 0.625$.",
           r"Call payoffs: up $= 120 - 100 = 20$; down $= 0$. $c_0 = 0.625 \times 20/1.05 = 11.90$.",
           r"Put payoffs: up $= 0$; down $= 100 - 80 = 20$. $p_0 = 0.375 \times 20/1.05 = 7.14$.",
           r"Hedge ratio: $h = (20 - 0)/(120 - 80) = 0.5$: sell one call against 0.5 shares for a riskless position.",
           r"Check parity: $100 + 7.14 = 11.90 + 100/1.05 = 107.14$."],
 "answer": "Call 11.90, put 7.14, hedge ratio 0.5."},
],
},
],
"pitfalls": [
"A forward PRICE is set so value is zero at initiation; the VALUE changes afterward.",
"Income (dividends, coupons, convenience yield) LOWERS the forward price; storage costs RAISE it.",
"Futures margin call: restore to INITIAL margin, not maintenance.",
"Swap = series of forwards; the swap rate is the par rate from the spot curve.",
"Long call breakeven X + c; long put breakeven X - p.",
"Higher volatility raises BOTH call and put values. Higher rates raise calls, lower puts.",
"Put-call parity: S + p = c + PV(X). Binomial pricing uses risk-neutral probabilities, not actual ones.",
],
"problems": [
{"id": "d1", "section": "instruments", "level": 1,
 "q": "Which derivative has a non-linear (asymmetric) payoff?",
 "choices": {"A": "A forward contract.", "B": "An interest rate swap.", "C": "A call option."}, "answer": "C",
 "explanation": "Options are contingent claims with asymmetric payoffs; forwards, futures and swaps are firm commitments with linear payoffs."},
{"id": "d2", "section": "instruments", "level": 2,
 "q": "Compared with OTC forwards, exchange-traded futures most likely have:",
 "choices": {"A": "greater customization.", "B": "less counterparty credit risk.", "C": "less transparency."}, "answer": "B",
 "explanation": "The clearinghouse guarantees performance and daily mark-to-market limits credit exposure."},
{"id": "d3", "section": "instruments", "level": 2,
 "q": "Initial margin is USD 3,000 and maintenance margin is USD 2,500. After a loss the balance is USD 2,200. The variation margin required is:",
 "choices": {"A": "USD 300", "B": "USD 800", "C": "USD 0"}, "answer": "B",
 "explanation": "The account must be brought back to initial margin: 3,000 - 2,200 = 800."},
{"id": "d4", "section": "instruments", "level": 2,
 "q": "A company hedges jet fuel purchases with crude oil futures. The risk that jet fuel and crude prices do not move together is:",
 "choices": {"A": "basis risk.", "B": "counterparty risk.", "C": "liquidity risk."}, "answer": "A",
 "explanation": "A mismatch between the hedging instrument and the exposure is basis risk."},
{"id": "d5", "section": "forwards", "level": 1,
 "q": "A non-dividend stock trades at USD 40, and the risk-free rate is 3% (annual compounding). The 9-month forward price is closest to:",
 "choices": {"A": "USD 40.90", "B": "USD 41.20", "C": "USD 40.00"}, "answer": "A",
 "explanation": r"$40 \times 1.03^{0.75} = 40.90$."},
{"id": "d6", "section": "forwards", "level": 2,
 "q": "All else equal, an increase in the convenience yield of a commodity will:",
 "choices": {"A": "increase its forward price.", "B": "decrease its forward price.", "C": "not affect its forward price."}, "answer": "B",
 "explanation": "Convenience yield is a benefit of holding the physical asset, which reduces the cost of carry."},
{"id": "d7", "section": "forwards", "level": 2,
 "q": "The value of a forward contract at initiation is:",
 "choices": {"A": "zero.", "B": "equal to the spot price.", "C": "equal to the forward price."}, "answer": "A",
 "explanation": "The forward price is chosen so that neither side pays anything at initiation."},
{"id": "d8", "section": "forwards", "level": 3,
 "q": "A forward bought at F0 = 60 has 3 months to expiration. The underlying (no income) now trades at 63 and r = 4%. The value to the long is closest to:",
 "choices": {"A": "3.00", "B": "3.59", "C": "2.41"}, "answer": "B",
 "explanation": r"$63 - 60/1.04^{0.25} = 63 - 59.41 = 3.59$."},
{"id": "d9", "section": "forwards", "level": 2,
 "q": "A plain vanilla interest rate swap is best described as equivalent to:",
 "choices": {"A": "a single forward contract.", "B": "a series of forward contracts.", "C": "a portfolio of options."}, "answer": "B",
 "explanation": "Each payment exchange is like an FRA at the same fixed rate."},
{"id": "d10", "section": "forwards", "level": 2,
 "q": "After entering a pay-fixed, receive-floating swap, interest rates rise. The value of the swap to the fixed-rate payer:",
 "choices": {"A": "increases.", "B": "decreases.", "C": "is unchanged."}, "answer": "A",
 "explanation": "The payer locked in a fixed rate below the new market rate and receives the higher floating rate."},
{"id": "d11", "section": "options", "level": 1,
 "q": "An investor buys a put with X = 50 for a premium of USD 4. At expiration the stock is USD 43. The profit is:",
 "choices": {"A": "USD 3", "B": "USD 7", "C": "-USD 4"}, "answer": "A",
 "explanation": r"Payoff $= 50 - 43 = 7$; profit $= 7 - 4 = 3$. Breakeven is 46."},
{"id": "d12", "section": "options", "level": 2,
 "q": "A call writer's maximum loss is:",
 "choices": {"A": "the premium received.", "B": "the exercise price.", "C": "unlimited."}, "answer": "C",
 "explanation": "The underlying price has no upper limit."},
{"id": "d13", "section": "options", "level": 2,
 "q": "An increase in the volatility of the underlying will most likely:",
 "choices": {"A": "increase call values and decrease put values.", "B": "increase both call and put values.", "C": "decrease both."}, "answer": "B",
 "explanation": "Options have limited downside, so greater dispersion of outcomes increases expected payoffs for both."},
{"id": "d14", "section": "options", "level": 2,
 "q": "A stock trades at USD 52; a 6-month European call with X = 50 costs USD 4.50; r = 5%. Under put-call parity, the put should cost about:",
 "choices": {"A": "USD 1.30", "B": "USD 2.50", "C": "USD 0.27"}, "answer": "A",
 "explanation": r"$p = 4.50 + 50/1.05^{0.5} - 52 = 4.50 + 48.795 - 52 = 1.30$."},
{"id": "d15", "section": "options", "level": 2,
 "q": "A fiduciary call consists of:",
 "choices": {"A": "a long call and a risk-free bond paying X at expiration.", "B": "a long stock and a long put.", "C": "a long stock and a short call."}, "answer": "A",
 "explanation": "Long stock + long put is a protective put; long stock + short call is a covered call."},
{"id": "d16", "section": "options", "level": 3,
 "q": "S0 = 50, u = 1.10, d = 0.90, r = 2% per period. The value of a one-period European put with X = 50 is closest to:",
 "choices": {"A": "USD 1.96", "B": "USD 2.94", "C": "USD 2.50"}, "answer": "A",
 "explanation": r"$\pi = (1.02 - 0.90)/0.20 = 0.60$. Put payoffs: up 0, down 5. $p_0 = 0.40 \times 5/1.02 = 1.96$. B uses $\pi$ instead of $1 - \pi$."},
{"id": "d17", "section": "options", "level": 2,
 "q": "In the binomial model, the risk-neutral probability of an up move depends on:",
 "choices": {"A": "investors' expected return on the stock.", "B": "the up and down factors and the risk-free rate.", "C": "the actual probability of an up move."}, "answer": "B",
 "explanation": r"$\pi = (1 + r - d)/(u - d)$; expectations and risk preferences do not enter."},
{"id": "d18", "section": "options", "level": 2,
 "q": "A European call on a non-dividend stock: S0 = 60, X = 55, T = 1 year, r = 5%. The lower bound of the call price is closest to:",
 "choices": {"A": "USD 5.00", "B": "USD 7.62", "C": "USD 0.00"}, "answer": "B",
 "explanation": r"$\max(0, 60 - 55/1.05) = 60 - 52.38 = 7.62$."},
],
}

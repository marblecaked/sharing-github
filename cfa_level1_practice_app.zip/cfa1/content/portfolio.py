TOPIC = {
"id": "pm",
"name": "Portfolio Management",
"weight": "8-12%",
"overview": r"""Portfolio management ties the curriculum together: who the investors are and what they need, how risk and return combine in portfolios, the **capital allocation line, capital market line, CAPM and security market line**, the **performance measures** (Sharpe, Treynor, M-squared, Jensen's alpha), the investment policy statement and asset allocation, behavioral biases, and enterprise risk management. Your day job sits squarely in this topic, so the main work is learning the curriculum's exact definitions and formulas rather than the concepts.""",
"sections": [
{
"id": "overview",
"title": "The Portfolio Management Process and Investors",
"body": r"""**The portfolio approach.** Evaluating investments as part of a portfolio rather than in isolation captures **diversification**: combining imperfectly correlated assets reduces risk without proportionally reducing return. The **diversification ratio** (risk of an equally weighted portfolio / average risk of a single security) measures the benefit. Diversification does not protect against *systematic* risk, and correlations tend to rise in crises.

**Steps of portfolio management.**

1. **Planning**: understand the client's needs and circumstances; write the **investment policy statement (IPS)**; form capital market expectations; set the strategic asset allocation.
2. **Execution**: asset allocation, security analysis, portfolio construction, trade execution.
3. **Feedback**: monitoring and rebalancing; performance measurement and reporting.

**Types of investors.**

| Investor | Time horizon | Risk tolerance | Income needs | Liquidity needs |
|---|---|---|---|---|
| Individuals | Varies by age | Varies | Varies | Varies |
| Defined benefit pension plans | Long | High | Depends on age of plan | Low (young plan) to high (mature plan) |
| Endowments and foundations | Very long (perpetual) | High | Spending commitments (e.g. 4-5% per year) | Low |
| Banks | Short | Low | Pay interest on deposits | High |
| Insurance (life) | Long | Low | Low | Moderate |
| Insurance (property and casualty) | Short | Low | Low | High |
| Investment companies (mutual funds) | Varies | Varies | Varies | High (redemptions) |
| Sovereign wealth funds | Varies by purpose | Varies | Varies | Varies |

**Defined contribution vs. defined benefit.** In a DC plan the employee bears investment risk and makes the decisions; in a DB plan the sponsor bears the risk.

**Pooled investment vehicles.** Open-end mutual funds (buy and redeem at NAV), closed-end funds (fixed shares, trade at premiums or discounts to NAV), **ETFs** (trade intraday; the creation/redemption mechanism with authorized participants keeps prices close to NAV and allows in-kind tax efficiency), separately managed accounts, hedge funds, private equity funds. **Asset management industry** trends: growth of passive investing, big data and AI, robo-advisors, fee compression.""",
"formulas": [],
"examples": [
{"title": "Matching investor and needs",
 "problem": "A university endowment spends 4.5% of assets per year and expects to exist indefinitely. Describe its time horizon, risk tolerance and liquidity needs.",
 "steps": ["Perpetual horizon allows long-term, equity-heavy and illiquid assets.", "Spending needs are moderate and predictable.", "It must earn the spending rate plus inflation plus costs to preserve real value."],
 "answer": "Very long horizon, high risk tolerance, low liquidity needs: well suited to alternatives and equities."},
],
},
{
"id": "riskreturn",
"title": "Risk, Return, Utility and the Optimal Portfolio",
"body": r"""**Risk aversion.** A *risk-averse* investor prefers the less risky of two investments with the same expected return; a *risk-neutral* investor cares only about expected return; a *risk-seeking* investor prefers more risk. Rational investors are assumed to be risk averse.

**Utility.** The curriculum's utility function is $U = E(r) - \tfrac{1}{2}A\sigma^2$, where $A$ is the coefficient of risk aversion (higher $A$ = more risk averse; $A = 0$ is risk neutral, $A < 0$ risk seeking). Returns and variances are entered as decimals. **Indifference curves** connect portfolios with equal utility; for risk-averse investors they slope upward and are steeper for more risk-averse investors.

**The minimum-variance frontier** is the set of portfolios with the lowest risk for each level of expected return. The part above the **global minimum-variance portfolio** is the **Markowitz efficient frontier**: no other portfolio offers higher return for the same risk.

**Adding a risk-free asset.** Combining the risk-free asset with any risky portfolio gives a straight line, the **capital allocation line (CAL)**. The best CAL is tangent to the efficient frontier at the **optimal risky portfolio**. Under the **two-fund separation theorem**, every investor holds the same optimal risky portfolio and simply chooses how much to put in the risk-free asset (or borrow) based on risk aversion. The **optimal investor portfolio** is where the investor's highest indifference curve touches the CAL.

**Leverage.** Investors who borrow at the risk-free rate to invest more than 100% in the risky portfolio move up the CAL beyond the tangency point.""",
"formulas": [
{"name": "Utility", "tex": r"U = E(r) - \tfrac{1}{2}A\sigma^2", "vars": [["E(r)", "expected return (decimal)"], ["A", "risk aversion coefficient"], ["\\sigma^2", "variance (decimal)"]], "note": ""},
{"name": "Capital allocation line", "tex": r"E(R_p) = R_f + \frac{E(R_i) - R_f}{\sigma_i}\,\sigma_p", "vars": [["R_f", "risk-free rate"], ["E(R_i), \\sigma_i", "expected return and risk of the risky portfolio"], ["\\sigma_p", "risk of the combined portfolio"]], "note": "The slope is the Sharpe ratio of the risky portfolio."},
{"name": "Combined portfolio return and risk", "tex": r"E(R_p) = w_1 R_f + (1-w_1)E(R_i) \qquad \sigma_p = (1-w_1)\sigma_i", "vars": [["w_1", "weight in the risk-free asset"]], "note": "The risk-free asset has zero variance and zero covariance."},
],
"examples": [
{"title": "Choosing with utility",
 "problem": "An investor with A = 4 chooses between Portfolio X (E(r) = 10%, sigma = 20%) and Portfolio Y (E(r) = 7%, sigma = 10%). Which has higher utility?",
 "steps": [r"$U_X = 0.10 - 0.5(4)(0.20^2) = 0.10 - 0.08 = 0.020$.", r"$U_Y = 0.07 - 0.5(4)(0.10^2) = 0.07 - 0.02 = 0.050$."],
 "answer": "Portfolio Y. A less risk-averse investor (e.g. A = 1) would pick X: U = 0.08 vs. 0.065."},
],
},
{
"id": "capm",
"title": "CML, CAPM, SML and Performance Measures",
"body": r"""**Capital market line (CML).** If all investors share the same expectations (homogeneous expectations), they all identify the same optimal risky portfolio, which must be the **market portfolio** of all risky assets. The CAL using the market portfolio is the CML. Portfolios on the CML are efficient; the CML plots expected return against **total risk** $\sigma$.

**Systematic vs. nonsystematic risk.** Total risk = systematic (market, non-diversifiable) + nonsystematic (unique, diversifiable). Because nonsystematic risk can be diversified away for free, **investors are compensated only for systematic risk**. **Beta** measures systematic risk: the sensitivity of an asset's return to the market's. The market has a beta of 1; the risk-free asset has a beta of 0.

**The market model** decomposes returns: $R_i = \alpha_i + \beta_i R_m + e_i$. Beta can be estimated as the slope of the regression of asset returns on market returns.

**CAPM** gives the required return on any asset as the risk-free rate plus beta times the market risk premium. Its assumptions: risk-averse, utility-maximizing investors; frictionless markets (no taxes, transaction costs); a single holding period; homogeneous expectations; infinitely divisible assets; price-taking investors.

**Security market line (SML)** is CAPM graphed: expected return against **beta**. It applies to *all* assets and portfolios, efficient or not. An asset plotting **above** the SML offers more return than required: it is **undervalued**. One plotting **below** is overvalued.

**Beyond CAPM**: multifactor models (Fama-French size and value factors, momentum; arbitrage pricing theory) explain returns better.

**Performance measures.**

- **Sharpe ratio**: excess return per unit of **total** risk. Use for a portfolio that is the investor's total holdings. Ratios rank but do not tell you *how much* better.
- **Treynor ratio**: excess return per unit of **systematic** risk (beta). Use for a well-diversified portfolio held as part of a larger one.
- **M-squared ($M^2$)**: leverages or de-leverages the portfolio to match the market's total risk and compares returns; gives the same ranking as Sharpe but in percentage terms.
- **Jensen's alpha**: actual return minus the CAPM required return; positive alpha means outperformance on a systematic-risk basis.""",
"formulas": [
{"name": "Capital market line", "tex": r"E(R_p) = R_f + \frac{E(R_m) - R_f}{\sigma_m}\,\sigma_p", "vars": [["E(R_m), \\sigma_m", "expected return and risk of the market portfolio"]], "note": ""},
{"name": "Beta", "tex": r"\beta_i = \frac{Cov(R_i, R_m)}{\sigma_m^2} = \rho_{i,m}\,\frac{\sigma_i}{\sigma_m}", "vars": [["\\rho_{i,m}", "correlation of asset with market"]], "note": ""},
{"name": "CAPM / security market line", "tex": r"E(R_i) = R_f + \beta_i\left[E(R_m) - R_f\right]", "vars": [["E(R_m) - R_f", "market risk premium"]], "note": ""},
{"name": "Total risk decomposition", "tex": r"\sigma_i^2 = \beta_i^2\sigma_m^2 + \sigma_e^2", "vars": [["\\sigma_e^2", "nonsystematic (diversifiable) variance"]], "note": ""},
{"name": "Sharpe and Treynor ratios", "tex": r"\text{Sharpe} = \frac{R_p - R_f}{\sigma_p} \qquad \text{Treynor} = \frac{R_p - R_f}{\beta_p}", "vars": [], "note": ""},
{"name": "M-squared and Jensen's alpha", "tex": r"M^2 = (R_p - R_f)\frac{\sigma_m}{\sigma_p} - (R_m - R_f) \qquad \alpha_p = R_p - \left[R_f + \beta_p(R_m - R_f)\right]", "vars": [], "note": ""},
],
"examples": [
{"title": "Beta and CAPM",
 "problem": "A stock's correlation with the market is 0.6, its standard deviation is 30% and the market's is 20%. Rf = 3% and the market risk premium is 6%. Compute beta and the required return. If analysts expect 9%, is the stock over- or undervalued?",
 "steps": [r"$\beta = 0.6 \times 30/20 = 0.90$.", r"$E(R) = 3\% + 0.90 \times 6\% = 8.4\%$.", r"Expected 9% > required 8.4%: plots above the SML."],
 "answer": "Beta 0.90; required return 8.4%; undervalued."},
{"title": "Performance evaluation",
 "problem": "A portfolio returned 12% with sigma 18% and beta 1.1. The market returned 10% with sigma 15%. Rf = 3%. Compute Sharpe, Treynor, M-squared and Jensen's alpha.",
 "steps": [r"Sharpe $= (12 - 3)/18 = 0.50$; market Sharpe $= 7/15 = 0.467$.",
           r"Treynor $= 9/1.1 = 8.18\%$; market Treynor $= 7/1 = 7.0\%$.",
           r"$M^2 = 9 \times (15/18) - 7 = 7.5 - 7.0 = 0.50\%$.",
           r"$\alpha = 12 - [3 + 1.1(7)] = 12 - 10.7 = 1.30\%$."],
 "answer": "The portfolio beat the market on every measure: Sharpe 0.50, Treynor 8.18%, M-squared +0.50%, alpha +1.30%."},
],
},
{
"id": "ips",
"title": "Portfolio Planning, Construction and Behavioral Finance",
"body": r"""**The investment policy statement (IPS)** documents the client's objectives and constraints and the manager's duties. Typical contents: introduction, statement of purpose, duties and responsibilities, procedures for updating, **investment objectives**, **investment constraints**, investment guidelines, evaluation and review, appendices (strategic asset allocation, rebalancing policy).

**Objectives.**

- **Return objective**: absolute (e.g. 7% per year) or relative (benchmark + 1%); must be consistent with risk tolerance.
- **Risk objective**: absolute (e.g. no more than a 10% loss) or relative (tracking error). **Risk tolerance** combines **ability** to bear risk (time horizon, wealth relative to needs, stability of income) and **willingness** (psychology). When they conflict, the more conservative usually governs, unless the gap can be addressed by education.

**Constraints (LLTTU).** **L**iquidity, **L**egal and regulatory, **T**ime horizon, **T**ax concerns, **U**nique circumstances (including ESG preferences).

**Strategic asset allocation (SAA)** sets long-term target weights for asset classes, the main driver of portfolio return variation over time. Asset classes should be internally homogeneous and have low correlation with each other. **Tactical asset allocation** deviates temporarily to exploit short-term views. **Rebalancing** policies (calendar or percentage-range) keep the portfolio near target. **Core-satellite**: a passive core with active satellites. **ESG integration** approaches: negative screening (exclusion), positive screening (best-in-class), ESG integration into analysis, thematic investing, impact investing, and engagement/active ownership.

**Behavioral biases.** Biases are either **cognitive errors** (faulty reasoning; can often be corrected with better information and education) or **emotional biases** (feelings; harder to correct, often must be accommodated).

| Cognitive: belief perseverance | Cognitive: processing errors | Emotional |
|---|---|---|
| Conservatism (slow to update on new information) | Anchoring and adjustment | Loss aversion (holding losers, selling winners) |
| Confirmation (seeking supporting evidence) | Mental accounting (treating money by source or bucket) | Overconfidence |
| Representativeness (stereotypes, base-rate neglect) | Framing (decision depends on presentation) | Self-control (spending today over saving) |
| Illusion of control | Availability (easily recalled = probable) | Status quo |
| Hindsight | | Endowment (valuing what you own more) |
| | | Regret aversion (herding, inaction) |

Biases help explain market anomalies such as momentum (herding, availability), bubbles (overconfidence) and the value effect (representativeness).""",
"formulas": [],
"examples": [
{"title": "Ability vs. willingness",
 "problem": "A 35-year-old physician with high, stable income, substantial savings and no near-term needs tells her adviser she cannot stand to see her portfolio fall in value. Assess her risk tolerance.",
 "steps": ["Ability to bear risk: high (long horizon, stable income, wealth well above needs).", "Willingness: low.", "Conflict: the adviser should first educate; absent a change, the lower willingness generally governs."],
 "answer": "Above-average ability, below-average willingness: start with a moderate allocation and education."},
{"title": "Identify the bias",
 "problem": "An investor refuses to sell a stock that has fallen 40% because selling would 'make the loss real', while quickly selling stocks that have risen.",
 "steps": ["Avoiding the realization of losses and locking in gains is the disposition effect.", "It stems from loss aversion, an emotional bias."],
 "answer": "Loss aversion (emotional)."},
],
},
{
"id": "riskmgmt",
"title": "Introduction to Risk Management",
"body": r"""**Risk management** is the process of identifying the level of risk an organization wants, measuring the risk it has, and modifying the two to match. It is **not** about minimizing risk; it is about taking the *right* risks.

**Risk governance** is top-down: the board sets **risk tolerance** (what risks are acceptable and how much). **Risk budgeting** allocates the total risk tolerance across activities or asset classes (e.g. by tracking error, VaR or factor exposures). An enterprise-wide approach (ERM) considers all risks together.

**Sources of risk.**

- **Financial risks**: market risk (prices, rates, FX, commodities), credit risk, liquidity risk.
- **Non-financial risks**: operational (people, processes, systems, external events, including cyber), compliance and legal, model risk, tail risk, settlement risk, accounting, tax, solvency.
- Individuals also face mortality, longevity and health risk.

Risks interact: a market shock can trigger credit defaults and liquidity freezes, so risks should not be measured only in isolation.

**Measuring risk.** Standard deviation (total volatility), beta (equity market sensitivity), duration (rate sensitivity), **delta** (option sensitivity to the underlying), **gamma** (change in delta), **vega** (volatility sensitivity), **rho** (rate sensitivity). **Value at risk (VaR)** is a minimum loss with a stated probability over a period ("a 5% one-day VaR of USD 1M means a 5% chance of losing at least USD 1M in a day"); it says nothing about how bad losses could be beyond that point. **Conditional VaR (CVaR, expected shortfall)** is the average loss beyond VaR. **Scenario analysis and stress testing** examine extreme but plausible events.

**Modifying risk.**

- **Prevention and avoidance**: do not take the risk.
- **Acceptance**: self-insurance (bear it, perhaps with reserves) and diversification.
- **Transfer**: insurance (an insurer takes the risk for a premium).
- **Shifting**: derivatives that change the distribution of outcomes (forwards, futures, swaps, options).

The choice depends on cost, effectiveness and the organization's risk tolerance.""",
"formulas": [
{"name": "Value at risk (normal, parametric)", "tex": r"VaR = \left[E(R_p) - z\,\sigma_p\right]\times V_p \quad \text{(as a loss: } -\text{this value)}", "vars": [["z", "z-value for the confidence level (1.65 for 95% one-tailed, 2.33 for 99%)"], ["V_p", "portfolio value"]], "note": "Often simplified to $z\\sigma_p V_p$ when the expected return over the period is near zero."},
],
"examples": [
{"title": "Choosing a risk modification method",
 "problem": "A US exporter will receive EUR 10 million in six months and wants to eliminate the currency risk at low cost while keeping no upside. A second firm wants protection against a fall in the euro but to keep the benefit if it rises. Which tools fit?",
 "steps": ["Eliminating risk entirely, symmetrically: sell euros forward (risk shifting via a forward).", "Downside protection with upside retained: buy a euro put option (pay a premium)."],
 "answer": "Forward for the first firm; a put option for the second."},
],
},
],
"pitfalls": [
"CML uses TOTAL risk (sigma) and applies to efficient portfolios. SML uses BETA and applies to all assets.",
"Above the SML: undervalued (expected return > required). Below: overvalued.",
"Sharpe for a portfolio that is the investor's entire holdings; Treynor for a well-diversified sub-portfolio.",
"Utility U = E(r) - 0.5 A sigma^2 with decimals. Higher A = more risk averse.",
"Only systematic risk is priced. Beta = rho x sigma_i / sigma_m.",
"Cognitive errors can be corrected; emotional biases are accommodated.",
"IPS constraints: liquidity, legal, time horizon, taxes, unique circumstances.",
"Risk management is not risk minimization. VaR is a minimum loss at a probability, not the maximum loss.",
],
"problems": [
{"id": "p1", "section": "overview", "level": 2,
 "q": "Which investor type typically has the shortest time horizon and the highest liquidity needs?",
 "choices": {"A": "An endowment", "B": "A bank", "C": "A defined benefit pension plan with a young workforce"}, "answer": "B",
 "explanation": "Banks fund themselves with deposits that can be withdrawn and hold short-term, liquid assets."},
{"id": "p2", "section": "overview", "level": 2,
 "q": "In a defined contribution pension plan, investment risk is borne primarily by:",
 "choices": {"A": "the employer.", "B": "the employee.", "C": "the plan's actuary."}, "answer": "B",
 "explanation": "The employee's benefit depends on contributions and investment results."},
{"id": "p3", "section": "overview", "level": 2,
 "q": "The mechanism that keeps an ETF's market price close to its NAV is:",
 "choices": {"A": "daily redemptions at NAV by all investors.", "B": "creation and redemption by authorized participants.", "C": "a fixed number of shares outstanding."}, "answer": "B",
 "explanation": "APs arbitrage price-NAV gaps by creating or redeeming creation units."},
{"id": "p4", "section": "riskreturn", "level": 2,
 "q": "For an investor with A = 3, the utility of a portfolio with expected return 9% and standard deviation 15% is closest to:",
 "choices": {"A": "0.056", "B": "0.068", "C": "0.022"}, "answer": "A",
 "explanation": r"$0.09 - 0.5 \times 3 \times 0.0225 = 0.09 - 0.03375 = 0.05625$."},
{"id": "p5", "section": "riskreturn", "level": 2,
 "q": "Compared with a less risk-averse investor, a more risk-averse investor's indifference curves are:",
 "choices": {"A": "flatter.", "B": "steeper.", "C": "downward sloping."}, "answer": "B",
 "explanation": "A more risk-averse investor demands more extra return for each extra unit of risk."},
{"id": "p6", "section": "riskreturn", "level": 2,
 "q": "An investor puts 40% in a risk-free asset (4%) and 60% in a risky portfolio (expected return 10%, sigma 20%). The combined portfolio's expected return and standard deviation are:",
 "choices": {"A": "7.6% and 12%", "B": "7.6% and 20%", "C": "6.4% and 8%"}, "answer": "A",
 "explanation": r"$0.4(4\%) + 0.6(10\%) = 7.6\%$; $\sigma = 0.6 \times 20\% = 12\%$."},
{"id": "p7", "section": "riskreturn", "level": 2,
 "q": "According to the two-fund separation theorem, investors with different risk aversion will:",
 "choices": {"A": "hold different optimal risky portfolios.", "B": "hold the same optimal risky portfolio in different proportions with the risk-free asset.", "C": "hold only the risk-free asset."}, "answer": "B",
 "explanation": "The investment decision (optimal risky portfolio) is separate from the financing decision (how much in it)."},
{"id": "p8", "section": "capm", "level": 2,
 "q": "A stock has a standard deviation of 25%, the market's is 16% and their correlation is 0.64. The stock's beta is:",
 "choices": {"A": "0.41", "B": "1.00", "C": "1.56"}, "answer": "B",
 "explanation": r"$0.64 \times 25/16 = 1.00$."},
{"id": "p9", "section": "capm", "level": 1,
 "q": "Rf = 2.5%, expected market return 9%, beta 1.3. The CAPM required return is:",
 "choices": {"A": "11.70%", "B": "10.95%", "C": "8.45%"}, "answer": "B",
 "explanation": r"$2.5\% + 1.3 \times 6.5\% = 10.95\%$. A multiplies beta by the market return."},
{"id": "p10", "section": "capm", "level": 2,
 "q": "A stock with an expected return of 8% and a CAPM required return of 10% plots:",
 "choices": {"A": "above the SML and is undervalued.", "B": "below the SML and is overvalued.", "C": "on the CML."}, "answer": "B",
 "explanation": "Expected return below required return: overvalued; sell or avoid."},
{"id": "p11", "section": "capm", "level": 2,
 "q": "In a well-diversified portfolio, which risk is investors compensated for bearing?",
 "choices": {"A": "Total risk.", "B": "Nonsystematic risk.", "C": "Systematic risk."}, "answer": "C",
 "explanation": "Nonsystematic risk is diversifiable at no cost, so it earns no premium."},
{"id": "p12", "section": "capm", "level": 2,
 "q": "A portfolio returned 14% with sigma 20% and beta 1.2. Rf = 4%, the market returned 11% with sigma 16%. M-squared is closest to:",
 "choices": {"A": "+1.0%", "B": "+0.5%", "C": "-1.0%"}, "answer": "A",
 "explanation": r"$10 \times 16/20 - 7 = 8 - 7 = 1.0\%$."},
{"id": "p13", "section": "capm", "level": 2,
 "q": "Using the same data, Jensen's alpha is closest to:",
 "choices": {"A": "1.6%", "B": "3.0%", "C": "0.4%"}, "answer": "A",
 "explanation": r"$14 - [4 + 1.2(7)] = 14 - 12.4 = 1.6\%$."},
{"id": "p14", "section": "capm", "level": 2,
 "q": "For evaluating a well-diversified fund that is one of many held by a large pension plan, the most appropriate measure is the:",
 "choices": {"A": "Sharpe ratio.", "B": "Treynor ratio.", "C": "standard deviation."}, "answer": "B",
 "explanation": "Only systematic risk matters for a sub-portfolio of a diversified whole."},
{"id": "p15", "section": "ips", "level": 1,
 "q": "Which is an investment constraint in an IPS?",
 "choices": {"A": "Return objective", "B": "Tax concerns", "C": "Willingness to take risk"}, "answer": "B",
 "explanation": "Constraints: liquidity, legal, time horizon, taxes, unique circumstances."},
{"id": "p16", "section": "ips", "level": 2,
 "q": "An investor who keeps relying on an initial estimate of a company's earnings after new information arrives is exhibiting:",
 "choices": {"A": "anchoring and adjustment.", "B": "loss aversion.", "C": "endowment bias."}, "answer": "A",
 "explanation": "Anchoring is a cognitive (processing) error: insufficient adjustment from an initial value."},
{"id": "p17", "section": "ips", "level": 2,
 "q": "Which bias is emotional rather than cognitive?",
 "choices": {"A": "Confirmation bias", "B": "Mental accounting", "C": "Status quo bias"}, "answer": "C",
 "explanation": "Status quo bias is emotional; confirmation (belief perseverance) and mental accounting (processing error) are cognitive."},
{"id": "p18", "section": "ips", "level": 2,
 "q": "Excluding tobacco and weapons manufacturers from a portfolio is an example of:",
 "choices": {"A": "positive screening.", "B": "negative screening.", "C": "impact investing."}, "answer": "B",
 "explanation": "Exclusion based on ESG criteria is negative screening."},
{"id": "p19", "section": "riskmgmt", "level": 2,
 "q": "A portfolio's 5% one-day VaR is USD 2 million. This means:",
 "choices": {"A": "the maximum one-day loss is USD 2 million.", "B": "there is a 5% chance of a one-day loss of at least USD 2 million.", "C": "the expected one-day loss is USD 2 million."}, "answer": "B",
 "explanation": "VaR is a minimum loss at a given probability, not a maximum."},
{"id": "p20", "section": "riskmgmt", "level": 2,
 "q": "Purchasing a put option to limit the downside on a stock position is an example of risk:",
 "choices": {"A": "avoidance.", "B": "transfer.", "C": "shifting."}, "answer": "C",
 "explanation": "Derivatives that reshape the payoff distribution shift risk; insurance transfers risk."},
{"id": "p21", "section": "riskmgmt", "level": 2,
 "q": "Which statement about risk management is most accurate?",
 "choices": {"A": "Its goal is to minimize risk.", "B": "It aligns the risks taken with the organization's risk tolerance.", "C": "It is primarily the responsibility of individual traders."}, "answer": "B",
 "explanation": "Risk governance sets tolerance from the top; risk management keeps actual risk aligned with it."},
],
}

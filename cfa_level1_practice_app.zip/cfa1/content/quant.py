TOPIC = {
"id": "quant",
"name": "Quantitative Methods",
"weight": "6-9%",
"overview": r"""Quantitative Methods is the toolkit the rest of the curriculum leans on. Time value of money reappears in bond pricing, equity valuation, capital budgeting and pension accounting; return measurement reappears in portfolio management; statistics and regression reappear in every empirical question you will see. The exam rewards *speed and precision with the calculator* more than depth, so the goal here is to know each formula cold and recognize which one a question is asking for.

The modules are: rates and returns, time value of money in finance, statistical measures of asset returns, probability trees and conditional expectations, portfolio mathematics, simulation methods, estimation and inference, hypothesis testing, parametric and non-parametric tests of independence, simple linear regression, and an introduction to big data techniques.""",
"sections": [
{
"id": "returns",
"title": "Rates and Returns",
"body": r"""An interest rate can be read three ways: as a **required rate of return** (the minimum an investor demands), as a **discount rate** (what converts a future cash flow into today's value) and as an **opportunity cost** (what you give up by consuming today). It decomposes as:

$$\begin{aligned} r = {} & \text{real risk-free rate} + \text{inflation premium} \\ & + \text{default risk premium} + \text{liquidity premium} + \text{maturity premium}\end{aligned}$$

The nominal risk-free rate is the real risk-free rate plus the inflation premium; T-bills are the usual proxy.

**Holding period return (HPR)** is the total return over any holding period: price change plus income, divided by the starting price. To combine several periods you have three averaging choices, and the exam tests when to use which:

- **Arithmetic mean**: the simple average of period returns. It is the best estimate of a *single* future period's expected return, but it overstates multi-period compound growth.
- **Geometric mean**: the constant compound rate that turns the starting value into the ending value. Use it for past multi-period performance. It is always at or below the arithmetic mean, and the gap widens with volatility (roughly $\bar R_G \approx \bar R_A - \sigma^2/2$).
- **Harmonic mean**: the average price paid under *cost averaging* (a fixed amount of money invested each period). It is always at or below the geometric mean.

**Money-weighted vs. time-weighted returns.** The money-weighted return (MWR) is simply the IRR of the investor's cash flows, so it is affected by the *timing and size* of contributions and withdrawals. The time-weighted return (TWR) breaks the period at every external cash flow, computes each sub-period HPR and chains them geometrically, so it strips out the effect of flows. Because a portfolio manager usually does not control client flows, **TWR is the industry standard for evaluating managers** (and is required by GIPS). If a client adds money just before a strong period, MWR > TWR.

**Annualizing.** Convert a return over a period of $t$ years (or any fraction) with $(1+r_{\text{period}})^{1/t}-1$. A 3-month return of 2% annualizes to $1.02^4-1 = 8.24\%$.

**Continuously compounded return** is $\ln(P_1/P_0)$. Continuously compounded returns are *additive* across time, which is why they are used in models.

**Other return measures.** Gross return is before management and administrative fees (but after trading costs); net return is after all fees. Pre-tax vs. after-tax and nominal vs. real follow the obvious logic. A **leveraged return** magnifies the unlevered return: you earn the portfolio return on your equity plus the spread between the portfolio return and the borrowing cost on the borrowed amount.""",
"formulas": [
{"name": "Holding period return", "tex": r"HPR = \frac{P_1 - P_0 + D_1}{P_0}",
 "vars": [["P_0", "beginning price"], ["P_1", "ending price"], ["D_1", "income (dividend, coupon) received during the period"]],
 "note": "Works for any length of period; it is not annualized."},
{"name": "Arithmetic mean return", "tex": r"\bar R_A = \frac{1}{T}\sum_{t=1}^{T} R_t",
 "vars": [["R_t", "return in period t"], ["T", "number of periods"]], "note": ""},
{"name": "Geometric mean return", "tex": r"\bar R_G = \left[\prod_{t=1}^{T}(1+R_t)\right]^{1/T} - 1",
 "vars": [["R_t", "return in period t"], ["T", "number of periods"]],
 "note": "Calculator: multiply the (1+R) terms, raise to 1/T, subtract 1."},
{"name": "Harmonic mean", "tex": r"\bar X_H = \frac{n}{\sum_{i=1}^{n} 1/X_i}",
 "vars": [["X_i", "observation i (e.g. purchase price)"], ["n", "number of observations"]],
 "note": "Ordering for any non-identical positive data: harmonic < geometric < arithmetic."},
{"name": "Money-weighted return (IRR)", "tex": r"\sum_{t=0}^{T}\frac{CF_t}{(1+MWR)^t} = 0",
 "vars": [["CF_t", "net cash flow at t (outflows negative, inflows positive)"], ["MWR", "the internal rate of return"]],
 "note": "Calculator: CF0, C01, C02, ... then IRR CPT."},
{"name": "Time-weighted return", "tex": r"TWR = \left[(1+HPR_1)(1+HPR_2)\cdots(1+HPR_N)\right]^{1/Y} - 1",
 "vars": [["HPR_i", "return of sub-period i (split at every external cash flow)"], ["Y", "number of years spanned"]],
 "note": ""},
{"name": "Continuously compounded return", "tex": r"r_{cc} = \ln\left(\frac{P_1}{P_0}\right) = \ln(1+HPR)",
 "vars": [["P_1/P_0", "price relative"]], "note": "Converting back: $HPR = e^{r_{cc}}-1$."},
{"name": "Real return (Fisher relation)", "tex": r"(1+r_{nominal}) = (1+r_{real})(1+\pi)",
 "vars": [["\\pi", "inflation rate"]], "note": "Approximation $r_{real} \\approx r_{nominal} - \\pi$ is fine only when rates are small."},
{"name": "Leveraged portfolio return", "tex": r"R_L = R_p + \frac{V_B}{V_E}\left(R_p - r_D\right)",
 "vars": [["R_p", "return on the total (unlevered) portfolio"], ["V_B", "amount borrowed"], ["V_E", "equity contributed"], ["r_D", "borrowing rate"]], "note": ""},
],
"examples": [
{"title": "Arithmetic vs. geometric mean",
 "problem": "A fund returns +50% in year 1 and -50% in year 2. Compute the arithmetic and geometric mean returns, and the ending value of USD 100.",
 "steps": [r"Arithmetic: $(50\% + (-50\%))/2 = 0\%$.",
           r"Geometric: $[(1.50)(0.50)]^{1/2} - 1 = \sqrt{0.75} - 1 = -13.40\%$.",
           r"Ending value: $100 \times 1.50 \times 0.50 = 75$. Check: $100 \times (1-0.1340)^2 = 75.0$."],
 "answer": "Arithmetic 0%, geometric -13.40%. Only the geometric mean reproduces the actual loss, which is why it is used for multi-period performance."},
{"title": "Money-weighted vs. time-weighted return",
 "problem": "An investor buys 1 share at USD 100 at t = 0. At t = 1 the share is USD 120, pays a USD 2 dividend, and the investor buys a second share. At t = 2 the share is USD 130, pays a USD 2 dividend per share, and the investor sells both shares. Compute the MWR and TWR.",
 "steps": [r"Cash flows to the investor: $CF_0 = -100$; $CF_1 = -120 + 2 = -118$; $CF_2 = 2(130) + 2(2) = 264$.",
           r"MWR: solve $-100 - \dfrac{118}{1+r} + \dfrac{264}{(1+r)^2} = 0$ (CF0 = -100, C01 = -118, C02 = 264, IRR) giving $r = 13.86\%$.",
           r"TWR sub-period 1: $(120 + 2 - 100)/100 = 22.0\%$. Sub-period 2 (per share): $(130 + 2 - 120)/120 = 10.0\%$.",
           r"TWR $= [(1.22)(1.10)]^{1/2} - 1 = 15.84\%$ per year."],
 "answer": "MWR = 13.86%, TWR = 15.84%. MWR is lower because the investor doubled the position just before the weaker (10%) period."},
{"title": "Real return and continuous compounding",
 "problem": "A bond fund earned a nominal 7% while inflation was 3%. Separately, a stock moved from USD 50 to USD 55. Find the exact real return of the fund and the stock's continuously compounded return.",
 "steps": [r"Real: $1.07/1.03 - 1 = 3.88\%$ (the 4% approximation overstates it).",
           r"Continuous: $\ln(55/50) = \ln(1.10) = 9.53\%$."],
 "answer": "Real return 3.88%; continuously compounded return 9.53%."},
],
},
{
"id": "tvm",
"title": "Time Value of Money",
"body": r"""Every valuation problem at Level I is the same idea: **value equals the present value of expected future cash flows, discounted at a rate that reflects their risk.** The mechanics are a handful of formulas plus disciplined use of the calculator (N, I/Y, PV, PMT, FV).

**Compounding frequency.** A stated annual rate $r_s$ compounded $m$ times per year has a periodic rate of $r_s/m$ and an **effective annual rate (EAR)** of $(1 + r_s/m)^m - 1$. As $m \to \infty$, EAR $\to e^{r_s}-1$. Always match the periodic rate to the payment frequency: monthly payments need a monthly rate and N measured in months.

**Annuities.** An *ordinary annuity* pays at the end of each period (most loans, bonds). An *annuity due* pays at the beginning (rent, insurance premiums); its value is the ordinary value times $(1+r)$, because every cash flow arrives one period earlier. On the calculator use BGN mode, and remember to switch back to END.

**Perpetuities** pay forever. A level perpetuity is worth $PMT/r$; a growing perpetuity is the Gordon growth formula $CF_1/(r-g)$, which requires $r > g$. Preferred stock and the terminal value in a DDM are perpetuities.

**Cash flow additivity.** Any stream can be broken into pieces, valued separately and added. This principle underlies no-arbitrage pricing: a bond is a portfolio of zero-coupon bonds, and two portfolios with identical cash flows must have the same price.

**Implied returns and growth.** If price and expected cash flows are known, solve for the discount rate: for a bond that is the yield to maturity; for a stock priced with a constant growth model, $r = D_1/P_0 + g$, i.e. dividend yield plus growth. Implied growth works the other way: $g = r - D_1/P_0$.

**Common traps.** (1) Mixing BGN/END. (2) Forgetting that a deferred annuity's PV formula lands one period *before* the first payment. (3) Using a stated rate where the EAR is required, or the reverse. (4) Sign conventions: PV and FV must have opposite signs on the calculator when there is no PMT.""",
"formulas": [
{"name": "Future value / present value of a single sum", "tex": r"FV_N = PV(1+r)^N \qquad PV = \frac{FV_N}{(1+r)^N}",
 "vars": [["r", "rate per period"], ["N", "number of periods"]], "note": ""},
{"name": "Effective annual rate", "tex": r"EAR = \left(1+\frac{r_s}{m}\right)^m - 1 \qquad EAR_{cont} = e^{r_s}-1",
 "vars": [["r_s", "stated (quoted) annual rate"], ["m", "compounding periods per year"]], "note": ""},
{"name": "Present value of an ordinary annuity", "tex": r"PV = PMT \times \frac{1-(1+r)^{-N}}{r}",
 "vars": [["PMT", "level payment at the end of each period"], ["r", "rate per period"], ["N", "number of payments"]],
 "note": "Annuity due: multiply by $(1+r)$."},
{"name": "Future value of an ordinary annuity", "tex": r"FV = PMT \times \frac{(1+r)^N - 1}{r}",
 "vars": [["PMT", "level payment"], ["r", "rate per period"], ["N", "number of payments"]], "note": ""},
{"name": "Perpetuity and growing perpetuity", "tex": r"PV = \frac{PMT}{r} \qquad PV_0 = \frac{CF_1}{r-g}",
 "vars": [["CF_1", "cash flow one period from now"], ["g", "constant growth rate, g < r"]], "note": "Note $CF_1 = CF_0(1+g)$: the formula uses next period's cash flow."},
],
"examples": [
{"title": "Retirement annuity, ordinary vs. due",
 "problem": "What lump sum is needed today to fund USD 50,000 per year for 20 years at 6%, (a) if payments are at year-end, (b) if payments are at the start of each year?",
 "steps": [r"(a) $PV = 50{,}000 \times \dfrac{1 - 1.06^{-20}}{0.06} = 50{,}000 \times 11.4699 = 573{,}496$. Calculator: N = 20, I/Y = 6, PMT = 50,000, FV = 0, CPT PV.",
           r"(b) Annuity due: $573{,}496 \times 1.06 = 607{,}906$."],
 "answer": "USD 573,496 (ordinary) and USD 607,906 (annuity due)."},
{"title": "Mortgage payment and EAR",
 "problem": "A USD 400,000 30-year mortgage carries a stated rate of 6% compounded monthly. Find the monthly payment and the EAR.",
 "steps": [r"Periodic rate $= 0.06/12 = 0.5\%$; $N = 360$.",
           r"$PMT = \dfrac{400{,}000 \times 0.005}{1 - 1.005^{-360}} = 2{,}398.20$.",
           r"$EAR = 1.005^{12} - 1 = 6.17\%$."],
 "answer": "Monthly payment USD 2,398.20; EAR 6.17%."},
{"title": "Savings goal (sinking fund)",
 "problem": "You want USD 1,000,000 in 25 years and can earn 7% annually. What equal year-end deposit is needed?",
 "steps": [r"Solve the FV annuity formula for PMT: $PMT = \dfrac{FV \times r}{(1+r)^N - 1} = \dfrac{1{,}000{,}000 \times 0.07}{1.07^{25} - 1}$.",
           r"$1.07^{25} = 5.4274$, so $PMT = 70{,}000/4.4274 = 15{,}811$.",
           r"Calculator: N = 25, I/Y = 7, PV = 0, FV = 1,000,000, CPT PMT."],
 "answer": "About USD 15,811 per year."},
],
},
{
"id": "stats",
"title": "Statistical Measures of Asset Returns",
"body": r"""**Central tendency.** Mean, median (middle observation, robust to outliers) and mode. A trimmed mean drops a fixed percentage of the extremes; a winsorized mean replaces them with the cutoff values.

**Location.** Quartiles, quintiles, deciles and percentiles. The position of the $y$-th percentile in $n$ sorted observations is $L_y = (n+1)\,y/100$; interpolate when it is not a whole number. The interquartile range is $Q_3 - Q_1$; a box-and-whisker plot shows it.

**Dispersion.** Range, mean absolute deviation (MAD), variance and standard deviation. Use $n-1$ in the denominator for a *sample* (this corrects bias); population formulas divide by $N$. The **coefficient of variation** $CV = s/\bar X$ measures risk per unit of return and is unit-free, so it compares assets with very different return levels (lower is better).

**Downside risk.** Investors dislike losses more than they like gains, so we also measure only the bad side. **Target downside deviation** (target semideviation) uses only observations below a target $B$, but still divides by $n-1$ (the full sample size).

**Shape.** **Skewness** measures asymmetry. A positively (right) skewed distribution has a long right tail and mean > median > mode; a negatively skewed one has mean < median < mode (think: the mean is pulled toward the tail). **Kurtosis** measures tail weight; the normal has kurtosis 3, so *excess kurtosis* = kurtosis - 3. Positive excess kurtosis (leptokurtic, "fat tails") means more extreme outcomes than the normal predicts, which is typical for asset returns. Investors prefer positive skew and dislike fat tails.

**Correlation** between two variables is their covariance scaled by both standard deviations, bounded between -1 and +1. It measures only *linear* association; zero correlation does not imply independence, outliers can distort it, and it can be spurious.""",
"formulas": [
{"name": "Sample variance and standard deviation", "tex": r"s^2 = \frac{\sum_{i=1}^{n}(X_i - \bar X)^2}{n-1} \qquad s = \sqrt{s^2}",
 "vars": [["X_i", "observation i"], ["\\bar X", "sample mean"], ["n", "sample size"]], "note": "Population variance divides by N instead of n - 1."},
{"name": "Mean absolute deviation", "tex": r"MAD = \frac{\sum_{i=1}^{n}|X_i - \bar X|}{n}", "vars": [], "note": ""},
{"name": "Coefficient of variation", "tex": r"CV = \frac{s}{\bar X}", "vars": [["s", "standard deviation"], ["\\bar X", "mean"]], "note": "Lower CV = less risk per unit of return."},
{"name": "Target downside deviation", "tex": r"s_{Target} = \sqrt{\frac{\sum_{X_i \le B}(X_i - B)^2}{n-1}}",
 "vars": [["B", "target return"], ["n", "total number of observations (not just those below B)"]], "note": ""},
{"name": "Sample correlation", "tex": r"r_{XY} = \frac{s_{XY}}{s_X s_Y} \qquad s_{XY} = \frac{\sum (X_i-\bar X)(Y_i - \bar Y)}{n-1}", "vars": [["s_{XY}", "sample covariance"]], "note": ""},
{"name": "Percentile location", "tex": r"L_y = (n+1)\frac{y}{100}", "vars": [["y", "percentile"], ["n", "number of observations (sorted ascending)"]], "note": ""},
],
"examples": [
{"title": "Dispersion measures for a return series",
 "problem": "Annual returns: 5%, -2%, 8%, 12%, 2%. Compute the mean, sample standard deviation, CV and the target downside deviation for a 3% target.",
 "steps": [r"Mean $= (5 - 2 + 8 + 12 + 2)/5 = 5.0\%$.",
           r"Squared deviations: $0, 49, 9, 49, 9$; sum $= 116$. $s^2 = 116/4 = 29$, so $s = 5.39\%$.",
           r"$CV = 5.39/5.0 = 1.08$.",
           r"Below 3%: only -2% and 2%. Squared shortfalls: $(-2-3)^2 = 25$ and $(2-3)^2 = 1$. $s_{Target} = \sqrt{26/4} = 2.55\%$."],
 "answer": "Mean 5.0%, s = 5.39%, CV = 1.08, target downside deviation 2.55%."},
],
},
{
"id": "prob",
"title": "Probability, Expectations and Portfolio Mathematics",
"body": r"""**Probability rules.** For any events A and B:

- Multiplication rule (joint probability): $P(AB) = P(A|B)\,P(B)$. If independent, $P(AB) = P(A)P(B)$.
- Addition rule: $P(A \text{ or } B) = P(A) + P(B) - P(AB)$. If mutually exclusive, $P(AB)=0$.
- Total probability: $P(A) = P(A|S_1)P(S_1) + P(A|S_2)P(S_2) + \dots$ for mutually exclusive, exhaustive scenarios $S_i$.

**Odds.** Odds *for* E $= P(E)/[1-P(E)]$. Odds of "1 to 4" for an event mean $P = 1/5 = 20\%$.

**Expected value and variance** of a random variable are probability-weighted. A **probability tree** organizes conditional scenarios: multiply along branches for joint probabilities, add across branches for the total. The conditional expectation $E(X|S)$ is the expected value within one scenario.

**Bayes' formula** updates a prior probability for new information. It is tested every year, and the cleanest approach is a frequency table: imagine 10,000 cases, split them by the prior, then by the conditional probabilities, and read the answer off.

**Portfolio mathematics.** Expected portfolio return is the weighted average of asset returns. Portfolio variance is *not* the weighted average of variances: it depends on covariances. With two assets the cross term is $2w_1w_2\rho_{12}\sigma_1\sigma_2$. As long as $\rho < 1$, the portfolio standard deviation is less than the weighted average of the standard deviations: that gap is the diversification benefit.

**Safety-first ratio.** Roy's safety-first criterion picks the portfolio that minimizes the probability of falling below a shortfall threshold $R_L$; under normality that means *maximizing* $SFRatio = [E(R_p) - R_L]/\sigma_p$. With $R_L$ equal to the risk-free rate it is the Sharpe ratio.

**Distributions.** The normal distribution is described fully by mean and variance; about 68% of outcomes lie within $\pm 1\sigma$, 90% within $\pm 1.645\sigma$, 95% within $\pm 1.96\sigma$, 99% within $\pm 2.58\sigma$. Standardize with $z = (X-\mu)/\sigma$. If continuously compounded returns are normal, the *price relative* is **lognormal**: bounded below by zero and right-skewed, which makes it the natural model for prices. Student's $t$ has fatter tails than the normal and converges to it as degrees of freedom rise; chi-square and F are asymmetric and bounded below by zero.

**Simulation.** Monte Carlo simulation draws random inputs from assumed distributions to estimate the distribution of an outcome (e.g. the value of a complex derivative, or a retirement plan's success rate). **Bootstrap** resampling draws repeatedly, with replacement, from the observed sample itself, so it needs no distributional assumption but cannot generate outcomes outside the data's experience.""",
"formulas": [
{"name": "Expected value and variance", "tex": r"E(X) = \sum P(X_i)X_i \qquad \sigma^2(X) = \sum P(X_i)\left[X_i - E(X)\right]^2",
 "vars": [["P(X_i)", "probability of outcome i"]], "note": ""},
{"name": "Bayes' formula", "tex": r"P(E\,|\,I) = \frac{P(I\,|\,E)}{P(I)}\,P(E)",
 "vars": [["P(E)", "prior probability of event E"], ["I", "new information"], ["P(I)", "unconditional probability of the information (total probability rule)"]], "note": ""},
{"name": "Covariance and correlation", "tex": r"Cov(R_i,R_j) = \sum P(s)\,[R_{i,s}-E(R_i)][R_{j,s}-E(R_j)] \qquad \rho_{ij} = \frac{Cov(R_i,R_j)}{\sigma_i\sigma_j}",
 "vars": [["s", "scenario"]], "note": ""},
{"name": "Two-asset portfolio variance", "tex": r"\sigma_p^2 = w_1^2\sigma_1^2 + w_2^2\sigma_2^2 + 2w_1w_2\rho_{12}\sigma_1\sigma_2",
 "vars": [["w_i", "portfolio weights (sum to 1)"], ["\\rho_{12}", "correlation of the two assets"]], "note": "The last term can also be written $2w_1w_2Cov_{12}$."},
{"name": "Roy's safety-first ratio", "tex": r"SFRatio = \frac{E(R_p) - R_L}{\sigma_p}",
 "vars": [["R_L", "minimum acceptable (threshold) return"]], "note": "Choose the portfolio with the highest SFRatio."},
{"name": "Standardizing a normal variable", "tex": r"z = \frac{X - \mu}{\sigma}", "vars": [], "note": ""},
],
"examples": [
{"title": "Bayes: a default-prediction model",
 "problem": "2% of borrowers default. A model flags 90% of borrowers who later default, and also flags 5% of borrowers who do not default. A borrower is flagged. What is the probability that the borrower defaults?",
 "steps": [r"Imagine 10,000 borrowers: 200 default, 9,800 do not.",
           r"Flagged defaulters: $0.90 \times 200 = 180$. Flagged non-defaulters: $0.05 \times 9{,}800 = 490$.",
           r"$P(\text{default}\,|\,\text{flag}) = 180/(180 + 490) = 26.9\%$."],
 "answer": "26.9%. Even an accurate-looking model gives a low posterior when the base rate is small."},
{"title": "Portfolio risk and the diversification benefit",
 "problem": "60% in stocks (sigma 20%) and 40% in bonds (sigma 10%), correlation 0.3. Compute portfolio standard deviation.",
 "steps": [r"$w_1^2\sigma_1^2 = 0.36 \times 0.04 = 0.0144$; $w_2^2\sigma_2^2 = 0.16 \times 0.01 = 0.0016$.",
           r"Cross term $= 2(0.6)(0.4)(0.3)(0.20)(0.10) = 0.00288$.",
           r"$\sigma_p^2 = 0.01888$, so $\sigma_p = 13.74\%$."],
 "answer": "13.74%, well below the 16% weighted average of the two standard deviations."},
{"title": "Safety-first selection",
 "problem": "A client must not lose money in real terms; inflation is 3%. Portfolio A: E(R) = 9%, sigma = 12%. Portfolio B: E(R) = 7%, sigma = 6%. Which is preferred?",
 "steps": [r"$SFR_A = (9 - 3)/12 = 0.50$; $SFR_B = (7-3)/6 = 0.67$.",
           r"Higher SFRatio means lower probability of falling below 3%."],
 "answer": "Portfolio B."},
],
},
{
"id": "inference",
"title": "Sampling, Estimation and Hypothesis Testing",
"body": r"""**Sampling.** Simple random sampling gives every member equal chance; stratified random sampling samples within subgroups in proportion to their size (used to build bond index funds). Cluster sampling samples whole groups. Non-probability methods (convenience, judgmental) are faster but risk bias.

**Central limit theorem.** For a sample of size $n \geq 30$ from any population with finite variance, the sample mean is approximately normal with mean $\mu$ and **standard error** $\sigma/\sqrt n$. This is what makes inference about means possible.

**Confidence intervals** have the form *point estimate* $\pm$ *reliability factor* $\times$ *standard error*. Use $z$ when the population variance is known (or the sample is large); use $t$ with $n-1$ degrees of freedom when the variance is unknown, which is the realistic case.

**Hypothesis testing, step by step.**

1. State $H_0$ (always contains the equals sign) and $H_a$ (what you hope to show).
2. Choose the test statistic and its distribution.
3. Choose the significance level $\alpha$.
4. State the decision rule (critical values).
5. Compute the statistic from the sample.
6. Decide: reject $H_0$ if the statistic falls in the rejection region. We never "accept" $H_0$; we "fail to reject" it.

**Errors.** A Type I error rejects a true null (probability $\alpha$). A Type II error fails to reject a false null (probability $\beta$). **Power** $= 1-\beta$. Lowering $\alpha$ raises $\beta$ for a given sample size; only a larger sample reduces both.

**p-value**: the smallest significance level at which the null can be rejected. Reject if $p < \alpha$.

**Which test?**

| Hypothesis about | Test statistic | Distribution |
|---|---|---|
| One mean | $t = (\bar X - \mu_0)/(s/\sqrt n)$ | $t$, df $= n-1$ |
| Difference in means (independent samples) | pooled $t$ | $t$, df $= n_1+n_2-2$ |
| Mean of differences (paired samples) | $t = \bar d/s_{\bar d}$ | $t$, df $= n-1$ |
| One variance | $\chi^2 = (n-1)s^2/\sigma_0^2$ | chi-square, df $= n-1$ |
| Equality of two variances | $F = s_1^2/s_2^2$ (larger on top) | $F$ |
| Correlation | $t = r\sqrt{n-2}/\sqrt{1-r^2}$ | $t$, df $= n-2$ |
| Independence (contingency table) | $\chi^2 = \sum (O-E)^2/E$ | chi-square, df $= (r-1)(c-1)$ |

**Non-parametric tests** (e.g. Spearman rank correlation, sign tests) are used when data are ranks, when distributional assumptions fail, or when there are outliers.""",
"formulas": [
{"name": "Standard error of the sample mean", "tex": r"s_{\bar X} = \frac{s}{\sqrt n}", "vars": [["s", "sample standard deviation"], ["n", "sample size"]], "note": ""},
{"name": "Confidence interval for the mean", "tex": r"\bar X \pm t_{\alpha/2}\,\frac{s}{\sqrt n}", "vars": [["t_{\\alpha/2}", "reliability factor (use z if the variance is known)"]],
 "note": "Common z values: 90% = 1.645, 95% = 1.96, 99% = 2.58."},
{"name": "t-test for a single mean", "tex": r"t_{n-1} = \frac{\bar X - \mu_0}{s/\sqrt n}", "vars": [["\\mu_0", "hypothesized mean"]], "note": ""},
{"name": "Test of a correlation", "tex": r"t = \frac{r\sqrt{n-2}}{\sqrt{1-r^2}}", "vars": [["r", "sample correlation"], ["n", "number of pairs"]], "note": "df = n - 2"},
{"name": "Chi-square test of independence", "tex": r"\chi^2 = \sum\frac{(O_{ij}-E_{ij})^2}{E_{ij}} \qquad E_{ij} = \frac{(\text{row } i \text{ total})(\text{col } j \text{ total})}{\text{grand total}}",
 "vars": [["O_{ij}", "observed frequency"], ["E_{ij}", "expected frequency under independence"]], "note": "df = (rows - 1)(columns - 1)"},
],
"examples": [
{"title": "Is a strategy's alpha different from zero?",
 "problem": "A strategy's mean monthly excess return over 36 months is 1.2% with a sample standard deviation of 4%. Test at the 5% level whether the mean differs from zero (critical t with 35 df is 2.03).",
 "steps": [r"$H_0: \mu = 0$; $H_a: \mu \neq 0$ (two-tailed).",
           r"Standard error $= 4/\sqrt{36} = 0.667\%$.",
           r"$t = 1.2/0.667 = 1.80$.",
           r"$|1.80| < 2.03$: fail to reject $H_0$."],
 "answer": "Not statistically significant at 5%. (It would be significant at 10%, where the critical value is about 1.69.)"},
],
},
{
"id": "regression",
"title": "Simple Linear Regression and Big Data",
"body": r"""Simple linear regression explains a **dependent variable** $Y$ with one **independent variable** $X$: $Y_i = b_0 + b_1X_i + \varepsilon_i$. Ordinary least squares (OLS) picks $\hat b_0$ and $\hat b_1$ to minimize the sum of squared residuals. The slope is the covariance of X and Y divided by the variance of X; the fitted line always passes through $(\bar X, \bar Y)$.

**Assumptions.** (1) Linearity in the parameters; (2) **homoskedasticity**: constant residual variance; (3) **independence** of residuals (no serial correlation); (4) **normality** of residuals. Violations show up in residual plots: a fan shape signals heteroskedasticity, patterns over time signal serial correlation.

**Analysis of variance.** Total variation splits into explained and unexplained parts: $SST = RSS + SSE$ (regression sum of squares + sum of squared errors). From the ANOVA table:

- $R^2 = RSS/SST$: the share of variation in Y explained by X. In simple regression $R^2 = r^2$.
- Standard error of estimate $SEE = \sqrt{MSE}$: the typical size of a residual. Smaller is better.
- $F = MSR/MSE$, with 1 and $n-2$ df, tests whether the slope is zero. In simple regression $F = t^2$ for the slope.

**Testing the slope.** $t = (\hat b_1 - B_1)/s_{\hat b_1}$ with $n-2$ df, usually against $B_1 = 0$. Testing $B_1 = 1$ is common for betas.

**Prediction.** $\hat Y = \hat b_0 + \hat b_1 X$. A prediction interval is wider than a confidence interval for the mean and widens as $X$ moves away from $\bar X$.

**Functional forms.** If the relationship is not linear, transform: log-lin ($\ln Y = b_0 + b_1X$, for constant growth rates), lin-log ($Y = b_0 + b_1\ln X$) and log-log ($\ln Y = b_0 + b_1 \ln X$, where $b_1$ is an elasticity).

**Big data.** Big data is characterized by volume, velocity, variety and veracity. Alternative data sources include individuals (social media, reviews), business processes (credit card transactions, scanner data) and sensors (satellite images, IoT). **Machine learning** is either *supervised* (labeled data: regression and classification) or *unsupervised* (no labels: clustering, dimension reduction); deep learning uses multi-layer neural networks. **Overfitting** (model memorizes noise and fails out of sample) and **underfitting** (model too simple) are the key risks; the data is split into training, validation and test sets to detect them. Natural language processing turns text (e.g. earnings call transcripts) into usable signals.""",
"formulas": [
{"name": "OLS slope and intercept", "tex": r"\hat b_1 = \frac{\sum (X_i-\bar X)(Y_i - \bar Y)}{\sum (X_i - \bar X)^2} = \frac{Cov(X,Y)}{Var(X)} \qquad \hat b_0 = \bar Y - \hat b_1 \bar X", "vars": [], "note": ""},
{"name": "Sum of squares decomposition", "tex": r"\underbrace{\sum(Y_i-\bar Y)^2}_{SST} = \underbrace{\sum(\hat Y_i-\bar Y)^2}_{RSS} + \underbrace{\sum(Y_i-\hat Y_i)^2}_{SSE}", "vars": [], "note": ""},
{"name": "Coefficient of determination", "tex": r"R^2 = \frac{RSS}{SST} = 1 - \frac{SSE}{SST}", "vars": [], "note": ""},
{"name": "Standard error of estimate and F-statistic", "tex": r"SEE = \sqrt{\frac{SSE}{n-2}} \qquad F = \frac{RSS/1}{SSE/(n-2)}", "vars": [["n", "number of observations"]], "note": "MSR = RSS / k and MSE = SSE / (n - k - 1), with k = 1 here."},
{"name": "t-test of the slope", "tex": r"t = \frac{\hat b_1 - B_1}{s_{\hat b_1}}", "vars": [["B_1", "hypothesized slope"], ["s_{\\hat b_1}", "standard error of the slope"]], "note": "df = n - 2"},
],
"examples": [
{"title": "Fit and evaluate a regression",
 "problem": "X = 2, 4, 6, 8, 10 and Y = 3, 5, 6, 9, 12. Estimate the regression, then compute R-squared, SEE and the F-statistic.",
 "steps": [r"$\bar X = 6$, $\bar Y = 7$. Deviations of X: -4, -2, 0, 2, 4; of Y: -4, -2, -1, 2, 5.",
           r"$\sum dx\,dy = 16+4+0+4+20 = 44$; $\sum dx^2 = 40$. So $\hat b_1 = 44/40 = 1.10$ and $\hat b_0 = 7 - 1.1(6) = 0.40$.",
           r"Fitted: 2.6, 4.8, 7.0, 9.2, 11.4. Residuals: 0.4, 0.2, -1.0, -0.2, 0.6, so $SSE = 1.60$.",
           r"$SST = 16+4+1+4+25 = 50$; $RSS = 50 - 1.6 = 48.4$; $R^2 = 48.4/50 = 0.968$.",
           r"$SEE = \sqrt{1.6/3} = 0.730$; $F = 48.4/(1.6/3) = 90.75$."],
 "answer": "Y-hat = 0.40 + 1.10X; R-squared 0.968; SEE 0.730; F = 90.75."},
],
},
],
"pitfalls": [
r"Arithmetic mean for forecasting one period ahead; geometric mean for describing past compound growth.",
r"MWR is the investor's IRR and depends on the timing of flows; TWR evaluates the manager.",
r"Sample variance divides by $n-1$; target downside deviation also divides by $n-1$, the full sample size.",
r"Positive skew: mean > median > mode. Excess kurtosis = kurtosis - 3.",
r"Annuity due = ordinary annuity $\times (1+r)$. Reset the calculator to END.",
r"In Bayes problems, build a frequency table; do not just reverse the conditional probability.",
r"Correlation measures only linear association. Zero correlation does not mean independence.",
r"Regression slope tests use $n-2$ degrees of freedom; in simple regression, $F = t^2$ and $R^2 = r^2$.",
],
"problems": [
{"id": "q1", "section": "returns", "level": 1,
 "q": r"A stock returned 15%, -10% and 20% over three years. Its geometric mean return is closest to:",
 "choices": {"A": "7.49%", "B": "7.92%", "C": "8.33%"}, "answer": "A",
 "explanation": r"$1.15 \times 0.90 \times 1.20 = 1.242$; $1.242^{1/3} - 1 = 7.49\%$. The arithmetic mean (8.33%) is the distractor; the geometric mean is always lower when returns vary."},
{"id": "q2", "section": "returns", "level": 2,
 "q": r"A client deposits a large sum into her account just before her manager's best quarter of the year. Compared with the time-weighted return, the money-weighted return for the year will most likely be:",
 "choices": {"A": "lower.", "B": "the same.", "C": "higher."}, "answer": "C",
 "explanation": r"MWR weights each period by the money invested. More money was invested during the strong quarter, so MWR exceeds TWR. TWR is unaffected by the timing of client flows."},
{"id": "q3", "section": "returns", "level": 1,
 "q": r"A share bought at USD 40 is sold one year later at USD 38 after paying a USD 3 dividend. The continuously compounded return is closest to:",
 "choices": {"A": "2.47%", "B": "2.50%", "C": "-5.13%"}, "answer": "A",
 "explanation": r"HPR $= (38 + 3 - 40)/40 = 2.5\%$. Continuously compounded $= \ln(1.025) = 2.47\%$. C ignores the dividend."},
{"id": "q4", "section": "returns", "level": 2,
 "q": r"An investor buys USD 1,000 of a fund every month for three months at NAVs of USD 20, USD 25 and USD 16. The average cost per share is closest to:",
 "choices": {"A": "19.67", "B": "20.33", "C": "19.87"}, "answer": "A",
 "explanation": r"Cost averaging uses the harmonic mean: $3/(1/20 + 1/25 + 1/16) = 3/0.1525 = 19.67$. The arithmetic mean of prices is 20.33."},
{"id": "q5", "section": "tvm", "level": 1,
 "q": r"A bank quotes 8% compounded quarterly. The effective annual rate is closest to:",
 "choices": {"A": "8.00%", "B": "8.24%", "C": "8.33%"}, "answer": "B",
 "explanation": r"$(1 + 0.08/4)^4 - 1 = 1.02^4 - 1 = 8.24\%$. C is the continuous compounding EAR."},
{"id": "q6", "section": "tvm", "level": 2,
 "q": r"A preferred stock pays USD 5 per year forever, with the first payment in one year. If the required return is 8%, its value is closest to:",
 "choices": {"A": "USD 62.50", "B": "USD 67.50", "C": "USD 57.87"}, "answer": "A",
 "explanation": r"Perpetuity: $5/0.08 = 62.50$. B treats it as a perpetuity due (adds the first payment today)."},
{"id": "q7", "section": "tvm", "level": 2,
 "q": r"An investor will receive USD 10,000 per year for 5 years, with the first payment 4 years from today. At 6%, the present value today is closest to:",
 "choices": {"A": "USD 35,368", "B": "USD 42,124", "C": "USD 33,366"}, "answer": "A",
 "explanation": r"The ordinary-annuity formula values the stream one period before the first payment, i.e. at t = 3: $10{,}000 \times 4.2124 = 42{,}124$. Discount 3 years: $42{,}124/1.06^3 = 35{,}368$. C discounts 4 years (the classic deferred-annuity mistake); B forgets to discount at all."},
{"id": "q8", "section": "tvm", "level": 2,
 "q": r"A stock trades at USD 50 and is expected to pay a USD 2 dividend next year, growing at a constant rate forever. If investors require 9%, the implied dividend growth rate is closest to:",
 "choices": {"A": "4.0%", "B": "5.0%", "C": "9.0%"}, "answer": "B",
 "explanation": r"$g = r - D_1/P_0 = 9\% - 2/50 = 9\% - 4\% = 5.0\%$."},
{"id": "q9", "section": "stats", "level": 1,
 "q": r"A return distribution has a mean of 6%, a median of 8% and a mode of 9%. The distribution is most likely:",
 "choices": {"A": "positively skewed.", "B": "negatively skewed.", "C": "symmetric."}, "answer": "B",
 "explanation": r"Mean < median < mode: the mean is pulled toward a long left tail, i.e. negative skew."},
{"id": "q10", "section": "stats", "level": 1,
 "q": r"Fund X has a mean return of 10% and standard deviation of 15%; fund Y has a mean of 6% and standard deviation of 8%. Based on the coefficient of variation:",
 "choices": {"A": "X has less risk per unit of return.", "B": "Y has less risk per unit of return.", "C": "the funds are equally risky per unit of return."}, "answer": "B",
 "explanation": r"$CV_X = 15/10 = 1.50$; $CV_Y = 8/6 = 1.33$. Lower CV means less risk per unit of return."},
{"id": "q11", "section": "stats", "level": 2,
 "q": r"A distribution with excess kurtosis of 2.0 compared with a normal distribution is best described as:",
 "choices": {"A": "platykurtic, with thinner tails.", "B": "mesokurtic.", "C": "leptokurtic, with fatter tails."}, "answer": "C",
 "explanation": r"Positive excess kurtosis means fatter tails and a higher probability of extreme outcomes than the normal: leptokurtic."},
{"id": "q12", "section": "prob", "level": 2,
 "q": r"60% of an analyst's buy recommendations are on stocks that later outperform. The probability that a stock outperforms is 40%, and the analyst recommends 30% of all stocks. Given that a stock outperforms, the probability it had a buy recommendation is closest to:",
 "choices": {"A": "18%", "B": "45%", "C": "72%"}, "answer": "B",
 "explanation": r"$P(\text{Buy}\,|\,\text{Out}) = P(\text{Out}\,|\,\text{Buy})P(\text{Buy})/P(\text{Out}) = 0.60 \times 0.30/0.40 = 0.45$. A is the joint probability."},
{"id": "q13", "section": "prob", "level": 2,
 "q": r"Two assets each have a standard deviation of 20% and are combined 50/50. If their correlation is -1, the portfolio standard deviation is:",
 "choices": {"A": "0%", "B": "10%", "C": "20%"}, "answer": "A",
 "explanation": r"With $\rho = -1$, $\sigma_p = |w_1\sigma_1 - w_2\sigma_2| = |0.5(20) - 0.5(20)| = 0$. Perfect negative correlation allows a riskless combination."},
{"id": "q14", "section": "prob", "level": 1,
 "q": r"If continuously compounded returns are normally distributed, then future asset prices are best described as:",
 "choices": {"A": "normally distributed.", "B": "lognormally distributed.", "C": "uniformly distributed."}, "answer": "B",
 "explanation": r"$P_T = P_0 e^{r}$; if $r$ is normal, $P_T$ is lognormal: bounded below by zero and right-skewed."},
{"id": "q15", "section": "prob", "level": 2,
 "q": r"Which method of simulation is limited to the patterns present in the historical data?",
 "choices": {"A": "Monte Carlo simulation", "B": "Bootstrap resampling", "C": "Both equally"}, "answer": "B",
 "explanation": r"Bootstrap resamples the observed data with replacement, so it cannot produce outcomes outside the sample's experience. Monte Carlo draws from an assumed distribution."},
{"id": "q16", "section": "inference", "level": 2,
 "q": r"Holding the sample size constant, decreasing the significance level from 5% to 1% will most likely:",
 "choices": {"A": "increase the probability of a Type II error.", "B": "increase the probability of a Type I error.", "C": "increase the power of the test."}, "answer": "A",
 "explanation": r"A lower $\alpha$ makes it harder to reject the null, so false nulls are rejected less often: $\beta$ (Type II) rises and power falls."},
{"id": "q17", "section": "inference", "level": 2,
 "q": r"A sample of 25 monthly returns has a mean of 1.5% and a standard deviation of 5%. The 95% confidence interval for the population mean (t critical = 2.064) is closest to:",
 "choices": {"A": "-0.56% to 3.56%", "B": "-0.46% to 3.46%", "C": "-8.82% to 11.82%"}, "answer": "A",
 "explanation": r"SE $= 5/\sqrt{25} = 1.0\%$. Interval $= 1.5 \pm 2.064(1.0) = -0.56\%$ to $3.56\%$. B uses $z = 1.96$; C forgets to divide by $\sqrt n$."},
{"id": "q18", "section": "inference", "level": 2,
 "q": r"An analyst wants to test whether the variance of returns is the same for two independent samples. The appropriate test statistic follows a:",
 "choices": {"A": "t-distribution.", "B": "chi-square distribution.", "C": "F-distribution."}, "answer": "C",
 "explanation": r"Equality of two variances uses $F = s_1^2/s_2^2$. A single variance uses chi-square."},
{"id": "q19", "section": "inference", "level": 3,
 "q": r"A sample correlation of 0.30 is computed from 30 pairs. The t-statistic for testing whether the population correlation is zero is closest to:",
 "choices": {"A": "1.56", "B": "1.66", "C": "1.72"}, "answer": "B",
 "explanation": r"$t = 0.30\sqrt{28}/\sqrt{1 - 0.09} = 0.30(5.2915)/0.9539 = 1.664$."},
{"id": "q20", "section": "regression", "level": 1,
 "q": r"In a simple linear regression, the residual plot shows that the spread of residuals increases as X increases. This most likely violates the assumption of:",
 "choices": {"A": "linearity.", "B": "homoskedasticity.", "C": "independence."}, "answer": "B",
 "explanation": r"A fan-shaped residual plot indicates the residual variance is not constant: heteroskedasticity."},
{"id": "q21", "section": "regression", "level": 2,
 "q": r"A regression with 32 observations has SST = 200 and SSE = 60. The F-statistic is closest to:",
 "choices": {"A": "70.0", "B": "2.33", "C": "7.0"}, "answer": "A",
 "explanation": r"$RSS = 200 - 60 = 140$. $MSE = 60/30 = 2.0$. $F = 140/2.0 = 70$. $R^2 = 0.70$."},
{"id": "q22", "section": "regression", "level": 2,
 "q": r"In the model $\ln(\text{Sales}) = b_0 + b_1 \ln(\text{Advertising})$, the slope coefficient $b_1$ is best interpreted as:",
 "choices": {"A": "the change in sales for a one-unit change in advertising.", "B": "the percentage change in sales for a 1% change in advertising.", "C": "the absolute change in sales for a 1% change in advertising."}, "answer": "B",
 "explanation": r"In a log-log model the slope is an elasticity: % change in Y per 1% change in X."},
{"id": "q23", "section": "regression", "level": 1,
 "q": r"A machine learning model performs very well on training data but poorly on new data. This is best described as:",
 "choices": {"A": "underfitting.", "B": "overfitting.", "C": "unsupervised learning."}, "answer": "B",
 "explanation": r"Fitting noise in the training data so that the model fails to generalize is overfitting."},
],
}

TOPIC = {
"id": "alts",
"name": "Alternative Investments",
"weight": "7-10%",
"overview": r"""Alternative investments are anything outside long-only public stocks, bonds and cash: private equity, private debt, real estate, infrastructure, natural resources (commodities, farmland, timberland), hedge funds and digital assets. The common features are **illiquidity, high fees, complex legal structures, limited transparency and return data that understates risk** (smoothed appraisals, survivorship and backfill bias). The calculation that reliably appears is the **fee waterfall** (management fee, incentive fee, hurdle, high-water mark). Expect conceptual questions on strategies, investment methods, and return components of commodity futures.""",
"sections": [
{
"id": "features",
"title": "Features, Methods of Investing and Fee Structures",
"body": r"""**Why alternatives?** Potential diversification (low correlation with traditional assets), access to illiquidity premiums, and manager skill. **Drawbacks**: illiquidity, high fees, high minimum investments, limited transparency and regulation, leverage, and difficult valuation. Reported historical returns are often overstated and volatility understated because of **appraisal smoothing**, **survivorship bias** (failed funds drop out) and **backfill bias** (funds add good past returns when joining a database).

**Methods of investing.**

- **Fund investing**: invest as a limited partner (LP) in a fund run by a general partner (GP). Lowest required expertise, diversified, but the highest fees and least control.
- **Co-investing**: invest in a fund and also directly alongside it in specific deals, typically with reduced fees. More control; requires more expertise; risk of adverse selection.
- **Direct investing**: buy assets directly. Most control, lowest fees, but needs significant expertise and capital, and offers less diversification.

**Fund structure.** Most private funds are **limited partnerships**: the GP manages the fund and has unlimited liability; LPs commit capital and have limited liability. Capital is **committed** up front and **called** (drawn down) over the investment period. The **limited partnership agreement** and **side letters** set the terms. Hedge funds often use a **master-feeder** structure to accommodate taxable and tax-exempt investors.

**Fees.**

- **Management fee**: typically 1-2% per year of committed capital (private equity) or AUM (hedge funds).
- **Incentive fee (carried interest)**: typically 20% of profits.
- **Hurdle rate**: the minimum return before incentive fees are paid. A **hard hurdle** pays incentive fees only on returns *above* the hurdle; a **soft hurdle** pays them on *all* profits once the hurdle is cleared. A **catch-up clause** lets the GP receive a larger share of profits above the hurdle until it reaches its full carried interest.
- **High-water mark**: no incentive fee is paid until the fund's value exceeds its previous highest value (net of fees), so investors do not pay twice for the same gains.
- **Waterfall**: **European (whole-of-fund)** pays carry only after LPs receive all contributed capital plus the hurdle (LP-friendly); **American (deal-by-deal)** pays carry deal by deal (GP-friendly). A **clawback** provision makes the GP return excess carry received earlier.

**Performance appraisal.** Private funds report **IRR** (money-weighted, because the GP controls the timing of capital calls) and **multiple of invested capital (MOIC)** = (realized + unrealized value) / invested capital. MOIC ignores the time value of money. Risk-adjusted measures (Sharpe, Sortino, Calmar, MAR) are distorted by smoothing and non-normal returns.""",
"formulas": [
{"name": "Hedge fund fees (common exam convention)", "tex": r"\text{Mgmt fee} = m \times V_1 \qquad \text{Incentive fee} = k \times \max\left[0,\ V_1 - V_0 - \text{Mgmt fee} - \text{Hurdle amount}\right]",
 "vars": [["m", "management fee rate"], ["k", "incentive fee rate"], ["V_0, V_1", "beginning and ending fund value (or the high-water mark in place of V_0)"]], "note": "Read each question for the base (beginning vs. ending value) and whether the incentive fee is net of the management fee. Hard hurdle: subtract the hurdle amount; soft hurdle: if cleared, the incentive fee applies to all profit."},
{"name": "Net return to investors", "tex": r"R_{net} = \frac{V_1 - \text{Total fees} - V_0}{V_0}", "vars": [], "note": ""},
{"name": "Multiple of invested capital", "tex": r"MOIC = \frac{\text{Realized value} + \text{Unrealized value}}{\text{Invested capital}}", "vars": [], "note": ""},
],
"examples": [
{"title": "2 and 20 with and without a hurdle",
 "problem": "A hedge fund starts the year at USD 100 million and ends at USD 130 million before fees. Fees: 2% management fee on year-end value, 20% incentive fee on gains net of the management fee. Compute the net return (a) with no hurdle, (b) with an 8% hard hurdle, (c) with an 8% soft hurdle.",
 "steps": [r"Management fee $= 2\% \times 130 = 2.6$.",
           r"(a) Incentive $= 20\% \times (130 - 100 - 2.6) = 5.48$. Total fees $= 8.08$. Net return $= (130 - 8.08 - 100)/100 = 21.92\%$.",
           r"(b) Hard hurdle: incentive $= 20\% \times (130 - 2.6 - 108) = 3.88$. Total fees $= 6.48$. Net return $= 23.52\%$.",
           r"(c) Soft hurdle: return after management fee $= 27.4\% > 8\%$, so the incentive applies to all gains: same as (a), 21.92%."],
 "answer": "21.92% (no hurdle), 23.52% (hard hurdle), 21.92% (soft hurdle)."},
{"title": "High-water mark",
 "problem": "A fund's value fell from USD 120M (its high-water mark) to USD 100M last year. This year it ends at USD 115M before fees. Is an incentive fee due?",
 "steps": ["The fund must exceed 120M before any incentive fee.", "115M < 120M, so no incentive fee, even though this year's gain is 15%."],
 "answer": "No incentive fee this year; only the management fee applies."},
],
},
{
"id": "private",
"title": "Private Capital: Private Equity and Private Debt",
"body": r"""**Private equity strategies.**

- **Leveraged buyouts (LBOs)**: acquire mature companies with stable cash flows using heavy debt; create value through operational improvements, financial engineering and governance. **Management buyouts (MBOs)** are led by existing management; **management buy-ins (MBIs)** bring in outside managers.
- **Venture capital (VC)**: equity in early-stage companies. Stages: *pre-seed/angel* (business plan), *seed* (product development and marketing), *early stage* (Series A, start of production), *later stage* (expansion), *mezzanine/pre-IPO*. High failure rates; returns are dominated by a few big winners.
- **Growth equity**: minority stakes in established, growing companies (often still private).
- Others: distressed investing, special situations.

**Exits**: trade sale (to a strategic buyer), IPO (often the highest value but least certain), secondary sale (to another PE fund), recapitalization (releverage to pay a dividend), write-off/liquidation.

**Private debt.**

- **Direct lending**: loans made directly by funds to (usually middle-market) companies, often senior and secured, with higher yields and covenants.
- **Mezzanine debt**: subordinated debt, often with warrants or conversion features ("equity kicker").
- **Venture debt**: loans to VC-backed start-ups, often with warrants.
- **Distressed debt**: bought at deep discounts; the investor may take an active role in restructuring.
- **Unitranche** loans blend senior and subordinated into one facility.

**Risk and return.** PE returns are higher on average than public equity but with high dispersion between top- and bottom-quartile managers, illiquidity, leverage and valuation risk. The **J-curve**: fund IRRs are negative in early years (fees and investments, no exits) and turn positive as investments mature and are sold.

**Valuation.** Private companies are valued by comparables (public peers or precedent transactions), DCF, or asset-based methods; VC valuations depend heavily on the post-money valuation of financing rounds.""",
"formulas": [],
"examples": [
{"title": "Evaluating exit routes",
 "problem": "A PE fund owns a profitable industrial company. Equity markets are depressed, but a large strategic competitor has expressed interest. Which exit route is most suitable?",
 "steps": ["An IPO in a depressed market would likely realize a poor price.", "A strategic buyer may pay a premium for synergies."],
 "answer": "A trade sale to the strategic buyer."},
],
},
{
"id": "realassets",
"title": "Real Estate, Infrastructure and Natural Resources",
"body": r"""**Real estate** can be accessed through four quadrants: **private equity** (direct ownership, private real estate funds), **private debt** (commercial mortgages), **public equity** (REITs, real estate company shares) and **public debt** (CMBS, RMBS). Real estate offers income, potential inflation protection, and diversification, but properties are heterogeneous, illiquid, costly to trade, and require active management.

**Property types**: residential, office, industrial and warehouse, retail, hospitality, healthcare, data centers. Lease length drives sensitivity to the economy: hotels (daily "leases") are most cyclical; long office leases less so.

**Valuation methods.**

- **Income approach**: direct capitalization ($V = NOI/\text{cap rate}$) or DCF of future NOI and resale value. The **cap rate** is like an earnings yield: a lower cap rate means a higher value.
- **Cost approach**: replacement cost of the building plus land value, less depreciation.
- **Sales comparison approach**: prices of similar recently sold properties, adjusted.

Appraisal-based indexes **smooth** returns, understating volatility and correlation with other assets. **REITs** must distribute most of their income, are liquid and traded, and behave partly like equities in the short run.

**Infrastructure**: long-lived real assets providing essential services. *Economic* infrastructure (transport, utilities, communications) vs. *social* infrastructure (schools, hospitals). **Brownfield** investments are existing assets with operating history (lower risk); **greenfield** are new projects to be built (higher risk). Often regulated or under long-term concession, producing stable, inflation-linked cash flows. Public-private partnerships (PPPs) are common.

**Natural resources.** **Commodities** are usually accessed through **futures**. The total return on a fully collateralized commodity futures position has three components:

- **Spot price return** (change in the underlying commodity price),
- **Roll return** (from replacing expiring contracts): positive in **backwardation** (futures price below spot) and negative in **contango** (futures above spot),
- **Collateral return** (interest earned on the margin/collateral, the risk-free rate).

**Farmland** and **timberland** provide income (crops; timber growth), inflation hedging and land appreciation. Timberland has an extra flexibility: trees can be left to grow if prices are low.

**Digital assets** (cryptocurrencies, tokens) use distributed ledger technology (blockchain). They have high volatility, uncertain regulation, and may be accessed directly, via funds or via ETPs.""",
"formulas": [
{"name": "Direct capitalization", "tex": r"V_0 = \frac{NOI_1}{\text{Cap rate}} \qquad \text{Cap rate} = \frac{NOI_1}{V_0}", "vars": [["NOI_1", "next year's net operating income (rents less operating expenses, before financing and taxes)"]], "note": ""},
{"name": "Commodity futures total return", "tex": r"R_{total} = R_{spot} + R_{roll} + R_{collateral}", "vars": [], "note": "Backwardation: positive roll yield. Contango: negative roll yield."},
],
"examples": [
{"title": "Cap rate valuation",
 "problem": "An office building is expected to generate NOI of USD 1.2 million next year. Comparable properties sell at a 6% cap rate. Estimate its value. What if cap rates rise to 6.5%?",
 "steps": [r"$V = 1.2/0.06 = 20.0$ million.", r"At 6.5%: $1.2/0.065 = 18.46$ million, a 7.7% decline."],
 "answer": "USD 20.0 million; rising cap rates (like rising yields) lower values."},
],
},
{
"id": "hedgefunds",
"title": "Hedge Funds",
"body": r"""Hedge funds are lightly regulated pooled vehicles that use leverage, short selling and derivatives, with redemption terms such as **lockup periods**, **notice periods** and **gates** (limits on withdrawals). They charge both management and incentive fees.

**Strategy categories.**

- **Equity hedge**: market neutral (long and short with little net exposure; profit from relative mispricing), fundamental growth or value, quantitative directional, short bias, sector specific.
- **Event-driven**: merger arbitrage (long target, short acquirer; risk is deal failure), distressed/restructuring, activist, special situations.
- **Relative value**: fixed income convertible arbitrage (long convertible, short stock), fixed income asset-backed, fixed income general, volatility arbitrage, multi-strategy. Typically use high leverage to magnify small spreads.
- **Opportunistic**: global macro (top-down bets on rates, currencies, commodities, indexes) and managed futures (CTAs, often trend following).
- **Specialist**: niche strategies (e.g. reinsurance, volatility trading).
- **Multi-manager**: fund-of-funds (extra layer of fees, but diversification and due diligence) and multi-strategy funds.

**Due diligence** examines the strategy, the investment process, competitive advantage, track record, size and capacity, risk management, operational and legal structure, service providers (prime broker, administrator, auditor), and the terms (fees, liquidity).

**Hedge fund index data** suffers from survivorship and backfill bias because reporting is voluntary, so index returns overstate the experience of a typical investor.""",
"formulas": [],
"examples": [
{"title": "Merger arbitrage",
 "problem": "Company A agrees to acquire Company T in an all-stock deal at 0.5 A shares per T share. A trades at USD 100 and T trades at USD 46. Describe the trade and the main risk.",
 "steps": ["Deal value per T share = 0.5 x 100 = 50, a 4 dollar spread over T's price.", "Buy 1 T share and short 0.5 A shares to lock in the spread.", "If the deal fails, T likely falls sharply."],
 "answer": "Long T / short A; the main risk is deal failure (event risk), not market direction."},
],
},
],
"pitfalls": [
"Hard hurdle: incentive fee only on returns ABOVE the hurdle. Soft hurdle: on ALL returns once cleared.",
"High-water mark: no incentive fee until the previous peak (net of fees) is exceeded.",
"European (whole-of-fund) waterfall favors LPs; American (deal-by-deal) favors GPs.",
"Commodity futures return = spot + roll + collateral. Backwardation gives a positive roll return.",
"Appraisal smoothing and survivorship/backfill bias understate risk and overstate returns of alternatives.",
"Brownfield = existing asset (lower risk); greenfield = to be built (higher risk).",
"Fund investing: most diversified, highest fees, least expertise required. Direct investing: the reverse.",
"PE uses IRR (GP controls cash flow timing) and MOIC (ignores time value).",
],
"problems": [
{"id": "a1", "section": "features", "level": 2,
 "q": "A fund starts at USD 200M and ends at USD 240M before fees. Fees are 1.5% of year-end assets and 20% of gains net of the management fee, with no hurdle. The net return to investors is closest to:",
 "choices": {"A": "14.56%", "B": "16.20%", "C": "15.12%"}, "answer": "A",
 "explanation": r"Management fee $= 0.015 \times 240 = 3.6$. Incentive $= 0.20 \times (240 - 200 - 3.6) = 7.28$. Net $= (240 - 3.6 - 7.28 - 200)/200 = 14.56\%$."},
{"id": "a2", "section": "features", "level": 2,
 "q": "Using the same fund with a 10% hard hurdle (applied to beginning value), the incentive fee is closest to:",
 "choices": {"A": "USD 3.28M", "B": "USD 7.28M", "C": "USD 4.00M"}, "answer": "A",
 "explanation": r"$0.20 \times (240 - 3.6 - 220) = 0.20 \times 16.4 = 3.28$."},
{"id": "a3", "section": "features", "level": 2,
 "q": "A high-water mark provision ensures that:",
 "choices": {"A": "the manager earns a minimum fee each year.", "B": "investors do not pay incentive fees twice on the same gains.", "C": "the fund cannot lose money."}, "answer": "B",
 "explanation": "Losses must be recovered before new incentive fees are paid."},
{"id": "a4", "section": "features", "level": 2,
 "q": "Which waterfall structure is most favorable to limited partners?",
 "choices": {"A": "American (deal-by-deal)", "B": "European (whole-of-fund)", "C": "Both are equally favorable"}, "answer": "B",
 "explanation": "Carry is paid only after LPs receive all contributed capital plus the hurdle."},
{"id": "a5", "section": "features", "level": 1,
 "q": "Compared with fund investing, direct investing in alternatives most likely offers:",
 "choices": {"A": "more diversification.", "B": "lower fees and more control.", "C": "lower required expertise."}, "answer": "B",
 "explanation": "Direct investing avoids the GP's fees and gives control, but demands expertise and capital."},
{"id": "a6", "section": "features", "level": 2,
 "q": "A private equity fund has invested USD 80M; it has distributed USD 60M and its remaining holdings are valued at USD 100M. Its MOIC is:",
 "choices": {"A": "1.25x", "B": "2.00x", "C": "0.75x"}, "answer": "B",
 "explanation": r"$(60 + 100)/80 = 2.0\times$."},
{"id": "a7", "section": "features", "level": 2,
 "q": "Survivorship bias in hedge fund databases most likely causes reported index returns to be:",
 "choices": {"A": "understated.", "B": "overstated.", "C": "unaffected."}, "answer": "B",
 "explanation": "Failed funds stop reporting and drop out, so remaining funds look better than the full population."},
{"id": "a8", "section": "private", "level": 1,
 "q": "A private equity strategy that uses significant debt to acquire a mature company with stable cash flows is a:",
 "choices": {"A": "venture capital investment.", "B": "leveraged buyout.", "C": "growth equity investment."}, "answer": "B",
 "explanation": "LBOs use heavy leverage on targets whose cash flows can service debt."},
{"id": "a9", "section": "private", "level": 2,
 "q": "Subordinated debt with an equity kicker such as warrants is best described as:",
 "choices": {"A": "direct lending.", "B": "mezzanine debt.", "C": "distressed debt."}, "answer": "B",
 "explanation": "Mezzanine debt sits between senior debt and equity and often carries warrants."},
{"id": "a10", "section": "private", "level": 2,
 "q": "The J-curve effect in private equity refers to:",
 "choices": {"A": "negative early returns followed by positive returns as investments are realized.", "B": "rising leverage over the fund's life.", "C": "the shape of the fee schedule."}, "answer": "A",
 "explanation": "Fees and early investments depress early IRRs before exits generate gains."},
{"id": "a11", "section": "realassets", "level": 2,
 "q": "A property is expected to produce NOI of USD 900,000. With a market cap rate of 7.5%, its value is:",
 "choices": {"A": "USD 6.75M", "B": "USD 12.0M", "C": "USD 9.68M"}, "answer": "B",
 "explanation": r"$900{,}000/0.075 = 12{,}000{,}000$."},
{"id": "a12", "section": "realassets", "level": 2,
 "q": "A commodity futures market in which futures prices are below the spot price is in:",
 "choices": {"A": "contango, producing a negative roll return.", "B": "backwardation, producing a positive roll return.", "C": "backwardation, producing a negative roll return."}, "answer": "B",
 "explanation": "In backwardation, an investor rolls into cheaper contracts that converge up toward spot: positive roll yield."},
{"id": "a13", "section": "realassets", "level": 2,
 "q": "Compared with a greenfield infrastructure project, a brownfield investment most likely has:",
 "choices": {"A": "higher construction risk.", "B": "an established operating history and lower risk.", "C": "no regulated cash flows."}, "answer": "B",
 "explanation": "Brownfield assets already exist and have cash flow records."},
{"id": "a14", "section": "realassets", "level": 2,
 "q": "Real estate indexes based on appraisals most likely:",
 "choices": {"A": "overstate volatility.", "B": "understate volatility and correlation with other assets.", "C": "accurately reflect transaction prices."}, "answer": "B",
 "explanation": "Appraisals lag and smooth prices."},
{"id": "a15", "section": "realassets", "level": 1,
 "q": "Which property type is generally the most sensitive to the business cycle because of the short length of its 'leases'?",
 "choices": {"A": "Office", "B": "Hotels", "C": "Industrial warehouses"}, "answer": "B",
 "explanation": "Hotel rates reset daily, so revenues respond immediately to demand."},
{"id": "a16", "section": "hedgefunds", "level": 2,
 "q": "A strategy that buys convertible bonds and shorts the issuer's common stock is:",
 "choices": {"A": "event-driven merger arbitrage.", "B": "relative value convertible arbitrage.", "C": "global macro."}, "answer": "B",
 "explanation": "Convertible arbitrage exploits mispricing between the convertible and the stock."},
{"id": "a17", "section": "hedgefunds", "level": 2,
 "q": "A restriction allowing a hedge fund to limit redemptions to a percentage of assets in a given period is a:",
 "choices": {"A": "lockup.", "B": "gate.", "C": "side letter."}, "answer": "B",
 "explanation": "A gate caps withdrawals; a lockup prohibits redemptions for an initial period."},
{"id": "a18", "section": "hedgefunds", "level": 2,
 "q": "Compared with investing in single hedge funds, a fund-of-funds most likely offers:",
 "choices": {"A": "lower total fees.", "B": "diversification and due diligence, at the cost of an extra layer of fees.", "C": "higher expected returns net of fees."}, "answer": "B",
 "explanation": "Fund-of-funds add their own fees on top of underlying funds' fees."},
],
}

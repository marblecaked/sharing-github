TOPIC = {
"id": "corp",
"name": "Corporate Issuers",
"weight": "6-9%",
"overview": r"""Corporate Issuers looks at the company from the inside: how it is organized and owned, who has a claim on it, how it is governed, how it manages short-term liquidity, how it chooses long-term investments, and how it finances itself. Expect a mix of conceptual governance questions and calculations on **NPV/IRR, WACC, the cash conversion cycle, the cost of trade credit, leverage and the Modigliani-Miller propositions.**""",
"sections": [
{
"id": "forms",
"title": "Organizational Forms, Stakeholders and Governance",
"body": r"""**Legal forms.** A *sole proprietorship* has unlimited liability and is not separate from its owner. A *general partnership* shares unlimited liability among partners; a *limited partnership* has at least one general partner with unlimited liability and limited partners whose liability is capped at their investment. A **corporation** is a separate legal entity: owners have **limited liability**, ownership is easily transferable, and it can raise capital at scale. The cost is potential **double taxation** (corporate profits taxed, then dividends taxed again) in many jurisdictions. Public companies trade on exchanges with extensive disclosure requirements; private companies face fewer disclosures but limited liquidity.

**Debt vs. equity holders.** Debtholders have a contractual, senior claim with capped upside: they care about downside risk and prefer lower leverage and stable cash flows. Equity holders have a residual claim with unlimited upside and limited downside (a call option on the firm's assets), so they may prefer *riskier* projects. This conflict is sharpest when a firm is near distress.

**Stakeholders**: shareholders, creditors, the board, managers and employees, customers, suppliers, governments and regulators. **Shareholder theory** says the firm should maximize shareholder value; **stakeholder theory** says it should balance the interests of all groups. ESG considerations reflect the stakeholder view.

**Principal-agent conflicts.**

- Shareholders vs. managers: empire building, entrenchment, excessive perquisites, insufficient effort, too much or too little risk-taking.
- Controlling vs. minority shareholders: related-party transactions, dual-class shares that give founders control with little economic ownership.
- Shareholders vs. creditors: asset substitution (riskier projects), excess dividends or buybacks, additional borrowing that dilutes existing creditors.

**Governance mechanisms.** Shareholder voting (ordinary and special resolutions, proxy voting, **cumulative voting** which helps minority holders elect directors), a **board of directors** with independent members and committees (audit, compensation/remuneration, nomination, risk), executive compensation aligned with long-term value, debt covenants for creditors, and external forces: activist investors, proxy fights, hostile takeovers and the market for corporate control. A **staggered board** and **poison pills** are takeover defenses that can entrench management.

**Governance risks and benefits.** Weak governance raises legal, regulatory and reputational risk and the cost of capital. Good governance improves operational efficiency, control and the quality of financial reporting, and tends to lower the cost of capital.""",
"formulas": [],
"examples": [
{"title": "Spotting the conflict",
 "problem": "A highly leveraged firm near distress approves a speculative project with negative NPV but a small chance of a large payoff. Whose interests does this serve?",
 "steps": ["Shareholders hold an option-like claim: if the gamble pays off they keep the upside; if it fails, creditors bear most of the loss.", "Creditors are harmed by the increase in risk."],
 "answer": "It favors shareholders at creditors' expense (asset substitution), which is why debt covenants restrict such actions."},
],
},
{
"id": "wc",
"title": "Working Capital and Liquidity",
"body": r"""**Working capital management** balances liquidity against profitability. Holding more cash and inventory reduces the risk of a shortfall but ties up capital that earns little.

**Primary sources of liquidity**: cash and marketable securities, operating cash flow, bank lines of credit, trade credit. **Secondary sources**: renegotiating debt, liquidating assets, filing for bankruptcy protection. Using secondary sources may signal distress.

**Drags and pulls on liquidity.** *Drags* slow cash inflows: uncollected receivables, obsolete inventory, tight credit conditions. *Pulls* accelerate outflows: paying vendors early, reduced credit limits from suppliers.

**Working capital approaches.** *Conservative*: large current asset balances financed with long-term funds; lower risk, lower return. *Aggressive*: lean current assets financed with short-term funds; higher return but rollover risk. *Moderate* matches maturities: permanent current assets financed long-term, seasonal ones short-term.

**The cash conversion cycle (CCC)** is the number of days cash is tied up in operations: days of inventory on hand plus days sales outstanding minus days payables outstanding. Shorter is better, all else equal, but an extremely short CCC can mean lost sales from tight credit terms or strained suppliers.

**Trade credit.** Terms like **2/10 net 30** mean a 2% discount if paid within 10 days, otherwise full payment in 30 days. Forgoing the discount is effectively borrowing for 20 days at a very high annualized cost. Unless the firm's alternative borrowing cost is higher, it should take the discount.

**Short-term funding options.** Uncommitted lines (no guarantee), committed lines (fee for commitment), revolving credit agreements (most reliable, multi-year), secured loans, factoring of receivables, commercial paper (for large, highly rated firms, usually backed by a credit line).""",
"formulas": [
{"name": "Cash conversion cycle", "tex": r"CCC = DOH + DSO - DPO",
 "vars": [["DOH", "days of inventory on hand = 365 / inventory turnover"], ["DSO", "days sales outstanding = 365 / receivables turnover"], ["DPO", "days payables outstanding = 365 / payables turnover"]], "note": ""},
{"name": "Cost of trade credit (forgoing a discount)", "tex": r"\text{Cost} = \left(1 + \frac{\text{Discount}}{1 - \text{Discount}}\right)^{365/(\text{Payment period} - \text{Discount period})} - 1",
 "vars": [["Discount", "discount percentage, e.g. 0.02"], ["Payment period", "days until full payment is due"], ["Discount period", "days within which the discount applies"]], "note": ""},
],
"examples": [
{"title": "Cost of forgoing a discount",
 "problem": "A supplier offers 2/10 net 30. The firm can borrow on its credit line at 9%. Should it take the discount?",
 "steps": [r"Cost of forgoing $= (1 + 0.02/0.98)^{365/20} - 1 = (1.020408)^{18.25} - 1 = 44.6\%$.",
           "Borrowing at 9% to pay early is far cheaper than 44.6%."],
 "answer": "Take the discount, funding it with the credit line if necessary."},
{"title": "Cash conversion cycle",
 "problem": "Inventory turnover is 8.11x, receivables turnover 12.17x and payables turnover 9.13x (365-day year). Compute the CCC.",
 "steps": [r"DOH $= 365/8.11 = 45$ days; DSO $= 365/12.17 = 30$ days; DPO $= 365/9.13 = 40$ days.", r"CCC $= 45 + 30 - 40 = 35$ days."],
 "answer": "35 days."},
],
},
{
"id": "capbud",
"title": "Capital Investments and Capital Allocation",
"body": r"""**Types of capital investments**: going concern projects (maintenance, replacement, efficiency), regulatory/compliance projects (often required regardless of NPV), expansion projects, and other projects (new products, acquisitions).

**The capital allocation process**: idea generation, investment analysis, planning and prioritization, monitoring and post-audit.

**Principles.**

1. Decisions are based on **incremental cash flows**, not accounting income.
2. **Ignore sunk costs** (already spent and unrecoverable).
3. **Include opportunity costs** (the value of a resource in its best alternative use).
4. Include **externalities** such as cannibalization of existing products.
5. Timing matters; cash flows are **after-tax**.
6. **Financing costs are excluded** from cash flows: they are captured in the discount rate (WACC).

**NPV** is the present value of all cash flows at the required return; accept if positive. It measures the expected increase in shareholder wealth. **IRR** is the discount rate that makes NPV zero; accept if IRR exceeds the required return. For a single independent conventional project, NPV and IRR always agree. They can **conflict for mutually exclusive projects** when projects differ in scale or in the timing of cash flows, because IRR assumes reinvestment at the IRR whereas NPV assumes reinvestment at the required return. **When they conflict, choose NPV.** Non-conventional cash flows (sign changes more than once) can produce multiple IRRs or none.

**Return on invested capital (ROIC)**, after-tax operating profit divided by average invested capital, compared with the cost of capital, indicates whether a company's past investments created value.

**Common capital allocation pitfalls**: inertia (copying last year's budget), source-of-capital bias (treating internal funds as free), failing to consider alternatives, pet projects, basing decisions on EPS or accounting returns rather than cash flows, and using the corporate WACC for projects with different risk.

**Real options** give managers the right, not the obligation, to act later: timing (delay), abandonment, expansion, flexibility (price-setting or production-flexibility) and fundamental options (payoffs depend on an underlying asset price, e.g. an oil field). Project value = NPV without options + value of options.""",
"formulas": [
{"name": "Net present value", "tex": r"NPV = \sum_{t=0}^{N}\frac{CF_t}{(1+r)^t}", "vars": [["CF_t", "after-tax incremental cash flow at t (CF_0 usually negative)"], ["r", "required return (risk-adjusted)"]], "note": ""},
{"name": "Internal rate of return", "tex": r"0 = \sum_{t=0}^{N}\frac{CF_t}{(1+IRR)^t}", "vars": [], "note": ""},
{"name": "Return on invested capital", "tex": r"ROIC = \frac{\text{After-tax operating profit}}{\text{Average book value of invested capital}}", "vars": [], "note": "Value is created when ROIC exceeds the cost of capital."},
],
"examples": [
{"title": "Evaluating a project",
 "problem": "A project costs USD 1,000 and returns USD 300, 400, 400 and 300 at the end of years 1 to 4. The required return is 10%. Compute NPV and IRR, and decide.",
 "steps": [r"PVs at 10%: $272.73 + 330.58 + 300.53 + 204.90 = 1{,}108.74$.",
           r"$NPV = 1{,}108.74 - 1{,}000 = 108.74$.",
           r"IRR (CF0 = -1000, C01 = 300, C02 = 400, C03 = 400, C04 = 300): 14.90%."],
 "answer": "NPV = USD 108.74 > 0 and IRR = 14.90% > 10%: accept."},
],
},
{
"id": "capstruct",
"title": "Capital Structure and the Cost of Capital",
"body": r"""**Weighted average cost of capital (WACC)** is the blended required return of all capital providers, weighted by their **target market value** weights, with the cost of debt on an **after-tax** basis (interest is deductible). It is the discount rate for projects of *average* risk; riskier projects need a higher rate.

**Component costs.** Cost of debt: the yield to maturity on existing debt or comparable debt (not the coupon). Cost of preferred stock: $D_p/P_p$. Cost of equity: **CAPM** ($r_f + \beta[E(R_m) - r_f]$), the dividend discount model ($D_1/P_0 + g$), or bond yield plus a risk premium.

**Modigliani-Miller (MM).**

- **No taxes, Proposition I**: capital structure is irrelevant; $V_L = V_U$.
- **No taxes, Proposition II**: the cost of equity rises linearly with leverage, exactly offsetting the benefit of cheaper debt, so WACC stays constant.
- **With taxes, Proposition I**: debt adds value through the tax shield: $V_L = V_U + tD$. Taken literally, the optimal structure is 100% debt.
- **With taxes, Proposition II**: cost of equity still rises with leverage, but by less, so WACC falls as debt increases.

**Static trade-off theory.** In reality, **costs of financial distress** (direct: legal fees; indirect: lost customers, suppliers and employees) rise with leverage. The optimal capital structure is where the marginal tax benefit of debt equals the marginal expected distress cost. At this point **WACC is minimized and firm value is maximized**.

**Pecking order theory** (asymmetric information): managers prefer internal funds first, then debt, then equity last, because issuing equity signals that management thinks the shares are overvalued. **Agency costs of equity** are reduced by debt, which disciplines management by committing free cash flow to interest payments.

**What drives capital structure in practice?** Companies with stable cash flows and tangible assets can carry more debt; companies in early growth stages with volatile cash flows rely on equity. Capital structure changes over the life cycle: start-ups (equity), growth (some debt), mature (substantial debt, steady payouts).

**Business risk and leverage.** *Operating leverage* (fixed operating costs) magnifies the effect of a sales change on operating income; *financial leverage* (fixed interest) magnifies the effect of an operating income change on net income.""",
"formulas": [
{"name": "Weighted average cost of capital", "tex": r"WACC = w_d\,r_d(1-t) + w_p\,r_p + w_e\,r_e",
 "vars": [["w_d, w_p, w_e", "target market-value weights of debt, preferred and equity"], ["r_d", "pre-tax cost of debt (YTM)"], ["t", "marginal tax rate"], ["r_p", "cost of preferred = D_p / P_p"], ["r_e", "cost of equity"]], "note": ""},
{"name": "Cost of equity (CAPM)", "tex": r"r_e = R_f + \beta\left[E(R_M) - R_f\right]", "vars": [["R_f", "risk-free rate"], ["\\beta", "equity beta"], ["E(R_M) - R_f", "equity risk premium"]], "note": ""},
{"name": "MM Proposition I with taxes", "tex": r"V_L = V_U + tD", "vars": [["V_L, V_U", "value of levered and unlevered firm"], ["tD", "PV of the debt tax shield"]], "note": ""},
{"name": "MM Proposition II", "tex": r"r_e = r_0 + (r_0 - r_d)\frac{D}{E} \qquad \text{with taxes: } r_e = r_0 + (r_0 - r_d)(1-t)\frac{D}{E}",
 "vars": [["r_0", "cost of capital of an all-equity firm"], ["D/E", "debt-to-equity ratio"]], "note": ""},
{"name": "Degrees of operating and financial leverage", "tex": r"DOL = \frac{Q(P - V)}{Q(P-V) - F} \qquad DFL = \frac{EBIT}{EBIT - I} \qquad DTL = DOL \times DFL",
 "vars": [["Q", "units sold"], ["P", "price per unit"], ["V", "variable cost per unit"], ["F", "fixed operating costs"], ["I", "interest expense"]], "note": r"$DOL = \%\Delta EBIT / \%\Delta Sales$; $DFL = \%\Delta NI / \%\Delta EBIT$."},
],
"examples": [
{"title": "Computing WACC",
 "problem": "Target weights: 30% debt, 70% equity. Pre-tax cost of debt 7%, tax rate 30%. Risk-free rate 3.5%, beta 1.1, market risk premium 6%. Compute WACC.",
 "steps": [r"$r_e = 3.5\% + 1.1(6\%) = 10.1\%$.",
           r"After-tax $r_d = 7\% \times (1 - 0.30) = 4.9\%$.",
           r"$WACC = 0.30(4.9\%) + 0.70(10.1\%) = 1.47\% + 7.07\% = 8.54\%$."],
 "answer": "WACC = 8.54%."},
{"title": "MM Proposition II",
 "problem": "An all-equity firm's cost of capital is 10%. It recapitalizes to D/E = 0.5 with debt costing 6%. Find the cost of equity with no taxes and with a 25% tax rate.",
 "steps": [r"No taxes: $r_e = 10\% + (10\% - 6\%)(0.5) = 12.0\%$.", r"With taxes: $r_e = 10\% + (4\%)(0.75)(0.5) = 11.5\%$."],
 "answer": "12.0% without taxes; 11.5% with taxes (equity risk rises less because the tax shield cushions it)."},
{"title": "Leverage",
 "problem": "A firm sells 100,000 units at USD 50 with variable cost USD 30 per unit and fixed operating costs of USD 600,000. Interest expense is USD 200,000. Compute DOL, DFL and DTL.",
 "steps": [r"Contribution $= 100{,}000 \times 20 = 2{,}000{,}000$; $EBIT = 2{,}000{,}000 - 600{,}000 = 1{,}400{,}000$.",
           r"$DOL = 2{,}000{,}000/1{,}400{,}000 = 1.43$.", r"$DFL = 1{,}400{,}000/(1{,}400{,}000 - 200{,}000) = 1.17$.", r"$DTL = 1.43 \times 1.17 = 1.67$."],
 "answer": "A 10% rise in sales raises EBIT by about 14.3% and net income by about 16.7%."},
],
},
{
"id": "bizmodel",
"title": "Business Models",
"body": r"""A **business model** describes how a company creates value for customers and captures some of it as profit. Key elements: the *value proposition* (which customers, which needs), *value delivery* (channels, the value chain), *pricing*, and *revenue model*.

**Pricing approaches**: value-based (price set by customer value), cost-plus, and competitive. Specialized models include **tiered pricing** (volume discounts), **dynamic pricing** (varies with demand, e.g. airlines), **freemium** (basic free, premium paid), **razors-and-blades** (cheap base product, profitable consumables), **bundling** and **auction/reverse auction**.

**Revenue models**: one-time sales, subscriptions (recurring), licensing and royalties, advertising, transaction fees, leasing.

**Network effects**: the product becomes more valuable as more people use it (social networks, payment networks, marketplaces). *Two-sided* platforms link two user groups (buyers and sellers). Network effects can create winner-take-most markets.

**Asset-light vs. asset-heavy.** Asset-light models (franchising, outsourcing manufacturing) need less capital and earn higher returns on capital but may give up control. **Unit economics** (revenue and cost per customer or per unit, customer acquisition cost vs. lifetime value) show whether a model can scale profitably.""",
"formulas": [],
"examples": [],
},
],
"pitfalls": [
"Ignore sunk costs and financing costs in project cash flows; include opportunity costs and cannibalization.",
"When NPV and IRR conflict for mutually exclusive projects, choose NPV.",
"WACC uses target market-value weights and the AFTER-TAX cost of debt (based on YTM, not the coupon).",
"MM without taxes: WACC constant. With taxes: WACC falls with leverage. Trade-off theory: WACC is U-shaped.",
"Forgoing a 2/10 net 30 discount costs about 44.6% per year.",
"CCC = DOH + DSO - DPO. Paying suppliers later shortens it.",
"Equity holders' option-like claim makes them favor risk; creditors use covenants to limit it.",
],
"problems": [
{"id": "c1", "section": "forms", "level": 1,
 "q": "Which form of business organization offers all owners limited liability and a separate legal identity?",
 "choices": {"A": "General partnership", "B": "Limited partnership", "C": "Corporation"}, "answer": "C",
 "explanation": "A limited partnership still has at least one general partner with unlimited liability."},
{"id": "c2", "section": "forms", "level": 2,
 "q": "Compared with debtholders, equity holders of a firm in financial distress most likely prefer:",
 "choices": {"A": "lower-risk projects.", "B": "higher-risk projects.", "C": "higher dividend restrictions."}, "answer": "B",
 "explanation": "Equity is like a call option on the firm's assets: more volatility increases its value at creditors' expense."},
{"id": "c3", "section": "forms", "level": 2,
 "q": "Cumulative voting most likely benefits:",
 "choices": {"A": "management.", "B": "minority shareholders.", "C": "controlling shareholders."}, "answer": "B",
 "explanation": "Cumulative voting lets shareholders concentrate all their votes on one director, helping minorities secure board representation."},
{"id": "c4", "section": "forms", "level": 2,
 "q": "Which of the following is most likely a takeover defense that can entrench management?",
 "choices": {"A": "A staggered board.", "B": "An independent audit committee.", "C": "Say-on-pay voting."}, "answer": "A",
 "explanation": "With staggered terms, a hostile acquirer cannot replace the whole board in one election."},
{"id": "c5", "section": "wc", "level": 2,
 "q": "A supplier offers terms of 1/10 net 30. The annualized cost of forgoing the discount is closest to:",
 "choices": {"A": "18.4%", "B": "20.1%", "C": "36.5%"}, "answer": "B",
 "explanation": r"$(1 + 0.01/0.99)^{365/20} - 1 = 20.1\%$. A is the simple-interest approximation ($1/99 \times 365/20 = 18.4\%$)."},
{"id": "c6", "section": "wc", "level": 1,
 "q": "Which of the following is a secondary source of liquidity?",
 "choices": {"A": "A committed bank line of credit.", "B": "Renegotiating debt contracts.", "C": "Cash flow from operations."}, "answer": "B",
 "explanation": "Secondary sources (renegotiating debt, selling assets, bankruptcy) may change the firm's operations or financial structure."},
{"id": "c7", "section": "wc", "level": 2,
 "q": "DOH = 60, DSO = 45, DPO = 50. If the company negotiates to pay suppliers 10 days later, its cash conversion cycle will:",
 "choices": {"A": "rise from 55 to 65 days.", "B": "fall from 55 to 45 days.", "C": "fall from 155 to 145 days."}, "answer": "B",
 "explanation": "CCC = 60 + 45 - 50 = 55; DPO rises to 60 so CCC = 45."},
{"id": "c8", "section": "wc", "level": 2,
 "q": "A working capital approach that finances permanent current assets with short-term borrowing is best described as:",
 "choices": {"A": "conservative.", "B": "moderate.", "C": "aggressive."}, "answer": "C",
 "explanation": "Funding permanent needs short-term creates rollover risk: aggressive."},
{"id": "c9", "section": "capbud", "level": 1,
 "q": "In capital budgeting, the cost of a market study completed last year for a proposed project should be:",
 "choices": {"A": "included as an initial outflow.", "B": "excluded because it is a sunk cost.", "C": "amortized over the project's life."}, "answer": "B",
 "explanation": "The cost is spent regardless of the decision: sunk."},
{"id": "c10", "section": "capbud", "level": 2,
 "q": "A project costs USD 500 and pays USD 200 a year for 3 years. At a 8% required return its NPV and decision are closest to:",
 "choices": {"A": "USD 15.42, accept.", "B": "USD 100.00, accept.", "C": "-USD 15.42, reject."}, "answer": "A",
 "explanation": r"$200 \times 2.5771 = 515.42$; NPV $= 15.42 > 0$. B ignores discounting. IRR is about 9.70%."},
{"id": "c11", "section": "capbud", "level": 2,
 "q": "For two mutually exclusive projects, NPV favors Project X and IRR favors Project Y. The firm should choose:",
 "choices": {"A": "X, because NPV measures the increase in shareholder wealth.", "B": "Y, because IRR is a percentage measure.", "C": "neither, because the methods conflict."}, "answer": "A",
 "explanation": "NPV assumes reinvestment at the required return and directly measures wealth added; it governs when the methods conflict."},
{"id": "c12", "section": "capbud", "level": 2,
 "q": "An option to wait one year for regulatory clarity before committing to a plant is best described as a(n):",
 "choices": {"A": "abandonment option.", "B": "timing option.", "C": "flexibility option."}, "answer": "B",
 "explanation": "The right to delay an investment is a timing option."},
{"id": "c13", "section": "capbud", "level": 2,
 "q": "Which is most likely a capital allocation pitfall?",
 "choices": {"A": "Using a project-specific discount rate for a riskier project.", "B": "Basing project decisions on their effect on next year's EPS.", "C": "Conducting a post-audit."}, "answer": "B",
 "explanation": "Focusing on accounting EPS instead of NPV is a common pitfall."},
{"id": "c14", "section": "capstruct", "level": 2,
 "q": "Weights 40% debt / 60% equity; pre-tax cost of debt 6%; tax rate 25%; cost of equity 10%. WACC is closest to:",
 "choices": {"A": "7.80%", "B": "8.40%", "C": "8.00%"}, "answer": "A",
 "explanation": r"$0.4(6\%)(0.75) + 0.6(10\%) = 1.8\% + 6.0\% = 7.8\%$. B uses the pre-tax cost of debt."},
{"id": "c15", "section": "capstruct", "level": 2,
 "q": "According to MM Proposition I without taxes, increasing leverage will:",
 "choices": {"A": "increase firm value.", "B": "decrease WACC.", "C": "leave firm value unchanged."}, "answer": "C",
 "explanation": "Without taxes, capital structure is irrelevant: the rising cost of equity exactly offsets cheaper debt."},
{"id": "c16", "section": "capstruct", "level": 2,
 "q": "An unlevered firm worth USD 500 million issues USD 200 million of debt to repurchase shares. With a 25% tax rate, MM with taxes implies a levered value of:",
 "choices": {"A": "USD 500 million.", "B": "USD 550 million.", "C": "USD 700 million."}, "answer": "B",
 "explanation": r"$V_L = V_U + tD = 500 + 0.25 \times 200 = 550$."},
{"id": "c17", "section": "capstruct", "level": 2,
 "q": "Under the static trade-off theory, the optimal capital structure occurs where:",
 "choices": {"A": "debt is 100% of capital.", "B": "the marginal tax benefit of debt equals the marginal expected cost of financial distress.", "C": "the cost of equity equals the cost of debt."}, "answer": "B",
 "explanation": "That is the point of minimum WACC and maximum firm value."},
{"id": "c18", "section": "capstruct", "level": 2,
 "q": "According to pecking order theory, managers' preferred order of financing is:",
 "choices": {"A": "new equity, debt, internal funds.", "B": "internal funds, debt, new equity.", "C": "debt, internal funds, new equity."}, "answer": "B",
 "explanation": "Asymmetric information makes issuing equity the most costly signal, so it is used last."},
{"id": "c19", "section": "capstruct", "level": 2,
 "q": "A firm's DOL is 2.0 and its DFL is 1.5. If sales rise by 10%, net income will rise by approximately:",
 "choices": {"A": "15%", "B": "20%", "C": "30%"}, "answer": "C",
 "explanation": r"$DTL = 2.0 \times 1.5 = 3.0$; $3.0 \times 10\% = 30\%$."},
{"id": "c20", "section": "bizmodel", "level": 1,
 "q": "A printer company that sells printers near cost and earns its profits from ink cartridges uses a:",
 "choices": {"A": "freemium model.", "B": "razors-and-blades model.", "C": "dynamic pricing model."}, "answer": "B",
 "explanation": "Low-margin base product with high-margin recurring consumables."},
{"id": "c21", "section": "bizmodel", "level": 1,
 "q": "A ride-sharing platform becomes more valuable to riders as more drivers join, and vice versa. This is an example of:",
 "choices": {"A": "economies of scope.", "B": "two-sided network effects.", "C": "tiered pricing."}, "answer": "B",
 "explanation": "Each user group's value depends on the size of the other: a two-sided network."},
],
}

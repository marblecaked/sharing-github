TOPIC = {
"id": "equity",
"name": "Equity Investments",
"weight": "11-14%",
"overview": r"""Equity covers how markets are organized, how indexes are built, whether markets are efficient, the types of equity securities, how to analyze industries and companies, and the basic valuation models. The calculation questions to master are **margin transactions, index returns under each weighting method, the dividend discount models, justified multiples and enterprise value**. The conceptual questions focus on order types, market efficiency forms and anomalies, and industry analysis frameworks.""",
"sections": [
{
"id": "markets",
"title": "Market Organization and Structure",
"body": r"""**Functions of the financial system**: saving, borrowing, raising equity, managing risk, exchanging assets, and using information. A well-functioning system is *operationally efficient* (low trading costs), *informationally efficient* (prices reflect information) and *allocationally efficient* (capital goes to its most productive uses).

**Positions.** A **long** position benefits from a price rise. A **short** seller borrows shares and sells them, hoping to buy back cheaper; the short seller must pay any dividends to the lender and post collateral. Shorting has theoretically unlimited loss.

**Leveraged (margin) positions.** Buying on margin means borrowing part of the purchase price from the broker. The **initial margin** is the investor's minimum equity share at purchase; the **maintenance margin** is the minimum equity share thereafter. If equity falls below it, the investor receives a **margin call** and must deposit funds to restore equity to the initial (or maintenance) level. The leverage ratio is $1/\text{initial margin}$: with 50% margin, a 10% price move becomes a roughly 20% move in equity.

**Orders** have execution, validity and clearing instructions:

- **Market order**: execute immediately at the best available price. Certainty of execution, uncertain price.
- **Limit order**: buy at no more than (sell at no less than) the limit price. Price certainty, execution uncertain. A buy limit below the best ask is "behind the market"; one above the best ask is "marketable".
- **Stop order** (stop-loss): becomes a market order once the stop price is reached. A *sell stop* sits below the current price to limit losses on a long position; a *buy stop* sits above the price to limit losses on a short.
- Validity: day order, good-till-cancelled, immediate-or-cancel (fill or kill), good-on-close.

**Market structures.** **Quote-driven** (dealer) markets: traders transact with dealers who post bid and ask prices (most bonds, FX). **Order-driven** markets: orders are matched by rules (price priority, then display, then time priority) in auctions or electronic crossing networks; most stock exchanges. **Brokered** markets: brokers find counterparties for unique, illiquid assets (real estate, large blocks).

**Primary vs. secondary markets.** In the primary market issuers sell new securities (IPOs, seasoned offerings, private placements, rights offerings, shelf registrations). Underwritten offerings put the investment bank at risk for unsold shares; best-efforts offerings do not. Secondary markets provide liquidity that lowers issuers' cost of capital.

**Regulation** aims to control fraud and agency problems, promote fairness, set mutually beneficial standards, prevent excessive risk-taking and ensure the solvency of long-term liabilities.""",
"formulas": [
{"name": "Leverage ratio", "tex": r"\text{Leverage ratio} = \frac{1}{\text{Initial margin}}", "vars": [], "note": ""},
{"name": "Margin call trigger price (long)", "tex": r"P^* = P_0 \times \frac{1 - IM}{1 - MM}", "vars": [["P_0", "purchase price"], ["IM", "initial margin"], ["MM", "maintenance margin"]], "note": "Below $P^*$ the investor receives a margin call."},
{"name": "Return on a margin purchase", "tex": r"R = \frac{(P_1 - P_0)Q + \text{Dividends} - \text{Interest} - \text{Commissions}}{\text{Initial equity}}", "vars": [], "note": ""},
],
"examples": [
{"title": "Margin purchase",
 "problem": "An investor buys 1,000 shares at USD 50 with 50% initial margin and 25% maintenance margin. The loan rate is 6%. One year later she sells at USD 60, having received USD 0.50 per share in dividends. Ignore commissions. Find the margin call price and the return on equity.",
 "steps": [r"Margin call price $= 50 \times (1 - 0.50)/(1 - 0.25) = 33.33$.",
           r"Equity $= 25{,}000$; loan $= 25{,}000$; interest $= 1{,}500$.",
           r"Gain $= (60 - 50) \times 1{,}000 = 10{,}000$; dividends $= 500$.",
           r"Return $= (10{,}000 + 500 - 1{,}500)/25{,}000 = 36.0\%$ (vs. 21% unlevered)."],
 "answer": "Margin call below USD 33.33; return on equity 36.0%."},
],
},
{
"id": "indexes",
"title": "Security Market Indexes",
"body": r"""An index represents a market or segment. Uses: gauging sentiment, proxies for asset classes, benchmarks for active managers, the basis for index funds and ETFs, and the market portfolio in asset pricing models.

**Index construction decisions**: the target market, which securities, how to weight them, how often to rebalance, and how often to reconstitute (change membership).

**Weighting methods.**

- **Price-weighted** (e.g. the DJIA, Nikkei 225): weight = price / sum of prices. High-priced stocks dominate regardless of company size. The divisor is adjusted for splits; a split *reduces* the stock's weight. The index return equals the return on holding one share of each stock.
- **Equal-weighted**: every security has the same weight. Overweights small caps relative to the market and must be rebalanced frequently, which creates turnover.
- **Market-capitalization weighted** (value-weighted): weight = market cap / total market cap. Self-rebalancing; overweights large, possibly overvalued stocks (momentum bias). **Float-adjusted** versions use only shares available to the public.
- **Fundamental weighting**: weights by sales, earnings, book value or dividends; has a value tilt and a contrarian rebalancing effect.

**Price return vs. total return.** A price return index reflects only price changes; a total return index also reinvests income.

**Rebalancing** restores target weights (needed for equal weighting). **Reconstitution** changes the index's membership (adds and deletes).

**Types of indexes**: broad market, multi-market, sector, style (value/growth, size). Fixed income indexes are harder to build and replicate: huge numbers of issues, frequent turnover as bonds mature, and dealer markets with stale prices. Alternative investment indexes (commodities, real estate, hedge funds) have their own biases, e.g. **survivorship bias** and voluntary reporting in hedge fund indexes.""",
"formulas": [
{"name": "Price-weighted index", "tex": r"V_{PW} = \frac{\sum_{i=1}^{N} P_i}{\text{Divisor}} \qquad w_i = \frac{P_i}{\sum P_j}", "vars": [], "note": ""},
{"name": "Market-cap weight", "tex": r"w_i = \frac{Q_i P_i}{\sum_j Q_j P_j}", "vars": [["Q_i", "shares outstanding (float-adjusted if applicable)"]], "note": ""},
{"name": "Index return", "tex": r"R_{index} = \sum_{i=1}^{N} w_i R_i", "vars": [["w_i", "beginning-of-period weight"], ["R_i", "return of constituent i"]], "note": ""},
],
"examples": [
{"title": "Three weighting methods",
 "problem": "Stock A: price 20 to 22, 100 shares. Stock B: 50 to 48, 50 shares. Stock C: 100 to 110, 20 shares. Compute the price-, value- and equal-weighted index returns.",
 "steps": [r"Price-weighted: sum of prices $170 \to 180$: $180/170 - 1 = 5.88\%$.",
           r"Value-weighted: market caps $2{,}000 + 2{,}500 + 2{,}000 = 6{,}500$ become $2{,}200 + 2{,}400 + 2{,}200 = 6{,}800$: $4.62\%$.",
           r"Equal-weighted: $(10\% - 4\% + 10\%)/3 = 5.33\%$."],
 "answer": "5.88% (price), 4.62% (value), 5.33% (equal). Stock C, the highest-priced, dominates the price-weighted index."},
],
},
{
"id": "efficiency",
"title": "Market Efficiency",
"body": r"""An **informationally efficient** market adjusts prices quickly and rationally to new information, so active strategies cannot consistently earn abnormal *risk-adjusted* returns after costs. **Market value** (price) differs from **intrinsic value**; in an efficient market they are close.

**Factors that affect efficiency**: number of market participants, availability of information, impediments to trading (e.g. short-selling restrictions), and transaction and information-acquisition costs. Markets are efficient only up to the cost of exploiting mispricing.

**Forms of the Efficient Market Hypothesis (Fama).**

| Form | Prices reflect | Implication |
|---|---|---|
| Weak | All past market data (prices, volume) | Technical analysis cannot earn abnormal returns |
| Semi-strong | All public information (including financial statements and news) | Fundamental analysis of public information cannot earn abnormal returns |
| Strong | All information, public and private | Even insiders cannot earn abnormal returns |

Each form includes the weaker forms. Evidence supports weak-form efficiency in developed markets and broadly semi-strong efficiency; strong form is rejected because insiders do earn abnormal returns.

**Implications.** If markets are semi-strong efficient, passive management is appropriate for most investors; the portfolio manager's role is to build portfolios matching the client's risk, return and constraints, not to pick stocks.

**Anomalies** (apparent violations that may vanish once properly adjusted for risk or costs): *time-series* (January effect, day-of-week, momentum and overreaction), *cross-sectional* (size effect, value effect: low P/B or P/E stocks outperforming), and *other* (closed-end fund discounts, earnings surprise drift, IPO underperformance over the long run). Many disappear after publication or reflect data mining.

**Behavioral finance** explains some anomalies through biases: loss aversion, herding, overconfidence, representativeness, mental accounting, conservatism and narrow framing. Behavioral biases do not by themselves make markets inefficient, unless they produce exploitable mispricing.""",
"formulas": [],
"examples": [
{"title": "Which form is violated?",
 "problem": "A strategy that buys stocks one day after positive earnings announcements earns consistent risk-adjusted excess returns after costs. Which form of EMH does this contradict?",
 "steps": ["Earnings announcements are public information.", "Profiting from public information contradicts semi-strong efficiency (and therefore strong form), but not weak form."],
 "answer": "Semi-strong form."},
],
},
{
"id": "securities_industry",
"title": "Equity Securities, Industry and Company Analysis",
"body": r"""**Types of equity.** **Common shares** carry residual claims and voting rights (statutory: one vote per share per seat; cumulative: votes can be concentrated). **Preference (preferred) shares** have priority over common for dividends and in liquidation, usually without voting rights; cumulative preferred accrues unpaid dividends; participating preferred can share in extra profits; convertible preferred can convert to common. **Callable** shares give the issuer the right to repurchase (bad for investors: compensates with higher dividend); **putable** shares give the investor the right to sell back.

**Private vs. public equity.** Private equity is illiquid, has less disclosure, and can take a longer-term view. Venture capital funds early-stage firms; leveraged buyouts take public companies private.

**Foreign equity access**: direct investing, depository receipts (sponsored vs. unsponsored ADRs/GDRs), global registered shares, and baskets of listed depository receipts.

**Return and risk.** Equity returns come from price change, dividends and (for foreign shares) currency. The **book value** of equity is the accounting value; **market value** reflects expectations. **ROE** = net income / average book equity. The **cost of equity** is the minimum return investors require; it is not directly observable and is estimated with models like CAPM or DDM.

**Industry analysis.**

- **Classification**: by products and services (GICS, ICB), by sensitivity to the business cycle (**cyclical** vs. **non-cyclical**, the latter split into defensive and growth), or statistically.
- **Porter's five forces**: threat of new entrants, threat of substitutes, bargaining power of suppliers, bargaining power of customers, rivalry among existing competitors. Industries with high barriers to entry, few substitutes and weak buyers/suppliers tend to be more profitable.
- **Industry life cycle**: embryonic (slow growth, high prices), growth (rapid demand growth, falling prices, improving profitability, limited competition), shakeout (slowing growth, intense competition, consolidation), mature (little growth, consolidation, high barriers, stable prices), decline (falling demand, overcapacity, price competition).
- **PESTLE** for external influences: political, economic, social, technological, legal, environmental.
- **Strategic groups**, pricing power, market share stability, capacity and capital intensity.

**Company analysis** covers the business model, revenue drivers, cost structure, competitive position (cost leadership, differentiation, focus) and ESG risks, and builds the forecasts that feed valuation.""",
"formulas": [
{"name": "Sustainable growth rate", "tex": r"g = b \times ROE", "vars": [["b", "earnings retention rate = 1 - payout ratio"], ["ROE", "return on equity"]], "note": ""},
],
"examples": [
{"title": "Life cycle",
 "problem": "An industry's growth has slowed from 25% to 8% a year, many weaker competitors are exiting or being acquired, and price competition is intense. Which life cycle stage?",
 "steps": ["Rapid growth has ended, but the industry is not yet stable.", "Consolidation and intense price competition characterize the shakeout stage."],
 "answer": "Shakeout."},
],
},
{
"id": "valuation",
"title": "Equity Valuation",
"body": r"""Three model families:

1. **Present value (discounted cash flow) models**: dividend discount models (DDM), free cash flow to equity models. Intrinsic value = PV of expected future cash flows to shareholders.
2. **Multiplier (relative) models**: price multiples (P/E, P/B, P/S, P/CF) and enterprise value multiples (EV/EBITDA, EV/Sales).
3. **Asset-based models**: value of assets minus liabilities, adjusted to market value. Useful for firms with mostly tangible or financial assets, holding companies and liquidations; poor for firms with large intangibles.

If the estimated intrinsic value exceeds market price, the stock is **undervalued** (buy); if below, **overvalued**.

**Dividend discount models.**

- **Gordon (constant) growth model**: $V_0 = D_1/(r - g)$. Requires $r > g$ and a stable, mature firm with a dividend policy linked to earnings.
- **Multistage models** for firms with high current growth: forecast dividends individually through the high-growth period, then apply the Gordon model to get a *terminal value* at the end of the high-growth period, and discount everything at $r$.
- **Preferred stock** with a fixed dividend and no maturity: $V = D/r$.
- **FCFE models** replace dividends with free cash flow to equity: useful when the company pays no or irregular dividends, or when an investor takes a control perspective.

**Price multiples.** The **justified P/E** follows from the Gordon model: leading $P_0/E_1 = (D_1/E_1)/(r-g) = p/(r-g)$. It shows that P/E rises with higher payout (holding growth constant), lower required return, and higher growth. **Method of comparables** values a firm relative to peers' multiples; it gives *relative* not absolute value, so if the whole sector is overvalued, so is the estimate.

**Enterprise value** is the value of the whole firm to all capital providers: $EV = \text{market value of equity} + \text{debt} + \text{preferred} + \text{minority interest} - \text{cash and short-term investments}$. EV/EBITDA is useful for comparing firms with different capital structures, and EBITDA is usually positive even when earnings are not.""",
"formulas": [
{"name": "Gordon growth model", "tex": r"V_0 = \frac{D_1}{r - g} = \frac{D_0(1+g)}{r - g}", "vars": [["D_1", "dividend expected next year"], ["r", "required return on equity"], ["g", "constant long-term dividend growth, g < r"]], "note": ""},
{"name": "Multistage DDM", "tex": r"V_0 = \sum_{t=1}^{n}\frac{D_t}{(1+r)^t} + \frac{V_n}{(1+r)^n} \qquad V_n = \frac{D_{n+1}}{r - g_L}", "vars": [["n", "end of high-growth period"], ["g_L", "long-run stable growth"]], "note": "The terminal value is discounted n periods, the same as $D_n$."},
{"name": "Preferred stock value", "tex": r"V_0 = \frac{D_p}{r_p}", "vars": [["D_p", "fixed preferred dividend"], ["r_p", "required return on the preferred"]], "note": ""},
{"name": "Justified P/E", "tex": r"\frac{P_0}{E_1} = \frac{D_1/E_1}{r - g} \qquad \frac{P_0}{E_0} = \frac{(D_0/E_0)(1+g)}{r - g}", "vars": [["D/E", "dividend payout ratio"]], "note": "Leading (left) and trailing (right)."},
{"name": "Enterprise value", "tex": r"EV = \text{Market cap} + \text{Debt} + \text{Preferred} + \text{Minority interest} - \text{Cash}", "vars": [], "note": ""},
],
"examples": [
{"title": "Gordon growth",
 "problem": "D0 = USD 2.00, g = 5%, r = 9%. Value the share.",
 "steps": [r"$D_1 = 2.00 \times 1.05 = 2.10$.", r"$V_0 = 2.10/(0.09 - 0.05) = 52.50$."],
 "answer": "USD 52.50. (Using D0 instead of D1 is the classic mistake: 50.00.)"},
{"title": "Two-stage DDM",
 "problem": "D0 = USD 1.00. Dividends grow 20% for 3 years, then 5% forever. Required return 10%. Value the share.",
 "steps": [r"$D_1 = 1.20$, $D_2 = 1.44$, $D_3 = 1.728$.",
           r"Terminal value at t = 3: $V_3 = D_4/(r - g) = 1.728(1.05)/0.05 = 36.288$.",
           r"PVs: $1.20/1.1 = 1.0909$; $1.44/1.1^2 = 1.1901$; $1.728/1.1^3 = 1.2983$; $36.288/1.1^3 = 27.2637$.",
           r"$V_0 = 1.0909 + 1.1901 + 1.2983 + 27.2637 = 30.84$."],
 "answer": "USD 30.84. Note how most of the value is in the terminal value."},
{"title": "Justified P/E",
 "problem": "Payout ratio 40%, required return 10%, sustainable growth 6%. Compute the justified leading and trailing P/E.",
 "steps": [r"Leading: $0.40/(0.10 - 0.06) = 10.0\times$.", r"Trailing: $0.40 \times 1.06/0.04 = 10.6\times$."],
 "answer": "10.0x leading, 10.6x trailing."},
],
},
],
"pitfalls": [
"Gordon model uses D1, not D0. The terminal value in a multistage model is discounted n periods.",
"Price-weighted: high-priced stocks dominate; a split lowers the stock's weight. Value-weighted indexes overweight possibly overvalued large caps.",
"Equal weighting requires frequent rebalancing and tilts toward small caps.",
"Weak form: past prices; semi-strong: all public info; strong: all info including private.",
"A buy stop sits ABOVE the market (protects a short); a sell stop sits BELOW (protects a long).",
"Margin call price = P0(1 - IM)/(1 - MM).",
"EV adds debt, preferred and minority interest and SUBTRACTS cash.",
"Callable preferred is worth less to investors; putable is worth more.",
],
"problems": [
{"id": "q1", "section": "markets", "level": 2,
 "q": "An investor buys a stock at USD 40 with 40% initial margin and 30% maintenance margin. The price at which she will receive a margin call is closest to:",
 "choices": {"A": "USD 28.00", "B": "USD 34.29", "C": "USD 22.86"}, "answer": "B",
 "explanation": r"$40 \times (1 - 0.40)/(1 - 0.30) = 40 \times 0.6/0.7 = 34.29$."},
{"id": "q2", "section": "markets", "level": 1,
 "q": "An investor who is short a stock and wants to limit losses if the price rises should place a:",
 "choices": {"A": "sell stop order below the market.", "B": "buy stop order above the market.", "C": "buy limit order below the market."}, "answer": "B",
 "explanation": "A buy stop triggers a purchase to close the short once the price rises to the stop price."},
{"id": "q3", "section": "markets", "level": 2,
 "q": "The bid is USD 20.10 and the ask is USD 20.15. A limit buy order at USD 20.12 is best described as:",
 "choices": {"A": "making a new market (inside the spread).", "B": "behind the market.", "C": "marketable."}, "answer": "A",
 "explanation": "It is above the best bid and below the best ask, so it becomes the new best bid."},
{"id": "q4", "section": "markets", "level": 1,
 "q": "In which type of market do traders primarily trade with dealers who post bid and ask prices?",
 "choices": {"A": "Quote-driven", "B": "Order-driven", "C": "Brokered"}, "answer": "A",
 "explanation": "Quote-driven (dealer) markets."},
{"id": "q5", "section": "markets", "level": 2,
 "q": "With an initial margin requirement of 25%, the leverage ratio is:",
 "choices": {"A": "1.25", "B": "2.5", "C": "4.0"}, "answer": "C",
 "explanation": r"$1/0.25 = 4$: a 1% price change moves equity by about 4%."},
{"id": "q6", "section": "indexes", "level": 2,
 "q": "Which index weighting method is most affected by a stock split of one constituent, absent an adjustment?",
 "choices": {"A": "Price-weighted", "B": "Market-cap weighted", "C": "Equal-weighted"}, "answer": "A",
 "explanation": "A split changes the price but not market value. The divisor must be adjusted, and afterward the stock carries less weight."},
{"id": "q7", "section": "indexes", "level": 2,
 "q": "Compared with a market-cap weighted index, an equal-weighted index most likely:",
 "choices": {"A": "has lower turnover.", "B": "overweights small-capitalization stocks.", "C": "is self-rebalancing."}, "answer": "B",
 "explanation": "Equal weights give small firms more weight than their market share; frequent rebalancing raises turnover."},
{"id": "q8", "section": "indexes", "level": 2,
 "q": "Fundamentally weighted indexes typically have a tilt toward:",
 "choices": {"A": "growth stocks.", "B": "value stocks.", "C": "momentum stocks."}, "answer": "B",
 "explanation": "Weighting by fundamentals relative to price overweights stocks with low price-to-fundamental ratios."},
{"id": "q9", "section": "indexes", "level": 1,
 "q": "Changing the membership of an index by adding and deleting securities is called:",
 "choices": {"A": "rebalancing.", "B": "reconstitution.", "C": "float adjustment."}, "answer": "B",
 "explanation": "Rebalancing adjusts weights of existing members; reconstitution changes membership."},
{"id": "q10", "section": "efficiency", "level": 1,
 "q": "If markets are weak-form efficient, which strategy cannot earn abnormal returns?",
 "choices": {"A": "Trading on insider information.", "B": "Technical analysis.", "C": "Fundamental analysis."}, "answer": "B",
 "explanation": "Weak form: prices already reflect past price and volume data."},
{"id": "q11", "section": "efficiency", "level": 2,
 "q": "Evidence that corporate insiders earn abnormal returns on trades in their own company's stock is inconsistent with:",
 "choices": {"A": "weak-form efficiency.", "B": "semi-strong form efficiency.", "C": "strong-form efficiency."}, "answer": "C",
 "explanation": "Only strong form claims prices reflect private information."},
{"id": "q12", "section": "efficiency", "level": 2,
 "q": "Which is a cross-sectional anomaly?",
 "choices": {"A": "The January effect.", "B": "The value effect.", "C": "Momentum."}, "answer": "B",
 "explanation": "Value and size effects compare securities at a point in time; January and momentum are time-series anomalies."},
{"id": "q13", "section": "securities_industry", "level": 2,
 "q": "From the investor's perspective, compared with otherwise identical non-callable preferred shares, callable preferred shares will most likely have:",
 "choices": {"A": "a higher price and lower dividend yield.", "B": "a lower price and higher required dividend yield.", "C": "the same price."}, "answer": "B",
 "explanation": "The call option benefits the issuer, so investors demand compensation."},
{"id": "q14", "section": "securities_industry", "level": 2,
 "q": "An industry in which demand growth is rapid, prices are falling and profitability is improving with limited competitive pressure is most likely in the:",
 "choices": {"A": "embryonic stage.", "B": "growth stage.", "C": "mature stage."}, "answer": "B",
 "explanation": "These are the characteristics of the growth stage."},
{"id": "q15", "section": "securities_industry", "level": 2,
 "q": "Under Porter's five forces, industry profitability is most likely to be higher when:",
 "choices": {"A": "customers are concentrated and products are commodities.", "B": "barriers to entry are high and substitutes are few.", "C": "suppliers are few and specialized."}, "answer": "B",
 "explanation": "High barriers and few substitutes protect incumbents' pricing power."},
{"id": "q16", "section": "securities_industry", "level": 2,
 "q": "A company has ROE of 15% and a dividend payout ratio of 40%. Its sustainable growth rate is:",
 "choices": {"A": "6.0%", "B": "9.0%", "C": "15.0%"}, "answer": "B",
 "explanation": r"$g = b \times ROE = 0.60 \times 15\% = 9\%$."},
{"id": "q17", "section": "valuation", "level": 1,
 "q": "D0 = USD 1.50, constant growth 4%, required return 8.5%. The value per share is closest to:",
 "choices": {"A": "USD 33.33", "B": "USD 34.67", "C": "USD 37.14"}, "answer": "B",
 "explanation": r"$1.50(1.04)/(0.085 - 0.04) = 1.56/0.045 = 34.67$. A uses D0."},
{"id": "q18", "section": "valuation", "level": 3,
 "q": "Expected dividends are USD 2.00 next year and USD 2.20 in year 2, after which dividends grow at 4% forever. Required return 11%. Value per share is closest to:",
 "choices": {"A": "USD 28.57", "B": "USD 30.12", "C": "USD 32.69"}, "answer": "B",
 "explanation": r"$V_2 = 2.20(1.04)/0.07 = 32.69$. $V_0 = 2.00/1.11 + (2.20 + 32.69)/1.11^2 = 1.80 + 28.32 = 30.12$. C is the undiscounted terminal value."},
{"id": "q19", "section": "valuation", "level": 2,
 "q": "Holding other factors constant, the justified P/E ratio increases when:",
 "choices": {"A": "the required return rises.", "B": "the expected growth rate rises.", "C": "the payout ratio falls with no change in growth."}, "answer": "B",
 "explanation": r"$P/E = p/(r - g)$: a higher g narrows the denominator."},
{"id": "q20", "section": "valuation", "level": 2,
 "q": "Market cap USD 800M, debt USD 300M, preferred USD 50M, cash USD 100M. Enterprise value is:",
 "choices": {"A": "USD 1,050M", "B": "USD 1,150M", "C": "USD 1,250M"}, "answer": "A",
 "explanation": r"$800 + 300 + 50 - 100 = 1{,}050$."},
{"id": "q21", "section": "valuation", "level": 2,
 "q": "An asset-based valuation model is most appropriate for:",
 "choices": {"A": "a software company with valuable patents.", "B": "a holding company whose assets are mainly listed securities.", "C": "a fast-growing consumer brand."}, "answer": "B",
 "explanation": "Asset-based models work when assets are mainly tangible or financial and can be valued at market."},
{"id": "q22", "section": "valuation", "level": 1,
 "q": "A preferred share pays a fixed annual dividend of USD 6 with no maturity. If the required return is 7.5%, its value is:",
 "choices": {"A": "USD 75.00", "B": "USD 80.00", "C": "USD 85.71"}, "answer": "B",
 "explanation": r"$6/0.075 = 80$."},
],
}

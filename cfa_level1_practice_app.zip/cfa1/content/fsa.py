TOPIC = {
"id": "fsa",
"name": "Financial Statement Analysis",
"weight": "11-14%",
"overview": r"""FSA is one of the three largest topics and the one most candidates find hardest, because it rewards understanding *how one accounting choice ripples through all three statements and the ratios*. The curriculum covers the framework of financial reporting, the income statement, balance sheet and cash flow statement, inventories, long-lived assets, long-term liabilities (bonds, leases, pensions), income taxes, financial reporting quality, ratio analysis and an introduction to modeling.

The study habit that pays off: for every accounting choice, ask **"what happens to net income, assets, equity, cash flow from operations, and the key ratios, in the early years and in later years?"** Most exam questions are exactly that.""",
"sections": [
{
"id": "framework",
"title": "Reporting Framework and the Income Statement",
"body": r"""**Standard setters vs. regulators.** Standard setters (IASB for IFRS, FASB for US GAAP) write the rules; regulators (e.g. the SEC, national securities commissions) enforce them and require filings. In the US, the key filings are the 10-K (annual), 10-Q (quarterly) and 8-K (material events); proxy statements disclose governance and pay.

**Qualitative characteristics** (Conceptual Framework): fundamental characteristics are **relevance** (including materiality) and **faithful representation** (complete, neutral, free from error). Enhancing characteristics: comparability, verifiability, timeliness, understandability. Constraint: the cost of reporting should not exceed its benefits.

**The audit opinion**: unqualified (clean), qualified (exceptions), adverse (statements not fairly presented), or disclaimer (auditor unable to form an opinion). Auditors provide *reasonable*, not absolute, assurance. Key audit matters / critical audit matters highlight areas of significant judgment. Footnotes and MD&A are essential reading.

**Revenue recognition** (IFRS 15 / ASC 606) follows five steps: (1) identify the contract, (2) identify the separate performance obligations, (3) determine the transaction price, (4) allocate the price to the obligations, (5) recognize revenue when (or as) each obligation is satisfied, at a point in time or over time. Long-term contracts are recognized over time based on progress. A company acting as an **agent** (arranging a sale for another party) reports only its net commission, not gross sales.

**Expense recognition** follows the matching principle: COGS matched to revenue, period costs (admin) expensed as incurred.

**Non-recurring items.** **Discontinued operations** (a component that has been disposed of or is held for sale and is operationally and physically separable) are reported net of tax, *below* income from continuing operations. Unusual or infrequent items are reported in continuing operations (pre-tax). Changes in accounting policy are applied **retrospectively** (prior periods restated); changes in **estimates** are applied **prospectively**; corrections of errors restate prior periods.

**EPS.** Basic EPS uses net income less preferred dividends over weighted average common shares. **Diluted EPS** adds the effect of potentially dilutive securities, but only if they are dilutive (they reduce EPS):

- **Convertible preferred** (if-converted): add back preferred dividends to the numerator, add conversion shares to the denominator.
- **Convertible bonds** (if-converted): add back after-tax interest, add conversion shares.
- **Options and warrants** (treasury stock method): assume exercise and that proceeds repurchase shares at the *average* market price; only in-the-money options (exercise price < average price) are dilutive.

**Comprehensive income** = net income + other comprehensive income (OCI). OCI includes foreign currency translation adjustments, certain pension remeasurements, unrealized gains on debt securities at FVOCI, and the effective portion of cash flow hedges. Analysts should look at OCI because items can bypass the income statement.""",
"formulas": [
{"name": "Basic EPS", "tex": r"\text{Basic EPS} = \frac{\text{Net income} - \text{Preferred dividends}}{\text{Weighted average common shares}}", "vars": [], "note": ""},
{"name": "Diluted EPS", "tex": r"\text{Diluted EPS} = \frac{NI - \text{Pref div} + \text{Conv. pref div} + \text{Conv. debt interest}(1-t)}{\text{WASO} + \text{conversion shares} + \text{net TSM shares}}", "vars": [], "note": "Include each security only if it reduces EPS (is dilutive)."},
{"name": "Treasury stock method: net new shares", "tex": r"\text{Net new shares} = N - \frac{N \times X}{\bar P}",
 "vars": [["N", "number of options/warrants"], ["X", "exercise price"], ["\\bar P", "average market price over the period"]], "note": ""},
],
"examples": [
{"title": "Diluted EPS with options",
 "problem": "Net income USD 1,000,000; preferred dividends USD 100,000; 500,000 weighted average shares. 50,000 options outstanding with exercise price USD 20; average share price USD 25. Compute basic and diluted EPS.",
 "steps": [r"Basic EPS $= (1{,}000{,}000 - 100{,}000)/500{,}000 = 1.80$.",
           r"Option proceeds $= 50{,}000 \times 20 = 1{,}000{,}000$, buying back $1{,}000{,}000/25 = 40{,}000$ shares; net new shares $= 10{,}000$.",
           r"Diluted EPS $= 900{,}000/510{,}000 = 1.76$."],
 "answer": "Basic 1.80; diluted 1.76."},
{"title": "Convertible bond (if-converted)",
 "problem": "NI = USD 2,000,000; 1,000,000 shares; no preferred. USD 5,000,000 of 6% convertible bonds convert into 200,000 shares; tax rate 25%. Diluted EPS?",
 "steps": [r"After-tax interest added back $= 5{,}000{,}000 \times 6\% \times 0.75 = 225{,}000$.",
           r"Diluted EPS $= (2{,}000{,}000 + 225{,}000)/1{,}200{,}000 = 1.854$.",
           r"Basic EPS is 2.00, so the bonds are dilutive and are included."],
 "answer": "Diluted EPS = 1.85."},
],
},
{
"id": "bs_cf",
"title": "Balance Sheet and Cash Flow Statement",
"body": r"""**Balance sheet.** Assets = Liabilities + Equity. Current assets and liabilities are expected to be realized or settled within one year or the operating cycle. IFRS allows presentation by liquidity when more relevant (e.g. banks).

**Measurement bases.** Some items at historical cost (PP&E under the cost model, inventory), some at amortized cost (held-to-maturity debt), some at **fair value**. Financial asset classification under IFRS 9: **amortized cost** (business model to hold and collect contractual cash flows, which are solely principal and interest), **FVOCI** (hold to collect and sell; unrealized gains to OCI), **FVPL** (everything else; unrealized gains to the income statement). Equity investments are FVPL, or FVOCI by irrevocable election.

**Intangibles.** Purchased intangibles are capitalized. Internally developed intangibles are generally expensed: under IFRS research is expensed and development may be capitalized once technical feasibility is established; under US GAAP both R&D are generally expensed (with an exception for software). **Goodwill** (acquisition price minus fair value of identifiable net assets) is not amortized but tested for impairment.

**Cash flow statement.** Three sections:

| | IFRS | US GAAP |
|---|---|---|
| Interest received | CFO or CFI | CFO |
| Dividends received | CFO or CFI | CFO |
| Interest paid | CFO or CFF | CFO |
| Dividends paid | CFO or CFF | CFF |
| Taxes paid | CFO (unless tied to investing/financing) | CFO |

Non-cash investing and financing (e.g. converting debt to equity, acquiring an asset with a lease) are disclosed, not reported in the cash flows.

**Indirect method (CFO).** Start from net income; add back non-cash charges (depreciation, amortization, impairments); subtract gains and add losses on sales of assets (the cash shows up in CFI); then adjust for working capital: **an increase in an operating asset is a use of cash (subtract); an increase in an operating liability is a source (add).**

**Direct method** shows actual cash receipts and payments: e.g. cash collected from customers = revenue - increase in receivables + increase in unearned revenue; cash paid to suppliers = COGS + increase in inventory - increase in payables.

**Free cash flow.** Free cash flow to the firm (FCFF) is cash available to all capital providers; free cash flow to equity (FCFE) is what remains for shareholders after debt holders are paid and net borrowing is added. Both reappear in equity valuation.""",
"formulas": [
{"name": "CFO by the indirect method", "tex": r"CFO = NI + \text{non-cash charges} - \text{gains} + \text{losses} - \Delta\text{operating assets} + \Delta\text{operating liabilities}", "vars": [], "note": ""},
{"name": "Free cash flow to the firm", "tex": r"FCFF = CFO + \text{Int}(1-t) - FCInv", "vars": [["\\text{Int}(1-t)", "after-tax interest (if interest paid is in CFO)"], ["FCInv", "fixed capital investment (capex net of disposals)"]], "note": "Alternative: $FCFF = NI + NCC + Int(1-t) - FCInv - WCInv$."},
{"name": "Free cash flow to equity", "tex": r"FCFE = CFO - FCInv + \text{Net borrowing}", "vars": [], "note": ""},
],
"examples": [
{"title": "CFO, indirect method",
 "problem": "Net income 500; depreciation 100; accounts receivable increased 40; inventory decreased 20; accounts payable increased 30; gain on sale of equipment 15. Compute CFO.",
 "steps": [r"Start: 500 + 100 (depreciation) - 15 (gain) = 585.",
           r"Working capital: -40 (AR up) + 20 (inventory down) + 30 (AP up) = +10.",
           r"$CFO = 585 + 10 = 595$."],
 "answer": "CFO = 595. The sale proceeds belong in CFI."},
],
},
{
"id": "inventory",
"title": "Inventories",
"body": r"""**Cost flow methods.** FIFO (first in, first out), weighted average cost, and specific identification are allowed under both IFRS and US GAAP. **LIFO** (last in, first out) is **allowed only under US GAAP**.

**When prices are rising (and inventory quantities stable or growing):**

| | LIFO | FIFO |
|---|---|---|
| COGS | Higher (recent, high costs) | Lower |
| Gross profit, net income | Lower | Higher |
| Income taxes paid | Lower | Higher |
| Cash flow (after tax) | Higher | Lower |
| Ending inventory | Lower (old costs: understated) | Higher (closer to current cost) |
| Current ratio, equity | Lower | Higher |
| Inventory turnover | Higher | Lower |

FIFO gives the better **balance sheet** value; LIFO gives the better **income statement** matching of current costs with revenue.

**LIFO reserve** = FIFO inventory - LIFO inventory. Analysts convert LIFO firms to FIFO to compare: add the reserve to inventory, adjust equity by the reserve net of tax (and deferred taxes by reserve times tax rate), and reduce COGS by the *change* in the reserve. **LIFO liquidation** occurs when a firm sells more than it buys, releasing old low-cost layers into COGS and inflating profit; it is not sustainable, and it is signaled by a falling LIFO reserve.

**Measurement.** IFRS: lower of cost and **net realizable value** (NRV = selling price - costs to complete and sell); write-downs can be **reversed** (up to the original cost). US GAAP: lower of cost and NRV for FIFO/average cost, lower of cost or market for LIFO/retail; **reversals are prohibited**.

**Periodic vs. perpetual systems** give the same results under FIFO and specific identification but can differ under LIFO and weighted average.""",
"formulas": [
{"name": "Cost of goods sold identity", "tex": r"COGS = \text{Beginning inventory} + \text{Purchases} - \text{Ending inventory}", "vars": [], "note": ""},
{"name": "LIFO to FIFO conversion", "tex": r"Inv_{FIFO} = Inv_{LIFO} + \text{LIFO reserve} \qquad COGS_{FIFO} = COGS_{LIFO} - \Delta\text{LIFO reserve}", "vars": [], "note": "Retained earnings rise by the reserve times (1 - t)."},
{"name": "Inventory ratios", "tex": r"\text{Inventory turnover} = \frac{COGS}{\text{Average inventory}} \qquad DOH = \frac{365}{\text{Inventory turnover}}", "vars": [], "note": ""},
],
"examples": [
{"title": "FIFO, LIFO and weighted average",
 "problem": "Beginning inventory 100 units at USD 10. Purchases: 200 units at USD 12, then 100 units at USD 15. 250 units are sold at USD 20 (periodic system). Compute COGS, ending inventory and gross profit under each method.",
 "steps": [r"Goods available: 400 units costing $1{,}000 + 2{,}400 + 1{,}500 = 4{,}900$. Revenue $= 250 \times 20 = 5{,}000$.",
           r"FIFO: COGS $= 100(10) + 150(12) = 2{,}800$; ending inventory $= 50(12) + 100(15) = 2{,}100$; gross profit $= 2{,}200$.",
           r"LIFO: COGS $= 100(15) + 150(12) = 3{,}300$; ending inventory $= 50(12) + 100(10) = 1{,}600$; gross profit $= 1{,}700$.",
           r"Weighted average: $4{,}900/400 = 12.25$ per unit; COGS $= 3{,}062.50$; ending inventory $= 1{,}837.50$; gross profit $= 1{,}937.50$.",
           r"LIFO reserve $= 2{,}100 - 1{,}600 = 500$."],
 "answer": "With rising prices: LIFO has the highest COGS and lowest profit and inventory; FIFO the reverse; weighted average in between."},
],
},
{
"id": "lta",
"title": "Long-Lived Assets",
"body": r"""**Capitalize vs. expense.** Capitalizing an expenditure puts it on the balance sheet and spreads the cost over time through depreciation; expensing hits income immediately.

| Effect of capitalizing (vs. expensing) | Early years | Later years |
|---|---|---|
| Net income | Higher | Lower |
| Total assets and equity | Higher | Higher (declining) |
| CFO | **Higher** (spend is in CFI) | Higher |
| CFI | Lower | - |
| Profitability ratios (ROA, ROE) | Higher in year 1, lower thereafter | |
| Income variability | Lower | |

**Capitalized interest**: interest on borrowing to construct an asset for own use is capitalized into the asset's cost. It shifts the outflow from CFO to CFI and raises interest coverage in the construction period; analysts often reverse it.

**Depreciation methods.** Straight-line spreads (cost - residual) evenly. **Accelerated** methods (double-declining balance) charge more early, giving lower early income and asset values. DDB ignores residual value in the calculation but you stop depreciating once book value reaches residual value. Units-of-production ties depreciation to usage. IFRS requires **component depreciation** (significant parts depreciated separately).

**Amortization** of finite-lived intangibles follows the same logic; indefinite-lived intangibles (and goodwill) are not amortized but tested for impairment.

**Impairment.**

- **IFRS**: impaired when carrying amount exceeds the **recoverable amount** = higher of *fair value less costs to sell* and *value in use* (PV of future cash flows). Loss = carrying amount - recoverable amount. **Reversals allowed** (except goodwill).
- **US GAAP** (assets held for use): two steps. (1) *Recoverability*: impaired if carrying amount > **undiscounted** future cash flows. (2) Loss = carrying amount - fair value. **Reversals prohibited.**

Impairments are non-cash: they reduce assets and income but not CFO.

**Revaluation model** (IFRS only): PP&E and intangibles with an active market may be carried at fair value. Increases go to OCI (revaluation surplus) unless they reverse a prior loss recognized in profit; decreases go to profit unless they reverse a prior surplus. **Investment property** under IFRS can use the cost or fair value model (fair value changes go through profit).

**Derecognition.** On sale, gain or loss = proceeds - carrying amount.

**Analyzing fixed assets.** Average age $\approx$ accumulated depreciation / annual depreciation; remaining useful life $\approx$ net PP&E / annual depreciation; total useful life $\approx$ gross PP&E / annual depreciation. An old asset base may signal upcoming capital spending.""",
"formulas": [
{"name": "Straight-line depreciation", "tex": r"\text{Depreciation} = \frac{\text{Cost} - \text{Residual value}}{\text{Useful life}}", "vars": [], "note": ""},
{"name": "Double-declining balance", "tex": r"\text{Depreciation}_t = \frac{2}{\text{Useful life}} \times \text{Beginning book value}_t", "vars": [], "note": "Do not depreciate below residual value."},
{"name": "Asset age estimates", "tex": r"\begin{gathered}\text{Avg. age} \approx \frac{\text{Accum. dep.}}{\text{Dep. expense}} \qquad \text{Remaining life} \approx \frac{\text{Net PP\&E}}{\text{Dep. expense}} \\[4pt] \text{Total life} \approx \frac{\text{Gross PP\&E}}{\text{Dep. expense}}\end{gathered}", "vars": [], "note": ""},
],
"examples": [
{"title": "Straight-line vs. double-declining balance",
 "problem": "Equipment costs USD 100,000 with a residual value of USD 10,000 and a 5-year life. Compute depreciation for years 1 to 3 under both methods.",
 "steps": [r"Straight-line: $(100{,}000 - 10{,}000)/5 = 18{,}000$ per year.",
           r"DDB rate $= 2/5 = 40\%$. Year 1: $0.40 \times 100{,}000 = 40{,}000$. Year 2: $0.40 \times 60{,}000 = 24{,}000$. Year 3: $0.40 \times 36{,}000 = 14{,}400$.",
           "DDB gives much lower income in year 1, and higher income later."],
 "answer": "SL: 18,000/year. DDB: 40,000, 24,000, 14,400."},
{"title": "Impairment, IFRS vs. US GAAP",
 "problem": "An asset has carrying amount 500. Undiscounted future cash flows 520; value in use (discounted) 430; fair value 420; costs to sell 10. Is it impaired, and by how much?",
 "steps": [r"IFRS: recoverable amount $= \max(420 - 10,\ 430) = 430$. Loss $= 500 - 430 = 70$.",
           r"US GAAP: recoverability test: undiscounted CFs 520 > 500, so **not impaired**."],
 "answer": "IFRS: impairment of 70. US GAAP: no impairment. IFRS impairments tend to be recognized earlier."},
],
},
{
"id": "liabilities",
"title": "Long-Term Liabilities, Leases, Pensions and Taxes",
"body": r"""**Bonds.** A bond is recorded at issue at its **price** (PV of cash flows at the market rate). Under the **effective interest method** (required by IFRS, preferred by US GAAP), interest expense = carrying amount $\times$ market rate at issue. For a bond issued at a **discount** (coupon < market rate), interest expense exceeds the coupon paid, and the carrying amount rises toward par each year. For a premium bond the reverse holds. The coupon paid is a CFO outflow under US GAAP; the issue proceeds and principal repayment are CFF. Debt is **not** marked to market for changes in rates (unless the fair value option is elected).

**Debt covenants**: affirmative (must do: maintain ratios, provide statements) and negative (must not: limits on more debt, dividends, asset sales).

**Leases (lessee).** Under IFRS 16, almost all leases put a **right-of-use (ROU) asset and a lease liability** (PV of lease payments) on the balance sheet; the income statement shows depreciation of the ROU asset plus interest on the liability (front-loaded expense). US GAAP (ASC 842) also puts both on the balance sheet but distinguishes **finance leases** (same treatment as IFRS) from **operating leases** (a single straight-line lease expense). Cash flows: for finance leases, the principal portion is CFF; interest is CFO or CFF (IFRS) / CFO (US GAAP); operating lease payments under US GAAP are entirely CFO. Short-term (12 months or less) and, under IFRS, low-value leases may be expensed.

**Lessor.** A finance (sales-type) lease transfers substantially all risks and rewards: the lessor derecognizes the asset and records a lease receivable. An operating lease keeps the asset on the lessor's books with lease revenue recognized over time.

**Pensions.** In a **defined contribution** plan, the employer's expense equals its contribution; investment risk sits with the employee. In a **defined benefit** plan, the employer promises a benefit and bears investment risk; the balance sheet shows the **net pension liability (asset)** = present value of the defined benefit obligation - fair value of plan assets. Funded status deficit = liability.

**Share-based compensation** is expensed at grant-date fair value over the vesting (service) period.

**Income taxes.** Accounting profit and taxable income differ.

- **Temporary differences** reverse over time and create deferred taxes. If **carrying amount of an asset > its tax base** (e.g. tax depreciation faster than book), the firm will pay more tax later: a **deferred tax liability (DTL)**. If **carrying amount of an asset < tax base** (e.g. warranty expense accrued for books before it is deductible), the result is a **deferred tax asset (DTA)**.
- **Permanent differences** (e.g. tax-exempt income, non-deductible fines) never reverse; they create no deferred taxes and drive a gap between the **effective** and **statutory** tax rates.
- DTAs are reduced by a **valuation allowance** (US GAAP) if it is more likely than not they will not be realized; IFRS recognizes a DTA only to the extent realization is probable.
- If a DTL is not expected to reverse (e.g. a growing firm keeps buying assets), analysts may treat it as equity.
- **Income tax expense = taxes payable + $\Delta$DTL - $\Delta$DTA.**""",
"formulas": [
{"name": "Bond interest expense (effective interest method)", "tex": r"\text{Interest expense}_t = \text{Carrying amount}_{t-1} \times r_{market\ at\ issue}", "vars": [], "note": r"Carrying amount$_t$ = carrying amount$_{t-1}$ + interest expense - coupon paid."},
{"name": "Lease liability at inception", "tex": r"L_0 = \sum_{t=1}^{N}\frac{\text{Lease payment}_t}{(1+r)^t}", "vars": [["r", "rate implicit in the lease (or the lessee's incremental borrowing rate)"]], "note": ""},
{"name": "Income tax expense", "tex": r"\text{Tax expense} = \text{Taxes payable} + \Delta DTL - \Delta DTA", "vars": [], "note": ""},
{"name": "Deferred tax on a temporary difference", "tex": r"DTL\ (DTA) = (\text{Carrying amount} - \text{Tax base}) \times t", "vars": [["t", "enacted tax rate expected when the difference reverses"]], "note": "For an asset: positive difference = DTL. For a liability: positive difference = DTA."},
],
"examples": [
{"title": "Bond issued at a discount",
 "problem": "A company issues a 5-year, USD 1,000,000 bond with a 5% annual coupon when market rates are 6%. Find the issue price, year-1 interest expense and year-end carrying amount.",
 "steps": [r"Price: N = 5, I/Y = 6, PMT = 50,000, FV = 1,000,000: PV = 957,876.",
           r"Year-1 interest expense $= 957{,}876 \times 6\% = 57{,}473$; coupon paid $= 50{,}000$.",
           r"Discount amortization $= 7{,}473$; carrying amount $= 957{,}876 + 7{,}473 = 965{,}349$."],
 "answer": "Price 957,876; interest expense 57,473 (higher than the coupon); carrying amount rises to 965,349."},
{"title": "Lease accounting for the lessee",
 "problem": "A 5-year lease requires USD 10,000 at the end of each year; the discount rate is 6%. Compute the initial lease liability and year-1 expense under IFRS and under a US GAAP operating lease.",
 "steps": [r"Lease liability $= 10{,}000 \times 4.2124 = 42{,}124$ (also the ROU asset).",
           r"IFRS year 1: depreciation $= 42{,}124/5 = 8{,}425$; interest $= 6\% \times 42{,}124 = 2{,}527$; total $= 10{,}952$.",
           r"US GAAP operating lease: single straight-line lease expense of 10,000.",
           r"Cash flow (IFRS): 2,527 interest in CFO (or CFF) and 7,473 principal in CFF. US GAAP operating: 10,000 in CFO."],
 "answer": "Same balance sheet at inception; IFRS front-loads expense and reports higher CFO."},
{"title": "Deferred tax liability",
 "problem": "An asset costs 30,000. Book depreciation (straight-line, 3 years) is 10,000 in year 1; tax depreciation is 15,000. Tax rate 25%. Compute the year-1 deferred tax.",
 "steps": [r"Carrying amount $= 20{,}000$; tax base $= 15{,}000$.", r"Temporary difference $= 5{,}000$; asset carrying amount > tax base: DTL.", r"$DTL = 5{,}000 \times 25\% = 1{,}250$."],
 "answer": "A DTL of 1,250 that reverses as book depreciation catches up."},
],
},
{
"id": "ratios",
"title": "Financial Analysis Techniques, Reporting Quality and Modeling",
"body": r"""**Ratio categories.**

| Category | Key ratios | Read as |
|---|---|---|
| Activity | Inventory turnover, receivables turnover, payables turnover, total asset turnover, fixed asset turnover, working capital turnover | Efficiency of using assets |
| Liquidity | Current, quick (cash + short-term marketable investments + receivables) / CL, cash ratio, defensive interval, cash conversion cycle | Ability to meet short-term obligations |
| Solvency | Debt-to-assets, debt-to-capital, debt-to-equity, financial leverage (assets/equity), interest coverage (EBIT / interest), fixed charge coverage | Ability to meet long-term obligations |
| Profitability | Gross, operating, pre-tax and net margins; ROA, ROE, return on total capital | Returns on sales and on capital |
| Valuation | P/E, P/CF, P/S, P/B, dividend payout | Market pricing |

Ratios have to be compared with peers, history and the company's strategy; differences in accounting choices (LIFO vs. FIFO, operating leases, capitalization policy) must be adjusted for.

**DuPont analysis** decomposes ROE so you can see *why* it changed: a rise driven by leverage is lower quality than one driven by margins or turnover.

**Financial reporting quality.** A spectrum from high-quality reporting of sustainable earnings, down through biased accounting choices (aggressive or conservative), to non-compliant reporting and fictitious transactions. Conditions for misreporting form the **fraud triangle**: **motivation** (pressure), **opportunity** (weak controls) and **rationalization**. Warning signs: revenue growing faster than receivables collection (rising DSO), inventory growing faster than sales, CFO persistently below net income, frequent "non-recurring" charges, changes in auditors, aggressive capitalization, and boosted pension assumptions.

**Earnings quality** concerns persistence: *accrual-heavy* earnings are less persistent than cash-backed earnings. **Big bath** accounting takes excessive charges in a bad year to flatter future years; **cookie jar reserves** over-accrue in good years to release later.

**Financial statement modeling.** Revenue is forecast first (top-down from GDP and market share, bottom-up from units and prices, or a hybrid). Costs are modeled as fixed or variable relative to revenue; working capital from turnover ratios; capex relative to depreciation and growth. Consider **competitive factors** (Porter's five forces), **inflation and deflation** (ability to pass through costs), technology change, and behavioral biases in forecasting (overconfidence, illusion of control, conservatism, representativeness, confirmation bias). Scenario and sensitivity analysis complement a point forecast.""",
"formulas": [
{"name": "Three-step DuPont", "tex": r"ROE = \underbrace{\frac{NI}{\text{Sales}}}_{\text{net margin}} \times \underbrace{\frac{\text{Sales}}{\text{Avg. assets}}}_{\text{asset turnover}} \times \underbrace{\frac{\text{Avg. assets}}{\text{Avg. equity}}}_{\text{leverage}}", "vars": [], "note": ""},
{"name": "Five-step DuPont", "tex": r"ROE = \frac{NI}{EBT} \times \frac{EBT}{EBIT} \times \frac{EBIT}{\text{Sales}} \times \frac{\text{Sales}}{\text{Assets}} \times \frac{\text{Assets}}{\text{Equity}}",
 "vars": [["NI/EBT", "tax burden"], ["EBT/EBIT", "interest burden"], ["EBIT/Sales", "EBIT margin"]], "note": ""},
{"name": "Key liquidity and solvency ratios", "tex": r"\begin{gathered}\text{Current} = \frac{CA}{CL} \qquad \text{Quick} = \frac{\text{Cash} + \text{ST inv.} + \text{AR}}{CL} \quad \\[4pt] \text{Interest coverage} = \frac{EBIT}{\text{Interest}} \qquad \frac{D}{E} = \frac{\text{Total debt}}{\text{Total equity}}\end{gathered}", "vars": [], "note": ""},
{"name": "Activity ratios", "tex": r"\text{Receivables turnover} = \frac{\text{Revenue}}{\text{Avg. AR}} \quad DSO = \frac{365}{\text{Rec. turnover}} \quad \text{Payables turnover} = \frac{\text{Purchases}}{\text{Avg. AP}}", "vars": [], "note": ""},
],
"examples": [
{"title": "DuPont decomposition",
 "problem": "Net income 120, sales 1,200, average assets 1,000, average equity 400. Decompose ROE. Then suppose next year ROE is the same but leverage rose to 3.0x while asset turnover was unchanged. What happened to the margin?",
 "steps": [r"Net margin $= 120/1{,}200 = 10\%$; asset turnover $= 1.2$; leverage $= 2.5$.",
           r"$ROE = 10\% \times 1.2 \times 2.5 = 30\%$.",
           r"Next year: $30\% = m \times 1.2 \times 3.0$, so $m = 8.33\%$."],
 "answer": "ROE 30% both years, but the margin fell to 8.33% and was masked by higher leverage: lower-quality ROE."},
],
},
],
"pitfalls": [
"LIFO is not allowed under IFRS. Rising prices: LIFO means higher COGS, lower taxes, higher cash flow, lower inventory.",
"Inventory write-down reversals: allowed under IFRS, prohibited under US GAAP.",
"Capitalizing raises CFO (the outflow goes to CFI) and early-year income.",
"US GAAP impairment: undiscounted cash flows for the recoverability test; IFRS: recoverable amount, reversals allowed.",
"Discount bond: interest expense > coupon; carrying value rises to par.",
"IFRS lessee: depreciation + interest (front-loaded). US GAAP operating lease: single straight-line expense, all CFO.",
"Asset carrying amount > tax base = DTL. Permanent differences create no deferred taxes.",
"Policy changes: retrospective. Estimate changes: prospective.",
"Dividends paid: CFF under US GAAP; CFO or CFF under IFRS. Interest paid: CFO under US GAAP.",
"Only include options in diluted EPS if exercise price < average market price.",
],
"problems": [
{"id": "f1", "section": "framework", "level": 1,
 "q": "Under the IFRS Conceptual Framework, the two fundamental qualitative characteristics of useful financial information are:",
 "choices": {"A": "relevance and faithful representation.", "B": "comparability and verifiability.", "C": "timeliness and understandability."}, "answer": "A",
 "explanation": "The others are enhancing characteristics."},
{"id": "f2", "section": "framework", "level": 2,
 "q": "An online marketplace sells third-party goods for USD 100, keeps a USD 12 commission and remits the rest. If it acts as an agent, revenue reported per sale is:",
 "choices": {"A": "USD 100.", "B": "USD 88.", "C": "USD 12."}, "answer": "C",
 "explanation": "An agent reports revenue net: only its commission."},
{"id": "f3", "section": "framework", "level": 2,
 "q": "A company changes its estimate of an asset's useful life from 10 to 8 years. The change is applied:",
 "choices": {"A": "retrospectively, with prior years restated.", "B": "prospectively.", "C": "as a prior-period adjustment to retained earnings."}, "answer": "B",
 "explanation": "Changes in estimates are prospective; changes in accounting policies are retrospective."},
{"id": "f4", "section": "framework", "level": 2,
 "q": "Average share price is USD 40. Which options are dilutive under the treasury stock method?",
 "choices": {"A": "Options with an exercise price of USD 45.", "B": "Options with an exercise price of USD 35.", "C": "Both."}, "answer": "B",
 "explanation": "Only in-the-money options (exercise price below average price) increase the share count."},
{"id": "f5", "section": "framework", "level": 3,
 "q": "NI = USD 3,000,000; 1,500,000 shares; 100,000 convertible preferred shares paying USD 2 each convertible into 200,000 common shares. Diluted EPS is closest to:",
 "choices": {"A": "USD 1.76", "B": "USD 1.87", "C": "USD 2.00"}, "answer": "A",
 "explanation": r"Basic $= (3{,}000{,}000 - 200{,}000)/1{,}500{,}000 = 1.87$. If converted: $3{,}000{,}000/1{,}700{,}000 = 1.76$, which is lower, so it is dilutive."},
{"id": "f6", "section": "bs_cf", "level": 2,
 "q": "Net income is 800; depreciation 120; accounts receivable decreased 50; inventory increased 70; accounts payable decreased 30; loss on sale of equipment 20. CFO is closest to:",
 "choices": {"A": "890", "B": "850", "C": "930"}, "answer": "A",
 "explanation": r"$800 + 120 + 20 + 50 - 70 - 30 = 890$."},
{"id": "f7", "section": "bs_cf", "level": 2,
 "q": "Under US GAAP, dividends paid to shareholders are classified as:",
 "choices": {"A": "operating cash flow.", "B": "financing cash flow.", "C": "either operating or financing."}, "answer": "B",
 "explanation": "US GAAP: dividends paid are CFF. IFRS allows CFO or CFF."},
{"id": "f8", "section": "bs_cf", "level": 2,
 "q": "A debt security held in a business model whose objective is both to collect contractual cash flows and to sell is measured under IFRS 9 at:",
 "choices": {"A": "amortized cost.", "B": "fair value through OCI.", "C": "fair value through profit or loss."}, "answer": "B",
 "explanation": "Hold-to-collect-and-sell = FVOCI; unrealized gains and losses go to OCI."},
{"id": "f9", "section": "bs_cf", "level": 2,
 "q": "Revenue is 2,000, and accounts receivable increased by 150 while unearned revenue increased by 40. Cash collected from customers is:",
 "choices": {"A": "1,890", "B": "2,110", "C": "1,810"}, "answer": "A",
 "explanation": r"$2{,}000 - 150 + 40 = 1{,}890$."},
{"id": "f10", "section": "inventory", "level": 2,
 "q": "In a period of rising prices and stable inventory quantities, compared with FIFO, a firm using LIFO will report:",
 "choices": {"A": "higher gross margin.", "B": "higher operating cash flow.", "C": "higher current ratio."}, "answer": "B",
 "explanation": "Higher COGS means lower taxable income and taxes paid, so after-tax operating cash flow is higher."},
{"id": "f11", "section": "inventory", "level": 2,
 "q": "A LIFO firm reports COGS of 5,000; its LIFO reserve rose from 800 to 950. COGS on a FIFO basis is:",
 "choices": {"A": "4,850", "B": "5,150", "C": "4,050"}, "answer": "A",
 "explanation": r"$COGS_{FIFO} = COGS_{LIFO} - \Delta \text{reserve} = 5{,}000 - 150 = 4{,}850$."},
{"id": "f12", "section": "inventory", "level": 2,
 "q": "A declining LIFO reserve in a period of rising prices most likely indicates:",
 "choices": {"A": "a LIFO liquidation that has inflated gross profit.", "B": "the firm switched to FIFO.", "C": "an inventory write-down."}, "answer": "A",
 "explanation": "Selling old low-cost layers reduces COGS and boosts margins temporarily."},
{"id": "f13", "section": "inventory", "level": 1,
 "q": "Reversal of a previous inventory write-down is:",
 "choices": {"A": "permitted under both IFRS and US GAAP.", "B": "permitted under IFRS only.", "C": "prohibited under both."}, "answer": "B",
 "explanation": "IFRS permits reversals up to the original write-down; US GAAP prohibits them."},
{"id": "f14", "section": "lta", "level": 2,
 "q": "Compared with expensing, capitalizing a cost in the year it is incurred will most likely result in:",
 "choices": {"A": "lower cash flow from operations.", "B": "higher cash flow from operations.", "C": "no difference in cash flow from operations."}, "answer": "B",
 "explanation": "The capitalized outflow is reported in CFI rather than CFO."},
{"id": "f15", "section": "lta", "level": 2,
 "q": "Equipment costs 50,000, residual value 5,000, life 4 years. Second-year depreciation under double-declining balance is:",
 "choices": {"A": "12,500", "B": "11,250", "C": "25,000"}, "answer": "A",
 "explanation": r"Rate $= 50\%$. Year 1: 25,000 (book value 25,000). Year 2: $0.5 \times 25{,}000 = 12{,}500$. B is straight-line."},
{"id": "f16", "section": "lta", "level": 3,
 "q": "Under US GAAP, an asset with carrying value 800 has undiscounted future cash flows of 780 and a fair value of 700. The impairment loss is:",
 "choices": {"A": "0", "B": "20", "C": "100"}, "answer": "C",
 "explanation": "Recoverability fails (780 < 800), so the loss is measured to fair value: 800 - 700 = 100."},
{"id": "f17", "section": "lta", "level": 2,
 "q": "Accumulated depreciation is 300, gross PP&E is 900 and annual depreciation expense is 60. The estimated average age of the assets is:",
 "choices": {"A": "5 years", "B": "10 years", "C": "15 years"}, "answer": "A",
 "explanation": r"Average age $= 300/60 = 5$. Remaining life $= 600/60 = 10$; total life $= 900/60 = 15$."},
{"id": "f18", "section": "liabilities", "level": 2,
 "q": "For a bond issued at a premium, over time the interest expense under the effective interest method will:",
 "choices": {"A": "be less than the coupon payment and decline.", "B": "be greater than the coupon payment and rise.", "C": "equal the coupon payment."}, "answer": "A",
 "explanation": "Premium bond: market rate < coupon, so expense < coupon; the carrying amount falls toward par, so expense falls too."},
{"id": "f19", "section": "liabilities", "level": 2,
 "q": "For a lessee, compared with a US GAAP operating lease, an IFRS 16 lease with the same terms will most likely report in the early years:",
 "choices": {"A": "higher total expense and higher CFO.", "B": "lower total expense and lower CFO.", "C": "the same expense and the same CFO."}, "answer": "A",
 "explanation": "IFRS expense (depreciation + interest) is front-loaded; part of the payment (principal) moves to CFF, raising CFO."},
{"id": "f20", "section": "liabilities", "level": 2,
 "q": "A company accrues warranty expense for financial reporting but deducts it for taxes only when paid. This creates a:",
 "choices": {"A": "deferred tax liability.", "B": "deferred tax asset.", "C": "permanent difference."}, "answer": "B",
 "explanation": "Taxes are paid now on income that the books have already reduced; future deductions will reduce taxes: DTA."},
{"id": "f21", "section": "liabilities", "level": 2,
 "q": "Taxes payable are 400, the DTL increased by 50 and the DTA increased by 20. Income tax expense is:",
 "choices": {"A": "430", "B": "470", "C": "370"}, "answer": "A",
 "explanation": r"$400 + 50 - 20 = 430$."},
{"id": "f22", "section": "liabilities", "level": 2,
 "q": "The funded status of a defined benefit pension plan is the:",
 "choices": {"A": "plan assets minus the present value of the defined benefit obligation.", "B": "employer contributions minus benefits paid.", "C": "service cost plus interest cost."}, "answer": "A",
 "explanation": "A negative funded status is reported as a net pension liability."},
{"id": "f23", "section": "ratios", "level": 2,
 "q": "Tax burden 0.75, interest burden 0.80, EBIT margin 12%, asset turnover 1.5, leverage 2.0. ROE is closest to:",
 "choices": {"A": "10.8%", "B": "21.6%", "C": "18.0%"}, "answer": "B",
 "explanation": r"$0.75 \times 0.80 \times 0.12 \times 1.5 \times 2.0 = 0.216$."},
{"id": "f24", "section": "ratios", "level": 2,
 "q": "A company's revenue rose 10% while its DSO rose from 45 to 70 days. The most likely concern is:",
 "choices": {"A": "aggressive revenue recognition.", "B": "excessive inventory.", "C": "conservative accounting."}, "answer": "A",
 "explanation": "Receivables growing much faster than revenue can signal recognizing sales that may not be collected."},
{"id": "f25", "section": "ratios", "level": 1,
 "q": "In the fraud triangle, weak internal controls represent:",
 "choices": {"A": "motivation.", "B": "opportunity.", "C": "rationalization."}, "answer": "B",
 "explanation": "Weak controls give the opportunity to misreport."},
{"id": "f26", "section": "ratios", "level": 2,
 "q": "Current assets: cash 50, marketable securities 30, receivables 120, inventory 200. Current liabilities 250. The quick ratio is:",
 "choices": {"A": "0.80", "B": "1.60", "C": "0.32"}, "answer": "A",
 "explanation": r"$(50 + 30 + 120)/250 = 0.80$. The current ratio is $400/250 = 1.60$."},
],
}

"""Single content source for the CFA Level I study guide (PDF) and practice app (Dash).

Text fields use a small Markdown dialect that both renderers understand:
  * blank line = new paragraph
  * lines starting with "- " = bullets, "1. " = numbered list
  * **bold**, *italic*
  * $inline math$ and $$display math$$ (display math on its own line)
  * pipe tables:  | a | b |  (first row is the header, second row is |---|---|)
Currency is written as "USD 100" so that "$" is always math.
"""
from . import (ethics, quant, economics, fsa, corporate, equity,
               fixed_income, derivatives, alternatives, portfolio)

TOPICS = [ethics.TOPIC, quant.TOPIC, economics.TOPIC, corporate.TOPIC,
          fsa.TOPIC, equity.TOPIC, fixed_income.TOPIC, derivatives.TOPIC,
          alternatives.TOPIC, portfolio.TOPIC]

TOPIC_BY_ID = {t["id"]: t for t in TOPICS}


def all_problems():
    for t in TOPICS:
        for p in t["problems"]:
            yield t, p

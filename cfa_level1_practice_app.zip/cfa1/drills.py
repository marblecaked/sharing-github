"""Randomized calculation drills with step-by-step solutions.

Each generator takes a random.Random and returns a dict:
  topic, title, question (markdown with $math$), answer (float), unit, tol (abs), steps [markdown]
Units: "%" answers are entered in percent (5.25 means 5.25%).
"""
import math
import random

DRILLS = {}


def drill(topic, title):
    def deco(fn):
        DRILLS[fn.__name__] = {"topic": topic, "title": title, "fn": fn}
        return fn
    return deco


def f(x, d=2):
    """Format a number with thousands separators."""
    return f"{x:,.{d}f}"


def fm(x, d=2):
    """Format for use inside math mode (escape thousands commas)."""
    return f"{x:,.{d}f}".replace(",", "{,}")


def pv_annuity(pmt, r, n):
    return pmt * (1 - (1 + r) ** -n) / r


def bond_price(c, y, n, m=1, face=100.0):
    cp, yy, N = c * face / m, y / m, n * m
    return sum(cp / (1 + yy) ** t for t in range(1, N + 1)) + face / (1 + yy) ** N


def result(topic, title, q, ans, unit, steps, tol=None):
    if tol is None:
        tol = max(abs(ans) * 0.003, 0.01 if unit in ("%", "x", "") else 0.5)
    return {"topic": topic, "title": title, "question": q, "answer": ans,
            "unit": unit, "tol": tol, "steps": steps}


# ---------------------------------------------------------------- Quant
@drill("quant", "Present value of an annuity")
def annuity_pv(rng):
    pmt = rng.choice([500, 1000, 2500, 5000, 10000, 25000])
    r = rng.choice([3, 4, 5, 6, 7, 8, 9]) / 100
    n = rng.randint(5, 30)
    due = rng.random() < 0.4
    pv = pv_annuity(pmt, r, n) * ((1 + r) if due else 1)
    timing = "at the **beginning** of each year (annuity due)" if due else "at the **end** of each year"
    q = (f"What is the present value of USD {f(pmt,0)} per year for {n} years, paid {timing}, "
         f"at a discount rate of {r*100:.0f}%? Answer in USD.")
    steps = [f"Ordinary annuity factor: $\\dfrac{{1 - (1+r)^{{-N}}}}{{r}} = \\dfrac{{1 - {1+r:.2f}^{{-{n}}}}}{{{r:.2f}}} = {pv_annuity(1, r, n):.4f}$.",
             f"$PV_{{ordinary}} = {fm(pmt,0)} \\times {pv_annuity(1, r, n):.4f} = {fm(pv_annuity(pmt, r, n))}$."]
    if due:
        steps.append(f"Annuity due: multiply by $(1+r)$: ${fm(pv_annuity(pmt, r, n))} \\times {1+r:.2f} = {fm(pv)}$.")
    steps.append(f"Calculator: {'BGN mode, ' if due else ''}N = {n}, I/Y = {r*100:.0f}, PMT = {pmt}, FV = 0, CPT PV.")
    return result("quant", "Present value of an annuity", q, pv, "USD", steps)


@drill("quant", "Loan payment and EAR")
def loan_payment(rng):
    P = rng.choice([150000, 250000, 300000, 400000, 500000])
    rs = rng.choice([4.5, 5.0, 5.5, 6.0, 6.5, 7.0]) / 100
    yrs = rng.choice([15, 20, 25, 30])
    r, n = rs / 12, yrs * 12
    pmt = P * r / (1 - (1 + r) ** -n)
    q = (f"A USD {f(P,0)} loan is repaid monthly over {yrs} years at a stated annual rate of {rs*100:.1f}% "
         f"compounded monthly. What is the monthly payment in USD?")
    steps = [f"Periodic rate $= {rs*100:.1f}\\%/12 = {r*100:.4f}\\%$; $N = {yrs} \\times 12 = {n}$.",
             f"$PMT = \\dfrac{{PV \\times r}}{{1 - (1+r)^{{-N}}}} = \\dfrac{{{fm(P,0)} \\times {r:.6f}}}{{1 - (1+{r:.6f})^{{-{n}}}}} = {fm(pmt)}$.",
             f"For reference, EAR $= (1 + {r:.6f})^{{12}} - 1 = {((1+r)**12-1)*100:.3f}\\%$."]
    return result("quant", "Loan payment and EAR", q, pmt, "USD", steps)


@drill("quant", "Effective annual rate")
def ear(rng):
    rs = rng.choice([4, 5, 6, 8, 10, 12]) / 100
    m, label = rng.choice([(2, "semiannually"), (4, "quarterly"), (12, "monthly"), (365, "daily"), (None, "continuously")])
    if m is None:
        e = math.exp(rs) - 1
        steps = [f"Continuous compounding: $EAR = e^{{r_s}} - 1 = e^{{{rs:.2f}}} - 1 = {e*100:.4f}\\%$."]
    else:
        e = (1 + rs / m) ** m - 1
        steps = [f"$EAR = \\left(1 + \\dfrac{{{rs:.2f}}}{{{m}}}\\right)^{{{m}}} - 1 = {e*100:.4f}\\%$."]
    q = f"A stated annual rate of {rs*100:.0f}% is compounded {label}. What is the effective annual rate (in %)?"
    return result("quant", "Effective annual rate", q, e * 100, "%", steps, tol=0.005)


@drill("quant", "Geometric vs. arithmetic mean")
def geo_mean(rng):
    rets = [rng.choice([-25, -15, -10, -5, -2, 3, 6, 8, 12, 15, 20, 30]) for _ in range(rng.randint(3, 5))]
    prod = 1.0
    for x in rets:
        prod *= 1 + x / 100
    g = prod ** (1 / len(rets)) - 1
    a = sum(rets) / len(rets)
    rl = ", ".join(f"{x:+d}%" for x in rets)
    q = f"Annual returns were {rl}. What is the geometric mean annual return (in %)?"
    terms = " \\times ".join(f"{1+x/100:.2f}" for x in rets)
    steps = [f"Product of growth factors: ${terms} = {prod:.6f}$.",
             f"Geometric mean $= {prod:.6f}^{{1/{len(rets)}}} - 1 = {g*100:.3f}\\%$.",
             f"Compare: the arithmetic mean is ${a:.3f}\\%$, which is higher because returns vary."]
    return result("quant", "Geometric vs. arithmetic mean", q, g * 100, "%", steps, tol=0.01)


@drill("quant", "Two-asset portfolio risk")
def port_sd(rng):
    w = rng.choice([0.3, 0.4, 0.5, 0.6, 0.7])
    s1 = rng.choice([15, 18, 20, 25, 30]) / 100
    s2 = rng.choice([5, 8, 10, 12]) / 100
    rho = rng.choice([-0.5, -0.2, 0.0, 0.2, 0.3, 0.5, 0.8])
    var = w**2 * s1**2 + (1 - w)**2 * s2**2 + 2 * w * (1 - w) * rho * s1 * s2
    sd = math.sqrt(var)
    q = (f"A portfolio holds {w*100:.0f}% in Asset 1 ($\\sigma$ = {s1*100:.0f}%) and {(1-w)*100:.0f}% in Asset 2 "
         f"($\\sigma$ = {s2*100:.0f}%). The correlation is {rho:.1f}. What is the portfolio standard deviation (in %)?")
    steps = [f"$w_1^2\\sigma_1^2 = {w:.1f}^2 \\times {s1:.2f}^2 = {w**2*s1**2:.6f}$",
             f"$w_2^2\\sigma_2^2 = {1-w:.1f}^2 \\times {s2:.2f}^2 = {(1-w)**2*s2**2:.6f}$",
             f"$2w_1w_2\\rho\\sigma_1\\sigma_2 = 2({w:.1f})({1-w:.1f})({rho:.1f})({s1:.2f})({s2:.2f}) = {2*w*(1-w)*rho*s1*s2:.6f}$",
             f"$\\sigma_p^2 = {var:.6f}$, so $\\sigma_p = {sd*100:.3f}\\%$.",
             f"Weighted average of sigmas would be {(w*s1+(1-w)*s2)*100:.2f}%: the gap is the diversification benefit."]
    return result("quant", "Two-asset portfolio risk", q, sd * 100, "%", steps, tol=0.01)


@drill("quant", "Bayes' formula")
def bayes(rng):
    prior = rng.choice([1, 2, 5, 10, 20]) / 100
    tp = rng.choice([80, 85, 90, 95]) / 100
    fp = rng.choice([5, 10, 15, 20]) / 100
    post = prior * tp / (prior * tp + (1 - prior) * fp)
    q = (f"{prior*100:.0f}% of companies in a sample will cut their dividend. A screen flags {tp*100:.0f}% of companies "
         f"that will cut, and {fp*100:.0f}% of companies that will not. A company is flagged. What is the probability "
         f"(in %) that it will cut its dividend?")
    a = 10000 * prior * tp
    b = 10000 * (1 - prior) * fp
    steps = [f"Imagine 10,000 companies: {10000*prior:,.0f} will cut, {10000*(1-prior):,.0f} will not.",
             f"Flagged cutters: ${tp:.2f} \\times {fm(10000*prior,0)} = {fm(a,0)}$. Flagged non-cutters: ${fp:.2f} \\times {fm(10000*(1-prior),0)} = {fm(b,0)}$.",
             f"$P(\\text{{cut}} \\mid \\text{{flag}}) = {fm(a,0)}/({fm(a,0)} + {fm(b,0)}) = {post*100:.2f}\\%$."]
    return result("quant", "Bayes' formula", q, post * 100, "%", steps, tol=0.05)


@drill("quant", "t-statistic for a mean")
def tstat(rng):
    n = rng.choice([16, 25, 36, 49, 64, 100])
    s = rng.choice([2, 3, 4, 5, 6])
    xbar = rng.choice([0.4, 0.6, 0.8, 1.0, 1.2, 1.5])
    t = xbar / (s / math.sqrt(n))
    q = (f"A sample of {n} monthly returns has a mean of {xbar}% and a standard deviation of {s}%. "
         f"What is the t-statistic for testing $H_0: \\mu = 0$?")
    steps = [f"Standard error $= s/\\sqrt n = {s}/\\sqrt{{{n}}} = {s/math.sqrt(n):.4f}\\%$.",
             f"$t = ({xbar} - 0)/{s/math.sqrt(n):.4f} = {t:.4f}$ with {n-1} degrees of freedom.",
             f"Compare with the two-tailed 5% critical value (about {2.13 if n == 16 else 2.06 if n == 25 else 2.03 if n == 36 else 2.01 if n == 49 else 2.00 if n == 64 else 1.98}): "
             f"{'reject' if abs(t) > (2.13 if n == 16 else 2.06 if n == 25 else 2.03 if n == 36 else 2.01 if n == 49 else 2.00 if n == 64 else 1.98) else 'fail to reject'} $H_0$."]
    return result("quant", "t-statistic for a mean", q, t, "", steps, tol=0.01)


# ---------------------------------------------------------------- Economics
@drill("econ", "Forward exchange rate")
def fx_forward(rng):
    pairs = [("USD", "EUR", 1.0500, 1.1500), ("JPY", "USD", 140.0, 160.0), ("CAD", "USD", 1.30, 1.40),
             ("USD", "GBP", 1.20, 1.35), ("MXN", "USD", 16.5, 19.5)]
    p, b, lo, hi = rng.choice(pairs)
    S = round(rng.uniform(lo, hi), 2 if lo > 10 else 4)
    ip = rng.choice([1, 2, 3, 4, 5, 6, 8, 10]) / 100
    ib = rng.choice([1, 2, 3, 4, 5, 6]) / 100
    days = rng.choice([90, 180, 270, 360])
    F = S * (1 + ip * days / 360) / (1 + ib * days / 360)
    dp = 2 if S > 10 else 4
    q = (f"Spot {p}/{b} = {S:.{dp}f}. The {days}-day {p} rate is {ip*100:.0f}% and the {b} rate is {ib*100:.0f}% "
         f"(actual/360). What is the {days}-day forward {p}/{b} rate?")
    steps = [f"{b} is the base currency, {p} the price currency: price-currency rate on top.",
             f"$F = {S:.{dp}f} \\times \\dfrac{{1 + {ip:.2f}({days}/360)}}{{1 + {ib:.2f}({days}/360)}} = {S:.{dp}f} \\times \\dfrac{{{1+ip*days/360:.4f}}}{{{1+ib*days/360:.4f}}} = {F:.{dp+1}f}$.",
             ("Interest rates are equal, so the forward equals spot." if ip == ib else
              f"The {'base' if F > S else 'price'} currency ({b if F > S else p}) has the lower interest rate and trades at a forward premium.")]
    return result("econ", "Forward exchange rate", q, F, "", steps, tol=0.0006 if S < 10 else 0.06)


@drill("econ", "Fiscal multiplier")
def fiscal(rng):
    mpc = rng.choice([0.6, 0.7, 0.75, 0.8, 0.85, 0.9])
    t = rng.choice([0.1, 0.15, 0.2, 0.25, 0.3])
    g = rng.choice([50, 100, 200, 250])
    mult = 1 / (1 - mpc * (1 - t))
    q = (f"The marginal propensity to consume is {mpc} and the tax rate is {t*100:.0f}%. By how much (USD billions) "
         f"does GDP rise if government spending increases by USD {g} billion?")
    steps = [f"$MPC(1-t) = {mpc} \\times {1-t:.2f} = {mpc*(1-t):.4f}$.",
             f"Multiplier $= 1/(1 - {mpc*(1-t):.4f}) = {mult:.4f}$.",
             f"$\\Delta GDP = {mult:.4f} \\times {g} = {mult*g:.2f}$."]
    return result("econ", "Fiscal multiplier", q, mult * g, "USD bn", steps, tol=0.5)


# ---------------------------------------------------------------- Corporate
@drill("corp", "Net present value")
def npv(rng):
    c0 = rng.choice([1000, 2000, 5000, 10000])
    n = rng.randint(3, 5)
    cfs = [round(c0 * rng.uniform(0.2, 0.45), -1) for _ in range(n)]
    r = rng.choice([6, 8, 10, 12, 14]) / 100
    pvs = [c / (1 + r) ** (i + 1) for i, c in enumerate(cfs)]
    v = sum(pvs) - c0
    q = (f"A project costs USD {f(c0,0)} today and returns " + ", ".join(f"USD {f(c,0)}" for c in cfs) +
         f" at the end of years 1 to {n}. The required return is {r*100:.0f}%. What is the NPV in USD?")
    steps = [" + ".join(f"${fm(c,0)}/{1+r:.2f}^{i+1} = {fm(p)}$" for i, (c, p) in enumerate(zip(cfs, pvs))),
             f"Sum of PVs $= {fm(sum(pvs))}$; $NPV = {fm(sum(pvs))} - {fm(c0,0)} = {fm(v)}$.",
             f"Decision: {'accept (NPV > 0)' if v > 0 else 'reject (NPV < 0)'}."]
    return result("corp", "Net present value", q, v, "USD", steps, tol=max(0.5, abs(v) * 0.002))


@drill("corp", "WACC")
def wacc(rng):
    wd = rng.choice([0.2, 0.3, 0.4, 0.5])
    rd = rng.choice([4, 5, 6, 7, 8]) / 100
    t = rng.choice([0.21, 0.25, 0.3])
    rf = rng.choice([2.5, 3, 3.5, 4]) / 100
    beta = rng.choice([0.8, 0.9, 1.0, 1.1, 1.2, 1.4])
    mrp = rng.choice([5, 5.5, 6, 6.5]) / 100
    re = rf + beta * mrp
    w = wd * rd * (1 - t) + (1 - wd) * re
    q = (f"Target capital structure: {wd*100:.0f}% debt, {(1-wd)*100:.0f}% equity. Pre-tax cost of debt {rd*100:.0f}%, "
         f"tax rate {t*100:.0f}%. Risk-free rate {rf*100:.1f}%, equity beta {beta}, market risk premium {mrp*100:.1f}%. "
         f"What is the WACC (in %)?")
    steps = [f"$r_e = {rf*100:.1f}\\% + {beta}({mrp*100:.1f}\\%) = {re*100:.3f}\\%$.",
             f"After-tax $r_d = {rd*100:.0f}\\%(1 - {t:.2f}) = {rd*(1-t)*100:.3f}\\%$.",
             f"$WACC = {wd:.1f}({rd*(1-t)*100:.3f}\\%) + {1-wd:.1f}({re*100:.3f}\\%) = {w*100:.3f}\\%$."]
    return result("corp", "WACC", q, w * 100, "%", steps, tol=0.01)


@drill("corp", "Cost of trade credit")
def trade_credit(rng):
    disc = rng.choice([1, 1.5, 2, 3])
    dp = rng.choice([10, 15])
    net = rng.choice([30, 45, 60])
    c = (1 + disc / (100 - disc)) ** (365 / (net - dp)) - 1
    q = f"A supplier offers terms of {disc:g}/{dp} net {net}. What is the annualized cost of forgoing the discount (in %)?"
    steps = [f"Periodic cost $= {disc:g}/{100-disc:g} = {disc/(100-disc)*100:.4f}\\%$ for {net-dp} days.",
             f"Annualize: $(1 + {disc/(100-disc):.6f})^{{365/{net-dp}}} - 1 = {c*100:.3f}\\%$."]
    return result("corp", "Cost of trade credit", q, c * 100, "%", steps, tol=0.02)


# ---------------------------------------------------------------- FSA
@drill("fsa", "Inventory: FIFO vs. LIFO COGS")
def inventory(rng):
    b_u, b_c = rng.choice([100, 200, 300]), rng.choice([8, 10, 12])
    p1_u, p1_c = rng.choice([200, 300, 400]), b_c + rng.choice([1, 2, 3])
    p2_u, p2_c = rng.choice([100, 200, 300]), p1_c + rng.choice([1, 2, 3])
    total = b_u + p1_u + p2_u
    sold = rng.choice([x for x in range(b_u + 50, total - 49, 50)])
    method = rng.choice(["FIFO", "LIFO"])
    layers = [(b_u, b_c), (p1_u, p1_c), (p2_u, p2_c)]
    order = layers if method == "FIFO" else layers[::-1]
    rem, cogs, parts = sold, 0, []
    for u, c in order:
        take = min(u, rem)
        if take > 0:
            cogs += take * c
            parts.append(f"{take} \\times {c}")
            rem -= take
    q = (f"Beginning inventory: {b_u} units at USD {b_c}. Purchases: {p1_u} units at USD {p1_c}, then {p2_u} units at "
         f"USD {p2_c}. {sold} units are sold (periodic system). What is COGS under **{method}** in USD?")
    steps = [f"{method} takes the {'oldest' if method == 'FIFO' else 'newest'} layers first.",
             f"$COGS = {' + '.join(parts)} = {fm(cogs,0)}$.",
             f"Goods available cost ${fm(sum(u*c for u,c in layers),0)}$, so ending inventory $= {fm(sum(u*c for u,c in layers)-cogs,0)}$."]
    return result("fsa", "Inventory: FIFO vs. LIFO COGS", q, cogs, "USD", steps, tol=0.5)


@drill("fsa", "DuPont ROE")
def dupont(rng):
    tb = rng.choice([0.70, 0.75, 0.79, 0.8])
    ib = rng.choice([0.80, 0.85, 0.90, 0.95])
    em = rng.choice([8, 10, 12, 15]) / 100
    at = rng.choice([0.8, 1.0, 1.2, 1.5])
    lev = rng.choice([1.5, 2.0, 2.5, 3.0])
    roe = tb * ib * em * at * lev
    q = (f"Tax burden {tb:.2f}, interest burden {ib:.2f}, EBIT margin {em*100:.0f}%, asset turnover {at:.1f}x, "
         f"financial leverage {lev:.1f}x. What is ROE (in %)?")
    steps = [f"$ROE = {tb:.2f} \\times {ib:.2f} \\times {em:.2f} \\times {at:.1f} \\times {lev:.1f} = {roe*100:.3f}\\%$.",
             f"Net margin $= {tb:.2f} \\times {ib:.2f} \\times {em:.2f} = {tb*ib*em*100:.3f}\\%$; ROA $= {tb*ib*em*at*100:.3f}\\%$."]
    return result("fsa", "DuPont ROE", q, roe * 100, "%", steps, tol=0.01)


@drill("fsa", "Diluted EPS (treasury stock method)")
def diluted_eps(rng):
    ni = rng.choice([2, 3, 5, 8]) * 1e6
    pref = rng.choice([0, 0.2, 0.5]) * 1e6
    sh = rng.choice([1, 2, 4]) * 1e6
    opts = rng.choice([100, 200, 300]) * 1e3
    x = rng.choice([20, 25, 30])
    p = x + rng.choice([-5, 5, 10, 15])
    basic = (ni - pref) / sh
    new = opts - opts * x / p if p > x else 0
    dil = (ni - pref) / (sh + new)
    q = (f"Net income USD {f(ni,0)}; preferred dividends USD {f(pref,0)}; weighted average shares {f(sh,0)}. "
         f"There are {f(opts,0)} options with an exercise price of USD {x}; the average share price was USD {p}. "
         f"What is diluted EPS in USD?")
    steps = [f"Basic EPS $= ({fm(ni,0)} - {fm(pref,0)})/{fm(sh,0)} = {basic:.4f}$."]
    if p > x:
        steps += [f"Options are in the money ({x} < {p}). Proceeds ${fm(opts*x,0)}$ buy back ${fm(opts*x/p,0)}$ shares at {p}.",
                  f"Net new shares $= {fm(opts,0)} - {fm(opts*x/p,0)} = {fm(new,0)}$.",
                  f"Diluted EPS $= {fm(ni-pref,0)}/{fm(sh+new,0)} = {dil:.4f}$."]
    else:
        steps += [f"Exercise price {x} exceeds the average price {p}: the options are anti-dilutive and excluded.",
                  f"Diluted EPS = basic EPS = {dil:.4f}."]
    return result("fsa", "Diluted EPS (treasury stock method)", q, dil, "USD", steps, tol=0.005)


@drill("fsa", "CFO by the indirect method")
def cfo(rng):
    ni = rng.choice([300, 500, 800, 1200])
    dep = rng.choice([50, 80, 120, 150])
    dar = rng.choice([-40, -20, 20, 40, 60])
    dinv = rng.choice([-30, -10, 10, 30, 50])
    dap = rng.choice([-25, -15, 15, 25])
    gain = rng.choice([0, 10, 20, -15])
    c = ni + dep - gain - dar - dinv + dap
    gl = "gain" if gain > 0 else "loss"
    q = (f"Net income {ni}; depreciation {dep}; accounts receivable {'increased' if dar > 0 else 'decreased'} by {abs(dar)}; "
         f"inventory {'increased' if dinv > 0 else 'decreased'} by {abs(dinv)}; accounts payable "
         f"{'increased' if dap > 0 else 'decreased'} by {abs(dap)}" + (f"; {gl} on sale of equipment {abs(gain)}" if gain else "") +
         ". What is cash flow from operations?")
    steps = [f"Start with NI + depreciation: ${ni} + {dep} = {ni+dep}$."]
    if gain:
        steps.append(f"{'Subtract the gain' if gain > 0 else 'Add back the loss'} (the sale is investing): ${ni+dep} {'-' if gain>0 else '+'} {abs(gain)} = {ni+dep-gain}$.")
    steps.append(f"Working capital: AR {'up: subtract' if dar>0 else 'down: add'} {abs(dar)}; inventory {'up: subtract' if dinv>0 else 'down: add'} {abs(dinv)}; AP {'up: add' if dap>0 else 'down: subtract'} {abs(dap)}.")
    steps.append(f"$CFO = {c}$.")
    return result("fsa", "CFO by the indirect method", q, c, "", steps, tol=0.5)


# ---------------------------------------------------------------- Equity
@drill("equity", "Gordon growth model")
def gordon(rng):
    d0 = rng.choice([1.0, 1.5, 2.0, 2.5, 3.0])
    g = rng.choice([2, 3, 4, 5, 6]) / 100
    r = g + rng.choice([3, 4, 5, 6]) / 100
    v = d0 * (1 + g) / (r - g)
    q = f"A stock just paid a dividend of USD {d0:.2f}. Dividends grow at {g*100:.0f}% forever; the required return is {r*100:.0f}%. What is its value in USD?"
    steps = [f"$D_1 = {d0:.2f} \\times {1+g:.2f} = {d0*(1+g):.4f}$ (use next year's dividend).",
             f"$V_0 = {d0*(1+g):.4f}/({r:.2f} - {g:.2f}) = {v:.2f}$."]
    return result("equity", "Gordon growth model", q, v, "USD", steps, tol=0.02)


@drill("equity", "Two-stage dividend discount model")
def two_stage(rng):
    d0 = rng.choice([0.8, 1.0, 1.5, 2.0])
    gh = rng.choice([10, 15, 20, 25]) / 100
    n = rng.choice([2, 3, 4])
    gl = rng.choice([3, 4, 5]) / 100
    r = rng.choice([9, 10, 11, 12]) / 100
    ds = [d0 * (1 + gh) ** t for t in range(1, n + 1)]
    tv = ds[-1] * (1 + gl) / (r - gl)
    pv = sum(d / (1 + r) ** (i + 1) for i, d in enumerate(ds)) + tv / (1 + r) ** n
    q = (f"D0 = USD {d0:.2f}. Dividends grow at {gh*100:.0f}% for {n} years, then {gl*100:.0f}% forever. "
         f"The required return is {r*100:.0f}%. What is the share's value in USD?")
    steps = ["High-growth dividends: " + ", ".join(f"$D_{i+1} = {d:.4f}$" for i, d in enumerate(ds)) + ".",
             f"Terminal value at t = {n}: $V_{n} = D_{n}(1+g_L)/(r - g_L) = {ds[-1]:.4f}({1+gl:.2f})/({r:.2f} - {gl:.2f}) = {tv:.4f}$.",
             "PVs: " + "; ".join(f"${d:.4f}/{1+r:.2f}^{i+1} = {d/(1+r)**(i+1):.4f}$" for i, d in enumerate(ds)) +
             f"; terminal ${tv:.4f}/{1+r:.2f}^{n} = {tv/(1+r)**n:.4f}$.",
             f"$V_0 = {pv:.2f}$."]
    return result("equity", "Two-stage dividend discount model", q, pv, "USD", steps, tol=0.03)


@drill("equity", "Margin call price")
def margin(rng):
    p0 = rng.choice([25, 40, 50, 60, 80, 100])
    im = rng.choice([40, 50, 60]) / 100
    mm = rng.choice([25, 30, 35]) / 100
    pc = p0 * (1 - im) / (1 - mm)
    q = f"An investor buys a stock at USD {p0} with {im*100:.0f}% initial margin. The maintenance margin is {mm*100:.0f}%. Below what price (USD) will she receive a margin call?"
    steps = [f"Borrowed per share $= {p0} \\times {1-im:.2f} = {p0*(1-im):.2f}$.",
             f"Margin call when equity/value $= {mm:.2f}$: $(P - {p0*(1-im):.2f})/P = {mm:.2f}$.",
             f"$P^* = {p0} \\times {1-im:.2f}/{1-mm:.2f} = {pc:.2f}$."]
    return result("equity", "Margin call price", q, pc, "USD", steps, tol=0.02)


@drill("equity", "Index returns by weighting method")
def index_ret(rng):
    names = ["A", "B", "C"]
    p0 = [rng.choice([10, 20, 30, 40]), rng.choice([50, 60, 75]), rng.choice([90, 100, 120])]
    p1 = [round(p * (1 + rng.choice([-0.1, -0.05, 0.05, 0.1, 0.15])), 2) for p in p0]
    sh = [rng.choice([100, 200, 500]), rng.choice([50, 100, 200]), rng.choice([20, 40, 60])]
    kind = rng.choice(["price-weighted", "market-cap weighted", "equal-weighted"])
    if kind == "price-weighted":
        r = sum(p1) / sum(p0) - 1
        steps = [f"Sum of prices: ${' + '.join(map(str, p0))} = {sum(p0):.2f}$ to ${' + '.join(f'{x:.2f}' for x in p1)} = {sum(p1):.2f}$.",
                 f"Return $= {sum(p1):.2f}/{sum(p0):.2f} - 1 = {r*100:.3f}\\%$."]
    elif kind == "market-cap weighted":
        m0 = sum(a * b for a, b in zip(p0, sh)); m1 = sum(a * b for a, b in zip(p1, sh))
        r = m1 / m0 - 1
        steps = [f"Beginning market value $= {fm(m0)}$; ending $= {fm(m1)}$.", f"Return $= {r*100:.3f}\\%$."]
    else:
        rs = [b / a - 1 for a, b in zip(p0, p1)]
        r = sum(rs) / 3
        steps = ["Individual returns: " + ", ".join(f"{n}: {x*100:.2f}%" for n, x in zip(names, rs)) + ".",
                 f"Equal-weighted return $= {r*100:.3f}\\%$."]
    rows = "\n".join(f"| {n} | {a} | {b:.2f} | {s} |" for n, a, b, s in zip(names, p0, p1, sh))
    q = (f"Compute the **{kind}** index return (in %).\n\n| Stock | Beginning price | Ending price | Shares |\n|---|---|---|---|\n{rows}")
    return result("equity", "Index returns by weighting method", q, r * 100, "%", steps, tol=0.01)


# ---------------------------------------------------------------- Fixed income
@drill("fi", "Bond price from YTM")
def bond_px(rng):
    c = rng.choice([2, 3, 4, 5, 6, 7, 8]) / 100
    y = rng.choice([2, 3, 4, 5, 6, 7, 8, 9]) / 100
    n = rng.choice([2, 3, 5, 7, 10, 15, 20])
    m = rng.choice([1, 2])
    p = bond_price(c, y, n, m)
    freq = "annual" if m == 1 else "semiannual"
    q = f"A {n}-year bond pays a {c*100:.0f}% {freq} coupon. The yield to maturity is {y*100:.0f}% ({freq} compounding). What is its price per 100 of par?"
    steps = [f"Calculator: N = {n*m}, I/Y = {y*100/m:g}, PMT = {c*100/m:g}, FV = 100, CPT PV.",
             f"$PV = \\sum \\frac{{{c*100/m:g}}}{{(1+{y/m:.4f})^t}} + \\frac{{100}}{{(1+{y/m:.4f})^{{{n*m}}}}} = {p:.4f}$.",
             f"Coupon {'>' if c > y else '<' if c < y else '='} yield, so the bond trades at a {'premium' if c > y else 'discount' if c < y else 'par'}."]
    return result("fi", "Bond price from YTM", q, p, "", steps, tol=0.01)


@drill("fi", "Implied forward rate")
def fwd_rate(rng):
    z1 = rng.choice([1.5, 2, 2.5, 3, 3.5, 4]) / 100
    z2 = z1 + rng.choice([-0.5, 0.25, 0.5, 0.75, 1.0]) / 100
    z3 = z2 + rng.choice([-0.25, 0.25, 0.5, 0.75]) / 100
    kind = rng.choice(["1y1y", "2y1y", "1y2y"])
    if kind == "1y1y":
        fr = (1 + z2) ** 2 / (1 + z1) - 1
        st = f"$(1+{z2:.4f})^2/(1+{z1:.4f}) - 1 = {fr*100:.4f}\\%$"
    elif kind == "2y1y":
        fr = (1 + z3) ** 3 / (1 + z2) ** 2 - 1
        st = f"$(1+{z3:.4f})^3/(1+{z2:.4f})^2 - 1 = {fr*100:.4f}\\%$"
    else:
        fr = ((1 + z3) ** 3 / (1 + z1)) ** 0.5 - 1
        st = f"$\\left[(1+{z3:.4f})^3/(1+{z1:.4f})\\right]^{{1/2}} - 1 = {fr*100:.4f}\\%$"
    q = f"Annual spot rates: 1-year {z1*100:.2f}%, 2-year {z2*100:.2f}%, 3-year {z3*100:.2f}%. What is the {kind} forward rate (in %)?"
    steps = [f"{kind} is a {kind[2]}-year rate starting in {kind[0]} year(s).", f"No arbitrage: {st}."]
    return result("fi", "Implied forward rate", q, fr * 100, "%", steps, tol=0.005)


@drill("fi", "Price change with duration and convexity")
def dur_conv(rng):
    md = rng.choice([3.5, 4.8, 6.2, 7.5, 9.1, 12.4])
    cx = round(md ** 2 * rng.uniform(0.9, 1.3), 1)
    dy = rng.choice([-150, -100, -75, -50, 50, 75, 100, 150, 200]) / 10000
    pct = -md * dy + 0.5 * cx * dy ** 2
    q = f"A bond has modified duration {md} and convexity {cx}. Estimate the percentage price change for a {dy*10000:+.0f} bp change in yield (in %)."
    steps = [f"Duration effect: $-{md} \\times ({dy:+.4f}) = {-md*dy*100:+.4f}\\%$.",
             f"Convexity effect: $\\tfrac12 \\times {cx} \\times ({dy:.4f})^2 = {0.5*cx*dy**2*100:+.4f}\\%$ (always positive).",
             f"Total $\\approx {pct*100:+.4f}\\%$."]
    return result("fi", "Price change with duration and convexity", q, pct * 100, "%", steps, tol=0.01)


@drill("fi", "Macaulay and modified duration")
def mac_dur(rng):
    c = rng.choice([3, 4, 5, 6, 8]) / 100
    y = rng.choice([3, 4, 5, 6, 7]) / 100
    n = rng.choice([2, 3, 4])
    cf = [c * 100] * (n - 1) + [c * 100 + 100]
    pvs = [x / (1 + y) ** t for t, x in enumerate(cf, 1)]
    p = sum(pvs)
    mac = sum(t * v for t, v in enumerate(pvs, 1)) / p
    mod = mac / (1 + y)
    ask = rng.choice(["Macaulay", "modified"])
    q = f"A {n}-year bond pays a {c*100:.0f}% annual coupon and yields {y*100:.0f}%. What is its **{ask}** duration?"
    steps = ["PVs of cash flows: " + "; ".join(f"t={t}: ${x:.2f}/{1+y:.2f}^{t} = {v:.4f}$" for t, (x, v) in enumerate(zip(cf, pvs), 1)) + f". Price $= {p:.4f}$.",
             f"$MacDur = (" + " + ".join(f"{t}({v:.4f})" for t, v in enumerate(pvs, 1)) + f")/{p:.4f} = {mac:.4f}$.",
             f"$ModDur = {mac:.4f}/{1+y:.2f} = {mod:.4f}$."]
    return result("fi", "Macaulay and modified duration", q, mac if ask == "Macaulay" else mod, "years", steps, tol=0.005)


@drill("fi", "Expected loss and credit spread")
def exp_loss(rng):
    pd = rng.choice([0.5, 1, 1.5, 2, 3, 5]) / 100
    rr = rng.choice([20, 30, 40, 50, 60]) / 100
    el = pd * (1 - rr)
    q = f"A bond's annual probability of default is {pd*100:g}% and the expected recovery rate is {rr*100:.0f}%. What is the expected loss as a % of exposure?"
    steps = [f"$LGD = 1 - {rr:.2f} = {1-rr:.2f}$.", f"$EL = PD \\times LGD = {pd:.3f} \\times {1-rr:.2f} = {el*100:.3f}\\%$.",
             f"So the credit spread should be at least about {el*10000:.0f} bp."]
    return result("fi", "Expected loss and credit spread", q, el * 100, "%", steps, tol=0.005)


# ---------------------------------------------------------------- Derivatives
@drill("deriv", "Forward price with income")
def fwd_price(rng):
    s = rng.choice([50, 80, 100, 120, 150])
    r = rng.choice([2, 3, 4, 5, 6]) / 100
    T = rng.choice([0.5, 0.75, 1.0])
    div = rng.choice([0, 1, 1.5, 2, 3])
    td = T / 2
    pvd = div / (1 + r) ** td
    F = (s - pvd) * (1 + r) ** T
    q = (f"A stock trades at USD {s}. " + (f"It will pay a USD {div} dividend in {td*12:.0f} months. " if div else "It pays no dividends. ") +
         f"The risk-free rate is {r*100:.0f}% (annual compounding). What is the {T*12:.0f}-month forward price in USD?")
    steps = []
    if div:
        steps.append(f"$PV(D) = {div}/{1+r:.2f}^{{{td:g}}} = {pvd:.4f}$.")
    steps.append(f"$F_0 = ({s} - {pvd:.4f}) \\times {1+r:.2f}^{{{T:g}}} = {F:.4f}$.")
    return result("deriv", "Forward price with income", q, F, "USD", steps, tol=0.02)


@drill("deriv", "Put-call parity")
def pcp(rng):
    s = rng.choice([40, 50, 60, 75, 100])
    x = s + rng.choice([-10, -5, 0, 5, 10])
    r = rng.choice([2, 3, 4, 5]) / 100
    T = rng.choice([0.25, 0.5, 1.0])
    c = round(max(s - x / (1 + r) ** T, 0) + rng.uniform(1.5, 5.0), 2)
    pvx = x / (1 + r) ** T
    p = c + pvx - s
    q = f"S = USD {s}, X = USD {x}, T = {T:g} years, r = {r*100:.0f}% (annual compounding). A European call costs USD {c:.2f}. What should the European put cost (USD)?"
    steps = [f"$PV(X) = {x}/{1+r:.2f}^{{{T:g}}} = {pvx:.4f}$.", f"$p = c + PV(X) - S = {c:.2f} + {pvx:.4f} - {s} = {p:.4f}$."]
    return result("deriv", "Put-call parity", q, p, "USD", steps, tol=0.01)


@drill("deriv", "One-period binomial option value")
def binomial(rng):
    s = rng.choice([40, 50, 80, 100])
    u = rng.choice([1.1, 1.15, 1.2, 1.25])
    d = rng.choice([0.8, 0.85, 0.9])
    r = rng.choice([1, 2, 3, 4, 5]) / 100
    x = s + rng.choice([-5, 0, 5])
    typ = rng.choice(["call", "put"])
    pi = (1 + r - d) / (u - d)
    if typ == "call":
        vu, vd = max(s * u - x, 0), max(s * d - x, 0)
    else:
        vu, vd = max(x - s * u, 0), max(x - s * d, 0)
    v = (pi * vu + (1 - pi) * vd) / (1 + r)
    q = f"S = {s}, u = {u}, d = {d}, r = {r*100:.0f}% per period, X = {x}. Value a one-period European **{typ}**."
    steps = [f"$\\pi = (1 + {r:.2f} - {d})/({u} - {d}) = {pi:.4f}$.",
             f"Up price ${s*u:.2f}$: payoff ${vu:.2f}$. Down price ${s*d:.2f}$: payoff ${vd:.2f}$.",
             f"Value $= [{pi:.4f}({vu:.2f}) + {1-pi:.4f}({vd:.2f})]/{1+r:.2f} = {v:.4f}$."]
    return result("deriv", "One-period binomial option value", q, v, "USD", steps, tol=0.01)


# ---------------------------------------------------------------- Alternatives
@drill("alts", "Hedge fund fees and net return")
def hf_fees(rng):
    v0 = rng.choice([100, 200, 250, 500])
    g = rng.choice([8, 12, 15, 20, 25, 30]) / 100
    v1 = v0 * (1 + g)
    m = rng.choice([1, 1.5, 2]) / 100
    k = rng.choice([15, 20]) / 100
    hurdle = rng.choice([0, 5, 8])
    hard = rng.random() < 0.5
    mf = m * v1
    if hurdle == 0:
        base = v1 - v0 - mf
        htxt = "no hurdle"
    elif hard:
        base = v1 - mf - v0 * (1 + hurdle / 100)
        htxt = f"a {hurdle}% **hard** hurdle"
    else:
        cleared = (v1 - mf) / v0 - 1 > hurdle / 100
        base = (v1 - v0 - mf) if cleared else 0
        htxt = f"a {hurdle}% **soft** hurdle"
    inc = k * max(0, base)
    net = (v1 - mf - inc - v0) / v0
    q = (f"A fund begins the year at USD {v0}M and ends at USD {v1:.1f}M before fees. The management fee is {m*100:g}% of year-end "
         f"assets; the incentive fee is {k*100:.0f}% of gains net of the management fee, with {htxt}. What is the investors' net return (in %)?")
    steps = [f"Management fee $= {m:.3f} \\times {v1:.1f} = {mf:.3f}$."]
    if hurdle == 0:
        steps.append(f"Incentive $= {k:.2f} \\times ({v1:.1f} - {v0} - {mf:.3f}) = {inc:.3f}$.")
    elif hard:
        steps.append(f"Hard hurdle: incentive $= {k:.2f} \\times \\max(0, {v1:.1f} - {mf:.3f} - {v0*(1+hurdle/100):.1f}) = {inc:.3f}$.")
    else:
        steps.append(f"Return after management fee $= {((v1-mf)/v0-1)*100:.2f}\\%$ {'>' if base else '<='} {hurdle}%: "
                     + (f"hurdle cleared, incentive on all gains $= {k:.2f} \\times {base:.3f} = {inc:.3f}$." if base else "no incentive fee."))
    steps.append(f"Net return $= ({v1:.1f} - {mf:.3f} - {inc:.3f} - {v0})/{v0} = {net*100:.3f}\\%$.")
    return result("alts", "Hedge fund fees and net return", q, net * 100, "%", steps, tol=0.01)


@drill("alts", "Cap rate valuation")
def cap_rate(rng):
    noi = rng.choice([0.6, 0.9, 1.2, 1.5, 2.4])
    cr = rng.choice([4.5, 5, 5.5, 6, 6.5, 7, 7.5, 8]) / 100
    v = noi / cr
    q = f"A property is expected to generate NOI of USD {noi}M next year. The market cap rate is {cr*100:g}%. What is its value in USD millions?"
    steps = [f"$V = NOI/\\text{{cap rate}} = {noi}/{cr:.3f} = {v:.3f}$."]
    return result("alts", "Cap rate valuation", q, v, "USD M", steps, tol=0.01)


# ---------------------------------------------------------------- Portfolio
@drill("pm", "CAPM and Jensen's alpha")
def capm(rng):
    rf = rng.choice([2, 3, 4]) / 100
    rm = rf + rng.choice([5, 6, 7]) / 100
    b = rng.choice([0.7, 0.9, 1.0, 1.2, 1.5])
    rp = rng.choice([8, 9, 10, 11, 12, 13, 14]) / 100
    req = rf + b * (rm - rf)
    a = rp - req
    q = f"Rf = {rf*100:.0f}%, market return {rm*100:.0f}%. A portfolio with beta {b} returned {rp*100:.0f}%. What is Jensen's alpha (in %)?"
    steps = [f"Required (CAPM) return $= {rf*100:.0f}\\% + {b}({(rm-rf)*100:.0f}\\%) = {req*100:.2f}\\%$.",
             f"$\\alpha = {rp*100:.0f}\\% - {req*100:.2f}\\% = {a*100:+.2f}\\%$."]
    return result("pm", "CAPM and Jensen's alpha", q, a * 100, "%", steps, tol=0.01)


@drill("pm", "Sharpe, Treynor and M-squared")
def perf(rng):
    rf = rng.choice([2, 3, 4]) / 100
    rp = rng.choice([9, 10, 11, 12, 13, 14]) / 100
    sp = rng.choice([12, 15, 18, 20, 24]) / 100
    rm = rng.choice([8, 9, 10, 11]) / 100
    sm = rng.choice([14, 15, 16, 18]) / 100
    beta = rng.choice([0.8, 0.9, 1.1, 1.2])
    which = rng.choice(["Sharpe ratio", "Treynor ratio (in %)", "M-squared (in %)"])
    sh = (rp - rf) / sp
    tr = (rp - rf) / beta
    m2 = (rp - rf) * sm / sp - (rm - rf)
    ans = sh if which.startswith("Sharpe") else (tr * 100 if which.startswith("Treynor") else m2 * 100)
    q = (f"Portfolio: return {rp*100:.0f}%, standard deviation {sp*100:.0f}%, beta {beta}. Market: return {rm*100:.0f}%, "
         f"standard deviation {sm*100:.0f}%. Rf = {rf*100:.0f}%. Compute the portfolio's **{which}**.")
    steps = [f"Excess return $= {rp*100:.0f}\\% - {rf*100:.0f}\\% = {(rp-rf)*100:.0f}\\%$.",
             f"Sharpe $= {(rp-rf):.2f}/{sp:.2f} = {sh:.4f}$ (market: ${(rm-rf)/sm:.4f}$).",
             f"Treynor $= {(rp-rf)*100:.0f}\\%/{beta} = {tr*100:.4f}\\%$.",
             f"$M^2 = {(rp-rf)*100:.0f}\\% \\times {sm:.2f}/{sp:.2f} - {(rm-rf)*100:.0f}\\% = {m2*100:.4f}\\%$."]
    return result("pm", "Sharpe, Treynor and M-squared", q, ans, "" if which.startswith("Sharpe") else "%", steps,
                  tol=0.005 if which.startswith("Sharpe") else 0.01)


@drill("pm", "Investor utility")
def utility(rng):
    A = rng.choice([1, 2, 3, 4, 5, 6])
    er = rng.choice([6, 8, 10, 12, 14]) / 100
    sd = rng.choice([8, 10, 15, 20, 25]) / 100
    u = er - 0.5 * A * sd ** 2
    q = f"An investor has a risk aversion coefficient A = {A}. What is the utility of a portfolio with expected return {er*100:.0f}% and standard deviation {sd*100:.0f}%? (Answer as a decimal, e.g. 0.0525.)"
    steps = [f"$U = {er:.2f} - 0.5({A})({sd:.2f})^2 = {er:.2f} - {0.5*A*sd**2:.4f} = {u:.4f}$."]
    return result("pm", "Investor utility", q, u, "", steps, tol=0.0005)


def generate(name, seed=None):
    rng = random.Random(seed)
    d = DRILLS[name]["fn"](rng)
    d["name"] = name
    return d


def drills_for(topic=None):
    return [k for k, v in DRILLS.items() if topic in (None, "all", v["topic"])]


if __name__ == "__main__":
    for name in DRILLS:
        for s in range(200):
            d = generate(name, s)
            assert math.isfinite(d["answer"]), name
    print(len(DRILLS), "drills OK")
    print(generate("two_stage", 1))

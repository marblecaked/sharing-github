"""Render the content source to a LaTeX study guide and compile it to PDF."""
import re
import subprocess
import sys
from pathlib import Path

from content import TOPICS

OUT = Path(__file__).parent / "build"
OUT.mkdir(exist_ok=True)

MATH_RE = re.compile(r"(\$\$.+?\$\$|\$.+?\$)", re.S)


def esc_text(s):
    rep = {"\\": r"\textbackslash{}", "&": r"\&", "%": r"\%", "#": r"\#", "_": r"\_",
           "{": r"\{", "}": r"\}", "~": r"\textasciitilde{}", "^": r"\textasciicircum{}", "|": r"\textbar{}"}
    s = "".join(rep.get(c, c) for c in s)
    s = re.sub(r"\*\*(.+?)\*\*", r"\\textbf{\1}", s)
    s = re.sub(r"(?<![\w*])\*(?!\s)(.+?)(?<!\s)\*(?![\w*])", r"\\emph{\1}", s)
    s = re.sub(r'"([^"]*)"', r"``\1''", s)
    s = s.replace("'s ", "'s ")
    return s


def inline(s):
    out = []
    for part in MATH_RE.split(s):
        if not part:
            continue
        if part.startswith("$$"):
            out.append(r"\[" + part[2:-2].strip() + r"\]")
        elif part.startswith("$"):
            out.append("$" + part[1:-1] + "$")
        else:
            out.append(esc_text(part))
    return "".join(out)


def table(lines):
    rows = [[c.strip() for c in ln.strip().strip("|").split("|")] for ln in lines]
    rows = [r for r in rows if not all(re.fullmatch(r":?-{2,}:?", c) for c in r)]
    ncol = len(rows[0])
    first = r">{\raggedright\arraybackslash\bfseries}p{0.17\linewidth}" if ncol >= 4 else r">{\raggedright\arraybackslash}X"
    spec = first + "".join([r">{\raggedright\arraybackslash}X"] * (ncol - 1))
    size = r"\footnotesize" if ncol >= 5 else r"\small"
    body = [r"\begin{center}" + size, r"\renewcommand{\arraystretch}{1.25}",
            r"\begin{tabularx}{\linewidth}{" + spec + "}", r"\toprule"]
    body.append(" & ".join(r"\textbf{" + inline(c) + "}" for c in rows[0]) + r" \\ \midrule")
    for r in rows[1:]:
        r = (r + [""] * ncol)[:ncol]
        body.append(" & ".join(inline(c) for c in r) + r" \\")
    body += [r"\bottomrule", r"\end{tabularx}", r"\end{center}"]
    return "\n".join(body)


def md(text):
    blocks, out = re.split(r"\n\s*\n", text.strip()), []
    for b in blocks:
        lines = b.strip("\n").split("\n")
        if all(l.strip().startswith("|") for l in lines):
            out.append(table(lines))
        elif all(l.strip().startswith("- ") for l in lines):
            out.append(r"\begin{itemize}" + "".join(r"\item " + inline(l.strip()[2:]) for l in lines) + r"\end{itemize}")
        elif all(re.match(r"\s*\d+\.\s", l) for l in lines):
            out.append(r"\begin{enumerate}" + "".join(r"\item " + inline(re.sub(r"^\s*\d+\.\s", "", l)) for l in lines) + r"\end{enumerate}")
        elif b.strip().startswith("$$") and b.strip().endswith("$$"):
            out.append(r"\[" + b.strip()[2:-2].strip() + r"\]")
        else:
            out.append(inline(" ".join(l.strip() for l in lines)))
    return "\n\n".join(out)


def formula_box(fo):
    s = [r"\begin{formulabox}{" + esc_text(fo["name"]) + "}",
         r"\[" + fo["tex"] + r"\]"]
    if fo["vars"]:
        s.append(r"\par\vspace{1pt}{\small\textit{where}}\par\vspace{-2pt}")
        s.append(r"\begin{varlist}")
        for sym, meaning in fo["vars"]:
            s.append(r"\item[$" + sym + r"$] " + inline(meaning))
        s.append(r"\end{varlist}")
    if fo.get("note"):
        s.append(r"{\small " + inline(fo["note"]) + "}")
    s.append(r"\end{formulabox}")
    return "\n".join(s)


def example_box(ex, n):
    s = [r"\begin{examplebox}{Example " + n + ": " + esc_text(ex["title"]) + "}",
         md(ex["problem"]),
         r"\par\smallskip\textbf{Solution}",
         r"\begin{enumerate}[label=\arabic*.,leftmargin=1.6em,itemsep=2pt]"]
    s += [r"\item " + md(st) for st in ex["steps"]]
    s.append(r"\end{enumerate}")
    s.append(r"\answerline{" + md(ex["answer"]) + "}")
    s.append(r"\end{examplebox}")
    return "\n".join(s)


def problem_tex(p, n):
    lvl = {1: "Recall", 2: "Apply", 3: "Analyze"}[p.get("level", 2)]
    s = [r"\begin{problem}{" + str(n) + "}{" + lvl + "}", md(p["q"]),
         r"\begin{choices}"]
    s += [r"\item[" + k + ".] " + inline(v) for k, v in sorted(p["choices"].items())]
    s += [r"\end{choices}", r"\end{problem}"]
    return "\n".join(s)


def topic_tex(ti, t):
    s = [r"\chapter{" + esc_text(t["name"]) + "}",
         r"\chapterweight{" + esc_text(t["weight"]) + "}{" + str(len(t["problems"])) + "}",
         md(t["overview"])]
    sec_num = {}
    for si, sec in enumerate(t["sections"], 1):
        sec_num[sec["id"]] = f"{ti}.{si}"
        s.append(r"\section{" + esc_text(sec["title"]) + "}")
        s.append(md(sec["body"]))
        if sec["formulas"]:
            s.append(r"\subsection*{Key formulas}")
            s += [formula_box(fo) for fo in sec["formulas"]]
        if sec["examples"]:
            s.append(r"\subsection*{Worked examples}")
            s += [example_box(ex, f"{ti}.{si}.{k}") for k, ex in enumerate(sec["examples"], 1)]
    s.append(r"\section*{Exam traps}\addcontentsline{toc}{section}{Exam traps}")
    s.append(r"\begin{trapbox}\begin{itemize}[leftmargin=1.2em,itemsep=3pt]" +
             "".join(r"\item " + inline(x) for x in t["pitfalls"]) + r"\end{itemize}\end{trapbox}")
    s.append(r"\clearpage\section*{Practice problems}\addcontentsline{toc}{section}{Practice problems}")
    s.append(r"{\small Problems are grouped by section. Levels: \emph{Recall} (definitions), \emph{Apply} (one-step use of a rule or formula), \emph{Analyze} (multi-step). Answers follow the problem set.}\par\medskip")
    n = 0
    for sec in t["sections"]:
        probs = [p for p in t["problems"] if p["section"] == sec["id"]]
        if not probs:
            continue
        s.append(r"\probsection{" + sec_num[sec["id"]] + " " + esc_text(sec["title"]) + "}")
        for p in probs:
            n += 1
            p["_num"] = n
            s.append(problem_tex(p, n))
    s.append(r"\section*{Answers and explanations}\addcontentsline{toc}{section}{Answers and explanations}")
    s.append(r"\begin{answers}")
    for sec in t["sections"]:
        for p in [p for p in t["problems"] if p["section"] == sec["id"]]:
            s.append(r"\ans{" + str(p["_num"]) + "}{" + p["answer"] + "}{" + md(p["explanation"]) + "}")
    s.append(r"\end{answers}")
    return "\n\n".join(s)


def formula_sheet():
    s = [r"\chapter{Formula Sheet}",
         r"Every formula from the guide on one set of pages, by topic. Use it for the final review weeks: cover the right-hand side and recall it."]
    for t in TOPICS:
        fs = [(sec, fo) for sec in t["sections"] for fo in sec["formulas"]]
        if not fs:
            continue
        s.append(r"\section*{" + esc_text(t["name"]) + "}")
        s.append(r"\begin{sheet}")
        for sec, fo in fs:
            s.append(r"\sheetrow{" + esc_text(fo["name"]) + r"}{$\displaystyle " + fo["tex"] + "$}")
        s.append(r"\end{sheet}")
    return "\n".join(s)


PREAMBLE = r"""
\documentclass[11pt,openany]{report}
\usepackage[letterpaper,margin=0.9in,headheight=14pt]{geometry}
\usepackage[T1]{fontenc}
\usepackage[utf8]{inputenc}
\usepackage{mathpazo}
\usepackage[scaled=0.92]{helvet}
\usepackage{amsmath,amssymb}
\usepackage{microtype}
\usepackage{xcolor}
\usepackage{tabularx,booktabs,array,longtable}
\usepackage{enumitem}
\usepackage[most]{tcolorbox}
\usepackage{titlesec}
\usepackage{fancyhdr}
\usepackage{needspace}
\usepackage[hidelinks]{hyperref}
\usepackage{bookmark}
\setcounter{tocdepth}{1}

\definecolor{ink}{HTML}{1B2A41}
\definecolor{accent}{HTML}{0F6E8C}
\definecolor{accentlight}{HTML}{E8F3F6}
\definecolor{ex}{HTML}{B7791F}
\definecolor{exlight}{HTML}{FDF8EE}
\definecolor{trap}{HTML}{B23A48}
\definecolor{traplight}{HTML}{FBEFF1}
\definecolor{muted}{HTML}{5B6676}
\definecolor{rule}{HTML}{D5DCE4}

\setlength{\parindent}{0pt}
\setlength{\parskip}{6pt}
\linespread{1.06}
\setlength{\emergencystretch}{2em}

\titleformat{\chapter}[display]{\sffamily\color{ink}}
  {\large\color{accent}\textsc{\chaptertitlename\ \thechapter}}{4pt}{\Huge\bfseries}[\vspace{2pt}{\color{accent}\titlerule[1.2pt]}]
\titlespacing*{\chapter}{0pt}{-20pt}{14pt}
\titleformat{\section}{\sffamily\Large\bfseries\color{ink}}{\color{accent}\thesection}{0.6em}{}
\titlespacing*{\section}{0pt}{18pt}{6pt}
\titleformat{\subsection}{\sffamily\large\bfseries\color{accent}}{\thesubsection}{0.6em}{}
\titlespacing*{\subsection}{0pt}{12pt}{4pt}

\pagestyle{fancy}
\fancyhf{}
\fancyhead[L]{\sffamily\small\color{muted}CFA Level I Study Guide}
\fancyhead[R]{\sffamily\small\color{muted}\leftmark}
\fancyfoot[C]{\sffamily\small\color{muted}\thepage}
\renewcommand{\headrulewidth}{0.4pt}
\renewcommand{\headrule}{{\color{rule}\hrule width\headwidth height\headrulewidth}}
\renewcommand{\chaptermark}[1]{\markboth{#1}{}}
\fancypagestyle{plain}{\fancyhf{}\fancyfoot[C]{\sffamily\small\color{muted}\thepage}\renewcommand{\headrulewidth}{0pt}}

\setlist[itemize]{leftmargin=1.3em,itemsep=2pt,topsep=2pt}
\setlist[enumerate]{leftmargin=1.6em,itemsep=2pt,topsep=2pt}
\newlist{varlist}{description}{1}
\setlist[varlist]{leftmargin=6.5em,labelwidth=6em,labelsep=0.5em,itemsep=0pt,topsep=1pt,font=\normalfont,style=sameline}
\newlist{choices}{description}{1}
\setlist[choices]{leftmargin=2.2em,labelwidth=1.6em,itemsep=0pt,parsep=0pt,topsep=2pt,font=\sffamily\bfseries\color{accent}}

\newtcolorbox{formulabox}[1]{enhanced,breakable=false,colback=accentlight,colframe=accent,boxrule=0pt,leftrule=3pt,
  arc=2pt,left=8pt,right=8pt,top=4pt,bottom=4pt,before skip=6pt,after skip=6pt,
  title={\sffamily\small\bfseries #1},coltitle=accent,colbacktitle=accentlight,attach title to upper,
  after title={\par\vspace{-4pt}}}
\newtcolorbox{examplebox}[1]{enhanced,breakable,colback=exlight,colframe=ex,boxrule=0.4pt,leftrule=3pt,arc=2pt,
  left=8pt,right=8pt,top=6pt,bottom=6pt,before skip=8pt,after skip=8pt,
  title={\sffamily\bfseries #1},colbacktitle=ex,coltitle=white,fonttitle=\sffamily}
\newtcolorbox{trapbox}{enhanced,breakable,colback=traplight,colframe=trap,boxrule=0.4pt,leftrule=3pt,arc=2pt,
  left=8pt,right=8pt,top=4pt,bottom=4pt}
\newcommand{\answerline}[1]{\par\smallskip{\color{ex}\rule{\linewidth}{0.4pt}}\par\textbf{\sffamily Answer.} #1}
\newcommand{\chapterweight}[2]{\begin{tcolorbox}[colback=white,colframe=rule,boxrule=0.5pt,arc=2pt,left=8pt,right=8pt,top=3pt,bottom=3pt]
  \sffamily\small\textbf{Exam weight:} #1 \hfill \textbf{Practice problems in this chapter:} #2\end{tcolorbox}}
\newcommand{\probsection}[1]{\par\needspace{6\baselineskip}\medskip{\sffamily\bfseries\color{accent}#1}\par\vspace{3pt}{\color{rule}\hrule}\vspace{6pt}}
\newenvironment{problem}[2]{\par\needspace{5\baselineskip}\noindent\begin{minipage}{\linewidth}
  {\sffamily\bfseries\color{ink}#1.}~{\sffamily\scriptsize\color{muted}[#2]}~}{\end{minipage}\par\medskip}
\newenvironment{answers}{\small}{}
\newcommand{\ans}[3]{\par\needspace{3\baselineskip}\noindent{\sffamily\bfseries\color{ink}#1.~\color{accent}#2}\quad #3\par\vspace{2pt}}
\newenvironment{sheet}{\renewcommand{\arraystretch}{1.9}\small\begin{longtable}{>{\raggedright\arraybackslash\sffamily\footnotesize\color{muted}}m{0.25\linewidth}>{\raggedright\arraybackslash}m{0.69\linewidth}}\toprule}{\bottomrule\end{longtable}}
\newcommand{\sheetrow}[2]{#1 & #2 \\ \midrule[0.2pt]}
\renewcommand{\chaptername}{Topic}
\begin{document}
"""

TITLE = r"""
\begin{titlepage}
\begin{tcolorbox}[enhanced,colback=ink,colframe=ink,arc=0pt,left=28pt,right=28pt,top=40pt,bottom=40pt,width=\linewidth]
\color{white}\sffamily
{\large\color{accentlight} CFA\textsuperscript{\textregistered} Program}\\[6pt]
{\fontsize{40}{44}\selectfont\bfseries Level I}\\[4pt]
{\fontsize{24}{28}\selectfont Study Guide}\\[18pt]
{\large Readings \textbullet{} Formulas with breakdowns \textbullet{} Worked examples \textbullet{} Practice problems}
\end{tcolorbox}
\vspace{24pt}
{\sffamily\large\color{ink}
\begin{tabularx}{\linewidth}{Xr}
\textbf{Topics covered} & 10 of 10 \\
\textbf{Worked examples} & EXAMPLES \\
\textbf{Formulas, each with a variable breakdown} & FORMULAS \\
\textbf{Practice problems with explanations} & PROBLEMS \\
\end{tabularx}}
\vfill
{\sffamily\small\color{muted}
Organized to the 2026 Level I curriculum topic areas and weights. The Ethics chapter reflects the 12th edition of the Standards of Practice Handbook (effective 1 January 2024).
This guide is an independent study aid, not CFA Institute material; always confirm details against the official curriculum.
A companion browser app (Dash) uses the same content and adds randomized calculation drills, timed mock exams and progress tracking.\par}
\end{titlepage}
"""

HOWTO = r"""
\chapter*{How to Use This Guide}
\addcontentsline{toc}{chapter}{How to Use This Guide}
\markboth{How to Use This Guide}{}
Each topic follows the same four-part rhythm:
\begin{enumerate}
\item \textbf{Reading.} A focused write-up of what the curriculum tests, with tables for the comparisons that show up as exam questions.
\item \textbf{Key formulas} \textit{(blue boxes)}. Each formula is followed by a line-by-line breakdown of every variable and a note on common variants.
\item \textbf{Worked examples} \textit{(amber boxes)}. Step-by-step solutions, with the calculator keystrokes where they help.
\item \textbf{Practice problems.} Three-choice questions in the exam format, tagged \emph{Recall}, \emph{Apply} or \emph{Analyze}, with answers and explanations of why the distractors are wrong. Each chapter ends with \textit{Exam traps} \textit{(red box)}: the mistakes the question writers expect you to make.
\end{enumerate}

\section*{The exam at a glance}
The Level I exam is a computer-based test of 180 multiple-choice questions in two 135-minute sessions: about \textbf{90 seconds per question}. Each question has three answer choices and there is no penalty for guessing. CFA Institute recommends roughly 300 hours of study.

\begin{center}\sffamily\small
\renewcommand{\arraystretch}{1.25}
\begin{tabularx}{0.82\linewidth}{Xrr}
\toprule
\textbf{Topic} & \textbf{Weight} & \textbf{Questions (approx.)}\\
\midrule
WEIGHTROWS
\bottomrule
\end{tabularx}
\end{center}

\section*{A suggested plan}
\begin{itemize}
\item \textbf{Order.} Start with Quantitative Methods (the toolkit), then Economics, Corporate Issuers and FSA; next Equity, Fixed Income, Derivatives, Alternatives and Portfolio Management. Study Ethics early \emph{and} again in the final month: it carries the most weight and rewards repetition.
\item \textbf{Each session.} Read a section, close the guide, rewrite each formula from memory with its variables, rework the examples without looking, then do the practice set for that section.
\item \textbf{Drills.} Use the companion app's randomized drills until the calculator steps are automatic. Speed on calculations buys time for the long ethics and FSA vignettes.
\item \textbf{Final six weeks.} Timed mixed mock exams in the app (it weights questions by topic), the formula sheet at the back of this guide, and the \emph{Exam traps} boxes.
\end{itemize}

\section*{Calculator essentials (TI BA II Plus)}
\begin{itemize}
\item Set decimals to 4 or more: \texttt{2ND FORMAT 4 ENTER}. Set P/Y = 1: \texttt{2ND P/Y 1 ENTER}; then work with periodic rates and periods yourself.
\item Clear TVM registers before every problem: \texttt{2ND CLR TVM}. Clear cash flows: \texttt{CF 2ND CLR WORK}.
\item Annuity due: \texttt{2ND BGN 2ND SET}, and switch back to END afterwards.
\item NPV/IRR: \texttt{CF}, enter CF0, C01 (with F01 frequency), and so on; then \texttt{NPV}, enter I, \texttt{CPT}; or \texttt{IRR CPT}.
\item Sign convention: money paid out is negative, money received is positive.
\end{itemize}
"""


def build():
    ne = sum(len(s["examples"]) for t in TOPICS for s in t["sections"])
    nf = sum(len(s["formulas"]) for t in TOPICS for s in t["sections"])
    nq = sum(len(t["problems"]) for t in TOPICS)
    rows = []
    for t in TOPICS:
        lo, hi = [float(x) for x in t["weight"].rstrip("%").split("-")]
        rows.append(f"{esc_text(t['name'])} & {lo:.0f}--{hi:.0f}\\% & {round(lo*1.8)}--{round(hi*1.8)}\\\\")
    doc = [PREAMBLE,
           TITLE.replace("EXAMPLES", str(ne)).replace("FORMULAS", str(nf)).replace("PROBLEMS", str(nq)),
           r"\pagenumbering{roman}\tableofcontents\clearpage\pagenumbering{arabic}",
           HOWTO.replace("WEIGHTROWS", "\n".join(rows))]
    for i, t in enumerate(TOPICS, 1):
        doc.append(topic_tex(i, t))
    doc.append(r"\appendix")
    doc.append(formula_sheet())
    doc.append(r"\end{document}")
    tex = OUT / "CFA_Level_I_Study_Guide.tex"
    tex.write_text("\n\n".join(doc))
    for _ in range(3):
        r = subprocess.run(["pdflatex", "-interaction=nonstopmode", "-halt-on-error", tex.name],
                           cwd=OUT, capture_output=True, text=True)
        if r.returncode != 0:
            log = (OUT / "CFA_Level_I_Study_Guide.log").read_text(errors="ignore")
            i = log.find("\n!")
            print(log[i - 200:i + 1500] if i >= 0 else r.stdout[-3000:])
            sys.exit(1)
    print("built", OUT / "CFA_Level_I_Study_Guide.pdf")


if __name__ == "__main__":
    build()
